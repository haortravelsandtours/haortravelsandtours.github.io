import React from 'react';
import { 
  Award, 
  CheckCircle2 
} from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';

interface WhyChooseUsProps {
  lang: 'bn' | 'en';
}

export const WhyChooseUs: React.FC<WhyChooseUsProps> = ({ lang }) => {
  const { content, updateWhyUs } = useContent();

  return (
    <section id="why-us" className="py-20 bg-white text-slate-900 relative border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-8 relative z-10 grid grid-cols-12 gap-12 items-center">
        
        {/* Left Column: Core Story & User Narrative Quote (6 cols) */}
        <div className="col-span-6 space-y-6">
          <Deletable id="whyUs.badge" label="কেন আমরা ব্যাজ">
            <span className="inline-flex items-center gap-2 bg-[#166D74] text-white font-black px-4 py-1.5 rounded-full text-xs uppercase tracking-wider shadow-sm">
              <Deletable id="whyUs.awardIcon" inline label="অ্যাওয়ার্ড আইকন">
                <Award className="w-4 h-4 text-white" />
              </Deletable>
              <EditableText
                id="whyUs.badgeText"
                label="কেন আমরা ব্যাজ টেক্সট"
                value={lang === 'bn' ? content.whyUs.badgeBn : content.whyUs.badgeEn}
                onSave={(val) => {
                  if (lang === 'bn') updateWhyUs({ badgeBn: val });
                  else updateWhyUs({ badgeEn: val });
                }}
              />
            </span>
          </Deletable>

          <h2 className="text-4xl lg:text-5xl font-black text-slate-900 leading-tight">
            <EditableText
              id="whyUs.title"
              label="কেন আমরা টাইটেল"
              value={lang === 'bn' ? content.whyUs.titleBn : content.whyUs.titleEn}
              onSave={(val) => {
                if (lang === 'bn') updateWhyUs({ titleBn: val });
                else updateWhyUs({ titleEn: val });
              }}
            />
          </h2>

          {/* User's Exact Core Narrative */}
          <Deletable id="whyUs.quoteBox" label="কেন আমরা উক্তি বক্স">
            <div className="p-6 rounded-2xl bg-slate-50 border-l-4 border-[#166D74] text-[#166D74] text-lg leading-relaxed font-bold shadow-sm">
              &ldquo;
              <EditableText
                id="whyUs.quoteText"
                label="কেন আমরা উক্তি টেক্সট"
                multiline
                value={lang === 'bn' ? content.whyUs.quoteBn : content.whyUs.quoteEn}
                onSave={(val) => {
                  if (lang === 'bn') updateWhyUs({ quoteBn: val });
                  else updateWhyUs({ quoteEn: val });
                }}
              />
              &rdquo;
            </div>
          </Deletable>

          <div className="text-slate-600 text-base leading-relaxed">
            <EditableText
              id="whyUs.desc"
              label="কেন আমরা বিবরণ"
              multiline
              value={lang === 'bn' ? content.whyUs.descBn : content.whyUs.descEn}
              onSave={(val) => {
                if (lang === 'bn') updateWhyUs({ descBn: val });
                else updateWhyUs({ descEn: val });
              }}
            />
          </div>
        </div>

        {/* Right Column: 4 Trust Pillars (6 cols, 2x2 grid) */}
        <div className="col-span-6 grid grid-cols-2 gap-4">
          {content.whyUs.pillars.map((item, idx) => (
            <Deletable key={idx} id={`whyUs.pillar.${idx}`} label={`বিশ্বাস পিলার ${idx + 1}`}>
              <div 
                className="p-6 rounded-2xl bg-slate-50 border-2 border-slate-200 hover:border-[#166D74] transition flex flex-col justify-between shadow-sm h-full"
              >
                <div>
                  <Deletable id={`whyUs.pillarIcon.${idx}`} inline label={`পিলার আইকন ${idx + 1}`}>
                    <div className="w-10 h-10 rounded-xl bg-[#166D74] text-white flex items-center justify-center font-black mb-4 shadow-md">
                      <CheckCircle2 className="w-6 h-6 text-white" />
                    </div>
                  </Deletable>
                  <h3 className="font-black text-slate-900 text-lg mb-2">
                    <EditableText
                      id={`whyUs.pillarTitle.${idx}`}
                      label="পিলার টাইটেল"
                      value={lang === 'bn' ? item.titleBn : item.titleEn}
                      onSave={(val) => {
                        const newPillars = [...content.whyUs.pillars];
                        if (lang === 'bn') newPillars[idx].titleBn = val;
                        else newPillars[idx].titleEn = val;
                        updateWhyUs({ pillars: newPillars });
                      }}
                    />
                  </h3>
                  <div className="text-sm text-slate-600 leading-relaxed font-medium">
                    <EditableText
                      id={`whyUs.pillarDesc.${idx}`}
                      label="পিলার বিবরণ"
                      value={lang === 'bn' ? item.descBn : item.descEn}
                      onSave={(val) => {
                        const newPillars = [...content.whyUs.pillars];
                        if (lang === 'bn') newPillars[idx].descBn = val;
                        else newPillars[idx].descEn = val;
                        updateWhyUs({ pillars: newPillars });
                      }}
                    />
                  </div>
                </div>
              </div>
            </Deletable>
          ))}
        </div>

      </div>
    </section>
  );
};
