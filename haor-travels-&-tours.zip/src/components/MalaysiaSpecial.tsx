import React from 'react';
import { 
  Building2, 
  Factory, 
  Trees, 
  Utensils, 
  CheckCircle2, 
  MessageCircle, 
  ArrowRight, 
  ShieldCheck, 
  Star 
} from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';

interface MalaysiaSpecialProps {
  lang: 'bn' | 'en';
  onOpenChecklist: () => void;
}

export const MalaysiaSpecial: React.FC<MalaysiaSpecialProps> = ({ lang, onOpenChecklist }) => {
  const { content, updateMalaysia } = useContent();

  const whatsappPhone = content.numbers?.floatingWhatsApp?.phone || content.numbers?.headerWhatsApp?.phone || '01914484627';
  const sectorIcons = [Factory, Building2, Trees, Utensils];

  return (
    <section id="malaysia" className="py-20 bg-slate-50 border-y border-slate-200 text-slate-900 relative">
      <div className="max-w-7xl mx-auto px-8">
        <div className="bg-white rounded-3xl p-10 lg:p-12 shadow-xl border-2 border-[#166D74] grid grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Special Badge, Quote & Story (5 cols) */}
          <div className="col-span-5 space-y-6">
            <Deletable id="malaysia.badge" label="মালয়েশিয়া ব্যাজ">
              <div className="inline-flex items-center gap-1.5 bg-[#166D74] text-white font-black px-4 py-1.5 rounded-full text-xs uppercase tracking-wider shadow-sm">
                <Deletable id="malaysia.starIcon" inline label="স্টার আইকন">
                  <Star className="w-4 h-4 fill-white text-white" />
                </Deletable>
                <EditableText
                  id="malaysia.badgeText"
                  label="মালয়েশিয়া ব্যাজ টেক্সট"
                  value={lang === 'bn' ? content.malaysia.badgeBn : content.malaysia.badgeEn}
                  onSave={(val) => {
                    if (lang === 'bn') updateMalaysia({ badgeBn: val });
                    else updateMalaysia({ badgeEn: val });
                  }}
                />
              </div>
            </Deletable>

            <h2 className="text-4xl font-black text-slate-900 leading-tight">
              <EditableText
                id="malaysia.title"
                label="মালয়েশিয়া টাইটেল"
                value={lang === 'bn' ? content.malaysia.titleBn : content.malaysia.titleEn}
                onSave={(val) => {
                  if (lang === 'bn') updateMalaysia({ titleBn: val });
                  else updateMalaysia({ titleEn: val });
                }}
              />
            </h2>

            {/* Special User Highlighted Quote */}
            <Deletable id="malaysia.quoteBox" label="উক্তি বক্স">
              <div className="p-6 rounded-2xl bg-slate-50 border-l-4 border-[#166D74] text-[#166D74] font-bold text-lg leading-relaxed shadow-sm">
                &ldquo;
                <EditableText
                  id="malaysia.quoteText"
                  label="উক্তি টেক্সট"
                  multiline
                  value={lang === 'bn' ? content.malaysia.quoteBn : content.malaysia.quoteEn}
                  onSave={(val) => {
                    if (lang === 'bn') updateMalaysia({ quoteBn: val });
                    else updateMalaysia({ quoteEn: val });
                  }}
                />
                &rdquo;
              </div>
            </Deletable>

            <div className="text-slate-600 text-base leading-relaxed">
              <EditableText
                id="malaysia.desc"
                label="মালয়েশিয়া বিবরণ"
                multiline
                value={lang === 'bn' ? content.malaysia.descBn : content.malaysia.descEn}
                onSave={(val) => {
                  if (lang === 'bn') updateMalaysia({ descBn: val });
                  else updateMalaysia({ descEn: val });
                }}
              />
            </div>

            {/* Action buttons */}
            <div className="flex flex-row items-center gap-4 pt-2">
              <Deletable id="malaysia.whatsappBtn" label="মালয়েশিয়া হোয়াটসঅ্যাপ বাটন">
                <a
                  href={`https://wa.me/88${whatsappPhone}?text=${encodeURIComponent(
                    'Assalamu Alaikum, I would like to inquire specifically about Malaysia Work / Calling Visa.'
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-[#166D74] hover:bg-[#0E585E] text-white font-black rounded-xl text-sm px-6 py-3.5 shadow-lg transition hover:-translate-y-0.5"
                >
                  <Deletable id="malaysia.whatsappIcon" inline label="হোয়াটসঅ্যাপ আইকন">
                    <MessageCircle className="w-5 h-5 fill-white text-white" />
                  </Deletable>
                  <span>{lang === 'bn' ? 'মালয়েশিয়া ভিসা সম্পর্কে জানুন' : 'Inquire on WhatsApp'}</span>
                </a>
              </Deletable>

              <Deletable id="malaysia.checklistBtn" label="চেকলিস্ট বাটন">
                <button
                  onClick={onOpenChecklist}
                  className="inline-flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-900 font-black rounded-xl text-sm px-6 py-3.5 shadow-sm transition hover:-translate-y-0.5 cursor-pointer border border-slate-200"
                >
                  <span>{lang === 'bn' ? 'কাগজপত্রের তালিকা' : 'View Checklist'}</span>
                  <ArrowRight className="w-4 h-4 text-[#166D74]" />
                </button>
              </Deletable>
            </div>
          </div>

          {/* Right Column: Sectors & Value Pillars (7 cols) */}
          <div className="col-span-7 space-y-6">
            <div className="grid grid-cols-2 gap-4">
              {content.malaysia.sectors.map((sec, idx) => {
                const Icon = sectorIcons[idx % sectorIcons.length];
                return (
                  <Deletable key={idx} id={`malaysia.sector.${idx}`} label={`সেক্টর: ${sec.titleBn}`}>
                    <div 
                      className="p-5 rounded-2xl bg-slate-50 border border-slate-200 hover:border-[#166D74] transition group shadow-sm h-full"
                    >
                      <Deletable id={`malaysia.sectorIcon.${idx}`} inline label={`সেক্টর আইকন ${idx + 1}`}>
                        <div className="w-12 h-12 rounded-xl bg-[#166D74] text-white flex items-center justify-center mb-3 transition font-black shadow-sm">
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                      </Deletable>
                      <h3 className="font-black text-slate-900 text-base mb-1 group-hover:text-[#166D74] transition">
                        <EditableText
                          id={`malaysia.secTitle.${idx}`}
                          label="সেক্টর টাইটেল"
                          value={lang === 'bn' ? sec.titleBn : sec.titleEn}
                          onSave={(val) => {
                            const newSec = [...content.malaysia.sectors];
                            if (lang === 'bn') newSec[idx].titleBn = val;
                            else newSec[idx].titleEn = val;
                            updateMalaysia({ sectors: newSec });
                          }}
                        />
                      </h3>
                      <div className="text-xs text-slate-600 font-medium leading-relaxed">
                        <EditableText
                          id={`malaysia.secDesc.${idx}`}
                          label="সেক্টর বিবরণ"
                          value={lang === 'bn' ? sec.descBn : sec.descEn}
                          onSave={(val) => {
                            const newSec = [...content.malaysia.sectors];
                            if (lang === 'bn') newSec[idx].descBn = val;
                            else newSec[idx].descEn = val;
                            updateMalaysia({ sectors: newSec });
                          }}
                        />
                      </div>
                    </div>
                  </Deletable>
                );
              })}
            </div>

            {/* Checklist highlights card */}
            <Deletable id="malaysia.guaranteesCard" label="নিশ্চয়ন কার্ড">
              <div className="p-6 rounded-2xl bg-slate-50 border border-[#166D74] text-slate-900 space-y-3 shadow-sm">
                <div className="flex items-center gap-2 text-[#166D74] font-black text-sm">
                  <Deletable id="malaysia.shieldIcon" inline label="শিল্ড আইকন">
                    <ShieldCheck className="w-5 h-5 text-[#166D74]" />
                  </Deletable>
                  <span>{lang === 'bn' ? 'মালয়েশিয়া প্রসেসিংয়ে আমাদের নিশ্চয়ন:' : 'Our Malaysia Guarantees:'}</span>
                </div>
                <div className="grid grid-cols-2 gap-3 text-xs text-slate-700 font-medium">
                  {content.malaysia.guaranteesBn.map((item, idx) => (
                    <Deletable key={idx} id={`malaysia.guarantee.${idx}`} label={`নিশ্চয়ন ${idx + 1}`}>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#166D74] shrink-0" />
                        <span>{lang === 'bn' ? item : content.malaysia.guaranteesEn[idx] || item}</span>
                      </div>
                    </Deletable>
                  ))}
                </div>
              </div>
            </Deletable>

          </div>

        </div>
      </div>
    </section>
  );
};
