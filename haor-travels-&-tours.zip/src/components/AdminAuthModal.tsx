import React, { useState, useEffect, useRef } from 'react';
import { 
  Lock, 
  KeyRound, 
  X, 
  AlertCircle, 
  CheckCircle2, 
  Eye, 
  EyeOff, 
  ShieldCheck 
} from 'lucide-react';
import { useContent } from '../context/ContentContext';

interface AdminAuthModalProps {
  lang: 'bn' | 'en';
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({ lang }) => {
  const { isAuthModalOpen, setIsAuthModalOpen, loginAdmin } = useContent();
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState(false);
  const [success, setSuccess] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isAuthModalOpen) {
      setPassword('');
      setError(false);
      setSuccess(false);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isAuthModalOpen]);

  if (!isAuthModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) {
      setError(true);
      return;
    }

    const ok = loginAdmin(password);
    if (ok) {
      setSuccess(true);
      setError(false);
      setTimeout(() => {
        setIsAuthModalOpen(false);
      }, 400);
    } else {
      setError(true);
      inputRef.current?.select();
    }
  };

  const handleClose = () => {
    setIsAuthModalOpen(false);
    setPassword('');
    setError(false);
    setSuccess(false);
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="admin-auth-title"
    >
      <div className="bg-white text-slate-900 rounded-3xl max-w-md w-full border-2 border-[#166D74] p-8 shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={handleClose}
          aria-label="Close dialog"
          className="absolute top-6 right-6 w-9 h-9 rounded-full bg-slate-100 border border-slate-300 hover:bg-[#166D74] hover:text-white text-slate-700 flex items-center justify-center transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Icon */}
        <div className="w-14 h-14 rounded-2xl bg-[#166D74] text-white flex items-center justify-center mb-5 shadow-lg shadow-[#166D74]/20">
          <KeyRound className="w-7 h-7 text-white stroke-[2.5]" />
        </div>

        {/* Title & Description */}
        <div className="space-y-2 mb-6">
          <span className="inline-block bg-slate-100 border border-slate-200 text-[#166D74] font-bold px-3 py-1 rounded-full text-xs uppercase tracking-wider">
            {lang === 'bn' ? 'এডমিন সিকিউরিটি লক' : 'Admin Security Access'}
          </span>
          <h3 id="admin-auth-title" className="text-2xl font-black text-slate-900">
            {lang === 'bn' ? 'এডমিন পাসওয়ার্ড প্রদান করুন' : 'Admin Password Required'}
          </h3>
          <p className="text-slate-600 text-xs leading-relaxed">
            {lang === 'bn'
              ? 'ওয়েবসাইটের কনটেন্ট, টিম ও সেকশন সম্পাদনা করতে শুধুমাত্র অনুমোদিত এডমিন পাসওয়ার্ড প্রদান করুন।'
              : 'Content editing and configuration are restricted. Enter the authorized admin password to unlock.'}
          </p>
        </div>

        {/* Password Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              {lang === 'bn' ? 'এডমিন পাসওয়ার্ড (Admin Password)' : 'Admin Password'}
            </label>
            <div className="relative">
              <input
                ref={inputRef}
                type={showPassword ? 'text' : 'password'}
                value={password}
                autoComplete="current-password"
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (error) setError(false);
                }}
                placeholder={lang === 'bn' ? 'গোপন পাসওয়ার্ড লিখুন...' : 'Enter admin password...'}
                className="w-full bg-slate-50 border-2 border-slate-300 focus:border-[#166D74] text-slate-900 font-mono text-base px-4 py-3.5 pr-12 rounded-xl focus:outline-none transition shadow-inner"
              />
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#166D74] cursor-pointer p-1"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>

            {error && (
              <p className="text-xs text-red-600 font-bold mt-2 flex items-center gap-1.5 animate-in fade-in">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                <span>
                  {lang === 'bn'
                    ? 'ভুল পাসওয়ার্ড! সঠিক এডমিন পাসওয়ার্ড প্রদান করুন।'
                    : 'Incorrect password! Please enter the correct admin password.'}
                </span>
              </p>
            )}

            {success && (
              <p className="text-xs text-[#166D74] font-bold mt-2 flex items-center gap-1.5 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-[#166D74]" />
                <span>{lang === 'bn' ? 'সফলভাবে আনলক হয়েছে! স্বাগতম এডমিন।' : 'Successfully unlocked! Welcome admin.'}</span>
              </p>
            )}
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={handleClose}
              className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 px-4 rounded-xl text-sm border border-slate-300 transition cursor-pointer"
            >
              {lang === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="flex-1 bg-[#166D74] hover:bg-[#0E585E] text-white font-black py-3 px-4 rounded-xl text-sm shadow-md transition cursor-pointer flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4 text-white" />
              <span>{lang === 'bn' ? 'আনলক করুন' : 'Unlock & Enter'}</span>
            </button>
          </div>
        </form>

        <div className="mt-6 pt-4 border-t border-slate-200 text-center">
          <p className="text-[11px] text-slate-500 font-medium">
            🔒 {lang === 'bn' ? 'হাওর ট্রাভেলস অ্যান্ড ট্যুরস • সুরক্ষিত এডমিন কন্ট্রোল' : 'Haor Travels & Tours • Secure Content Management'}
          </p>
        </div>
      </div>
    </div>
  );
};
