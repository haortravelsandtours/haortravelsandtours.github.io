import React from 'react';
import { 
  PhoneCall, 
  FileText, 
  ShieldCheck, 
  PlaneTakeoff, 
  Sparkles 
} from 'lucide-react';
import { PROCESS_STEPS } from '../data/content';
import { useContent } from '../context/ContentContext';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';

interface ProcessStepsProps {
  lang: 'bn' | 'en';
}

export const ProcessSteps: React.FC<ProcessStepsProps> = ({ lang }) => {
  const { content } = useContent();

  const hotlinePhone = content.numbers?.headerHotline?.phone || '01712431613';

  const getStepIcon = (iconName: string) => {
    switch (iconName) {
      case 'PhoneCall':
        return PhoneCall;
      case 'FileText':
        return FileText;
      case 'ShieldCheck':
        return ShieldCheck;
      case 'PlaneTakeoff':
        return PlaneTakeoff;
      default:
        return Sparkles;
    }
  };

  return (
    <section className="py-20 bg-white border-y border-slate-200 relative text-slate-900">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <Deletable id="steps.badge" label="ধাপসমূহ ব্যাজ">
            <span className="inline-block bg-[#166D74] text-white font-black px-4 py-1 rounded-full text-xs uppercase tracking-wider shadow-sm mb-3">
              {lang === 'bn' ? '৪টি সহজ ধাপ' : '4 Easy Steps'}
            </span>
          </Deletable>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">
            <EditableText
              id="steps.title"
              label="ধাপসমূহ টাইটেল"
              value={lang === 'bn' ? 'কীভাবে সেবা গ্রহণ করবেন' : 'How It Works (From Call to Flight)'}
              onSave={() => {}}
            />
          </h2>
          <div className="text-slate-600 mt-2 text-sm leading-relaxed">
            <EditableText
              id="steps.subtitle"
              label="ধাপসমূহ সাবটাইটেল"
              value={
                lang === 'bn'
                  ? 'কোনো জটিলতা ছাড়া সহজ ৪টি ধাপে সম্পন্ন করুন আপনার কাঙ্ক্ষিত ভিসা ও বিদেশ যাত্রা।'
                  : 'A transparent, stress-free 4-step roadmap to fulfill your international work and travel aspirations.'
              }
              onSave={() => {}}
            />
          </div>
        </div>

        {/* Steps Grid - Exactly 4 Columns on PC & Phone */}
        <div className="grid grid-cols-4 gap-6">
          {PROCESS_STEPS.map((step) => {
            const Icon = getStepIcon(step.icon);
            const isLast = step.step === 4;

            return (
              <Deletable key={step.step} id={`steps.card.${step.step}`} label={`ধাপ ${step.step} কার্ড`}>
                <div
                  className={`bg-slate-50 rounded-3xl p-6 shadow-sm border-2 relative flex flex-col justify-between text-center transition duration-300 h-full ${
                    isLast ? 'border-[#166D74] ring-2 ring-[#166D74]/20' : 'border-slate-200 hover:border-[#166D74]'
                  }`}
                >
                  {/* Step Number Circle */}
                  <div
                    className="w-14 h-14 mx-auto -mt-12 mb-5 rounded-2xl flex items-center justify-center font-black text-xl shadow-lg bg-[#166D74] text-white shadow-[#166D74]/20"
                  >
                    {step.step}
                  </div>

                  {/* Step content */}
                  <div className="space-y-3 mb-4">
                    <Deletable id={`steps.icon.${step.step}`} inline label={`ধাপ ${step.step} আইকন`}>
                      <div className="w-10 h-10 mx-auto rounded-xl bg-white text-[#166D74] border border-slate-200 shadow-sm flex items-center justify-center">
                        <Icon className="w-5 h-5 text-[#166D74]" />
                      </div>
                    </Deletable>
                    <h3 className="font-black text-lg text-slate-900">
                      {lang === 'bn' ? step.titleBn : step.titleEn}
                    </h3>
                    <p className="text-slate-600 text-xs leading-relaxed">
                      {lang === 'bn' ? step.descBn : step.descEn}
                    </p>
                  </div>

                  {/* Step sub-action */}
                  <div className="pt-3 border-t border-slate-200 text-[11px] font-bold text-[#166D74]">
                    {step.step === 1 && (
                      <a href={`tel:${hotlinePhone}`} className="hover:underline">
                        কল: {hotlinePhone}
                      </a>
                    )}
                    {step.step === 2 && <span>সরাসরি অফিস বা অনলাইনে</span>}
                    {step.step === 3 && <span>বায়োমেট্রিক ও অনুমোদন</span>}
                    {step.step === 4 && <span className="text-[#166D74]">শুভ নিরাপদ যাত্রা!</span>}
                  </div>
                </div>
              </Deletable>
            );
          })}
        </div>

      </div>
    </section>
  );
};
