import React, { useState, useRef } from 'react';
import { 
  X, 
  Save, 
  Plus, 
  Trash2, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  Building2, 
  Briefcase, 
  Users, 
  HelpCircle, 
  Image as ImageIcon, 
  Sliders, 
  Download, 
  Upload, 
  RotateCcw,
  Sparkles,
  ChevronUp,
  ChevronDown,
  Phone,
  MessageCircle,
  Type,
  Link2,
  FileText,
  Copy,
  Check,
  ExternalLink
} from 'lucide-react';
import { useContent, SectionVisibility } from '../context/ContentContext';

interface AdminDrawerProps {
  lang: 'bn' | 'en';
}

export const AdminDrawer: React.FC<AdminDrawerProps> = ({ lang }) => {
  const { 
    content, 
    isAdminOpen, 
    setIsAdminOpen,
    updateAgencyInfo,
    updateHeaderHotline,
    updateHeaderWhatsApp,
    updateFloatingWhatsApp,
    updateContactPageNumbers,
    updateFooterNumbers,
    isDeleted,
    deleteItem,
    restoreItem,
    restoreAllItems,
    deletedCount,
    deletedKeys,
    updateHero,
    updateMalaysia,
    updateService,
    addService,
    deleteService,
    updateTeamMember,
    addTeamMember,
    deleteTeamMember,
    moveTeamMember,
    updateWhyUs,
    updateFaq,
    addFaq,
    deleteFaq,
    updateGalleryItem,
    addGalleryItem,
    deleteGalleryItem,
    toggleSectionVisibility,
    updateTypography,
    addNavLink,
    updateNavLink,
    deleteNavLink,
    moveNavLink,
    addFooterLink,
    updateFooterLink,
    deleteFooterLink,
    uploadFile,
    deleteFile,
    resetToDefaults,
    exportContentJson,
    importContentJson
  } = useContent();

  const [activeTab, setActiveTab] = useState<
    'general' | 'numbers' | 'deleted' | 'hero' | 'malaysia' | 'services' | 'team' | 'whyUs' | 'gallery' | 'faqs' | 'typography' | 'links' | 'files' | 'visibility' | 'backup'
  >('numbers');

  const [importText, setImportText] = useState('');
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Link form state
  const [newLinkTarget, setNewLinkTarget] = useState<'header' | 'footer'>('header');
  const [newLinkLabelBn, setNewLinkLabelBn] = useState('');
  const [newLinkLabelEn, setNewLinkLabelEn] = useState('');
  const [newLinkUrl, setNewLinkUrl] = useState('');
  const [newLinkIsExternal, setNewLinkIsExternal] = useState(false);
  const [linkSuccess, setLinkSuccess] = useState<string | null>(null);

  // File upload state
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isAdminOpen) return null;

  const tabs = [
    { id: 'numbers', labelBn: 'ফোন ও WhatsApp (আলাদা)', labelEn: 'Separate Numbers', icon: Phone },
    { id: 'deleted', labelBn: `মুছে ফেলা (${deletedCount})`, labelEn: `Deleted (${deletedCount})`, icon: Trash2 },
    { id: 'general', labelBn: 'সাধারণ তথ্য', labelEn: 'General Info', icon: Building2 },
    { id: 'typography', labelBn: 'টেক্সট ও ফন্ট', labelEn: 'Text & Fonts', icon: Type },
    { id: 'links', labelBn: 'লিংক ম্যানেজার', labelEn: 'Link Manager', icon: Link2 },
    { id: 'files', labelBn: 'ফাইল ও ডিলিট', labelEn: 'Files & Delete', icon: FileText },
    { id: 'hero', labelBn: 'হিরো ও হেডলাইন', labelEn: 'Hero & Title', icon: Sparkles },
    { id: 'malaysia', labelBn: 'মালয়েশিয়া স্পেশাল', labelEn: 'Malaysia Section', icon: Sliders },
    { id: 'services', labelBn: 'সেবাসমূহ', labelEn: 'Services (5)', icon: Briefcase },
    { id: 'team', labelBn: 'টিম ও পরিচালক', labelEn: 'Team Members', icon: Users },
    { id: 'whyUs', labelBn: 'কেন আমরা', labelEn: 'Why Choose Us', icon: CheckCircle2 },
    { id: 'gallery', labelBn: 'ফটো গ্যালারি', labelEn: 'Photo Gallery', icon: ImageIcon },
    { id: 'faqs', labelBn: 'প্রশ্নোত্তর (FAQ)', labelEn: 'FAQs', icon: HelpCircle },
    { id: 'visibility', labelBn: 'সেকশন হাইড/শো', labelEn: 'Visibility', icon: Eye },
    { id: 'backup', labelBn: 'ব্যাকআপ ও রিস্টোর', labelEn: 'Backup / Reset', icon: Download },
  ];

  const handleImport = () => {
    if (!importText.trim()) return;
    const ok = importContentJson(importText);
    if (ok) {
      setImportStatus(lang === 'bn' ? 'সফলভাবে ইমপোর্ট সম্পন্ন হয়েছে!' : 'Import successful!');
      setImportText('');
    } else {
      setImportStatus(lang === 'bn' ? 'ভুল JSON ফরম্যাট, অনুগ্রহ করে সঠিক ফরম্যাট দিন।' : 'Invalid JSON format.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-sm flex justify-end animate-in fade-in duration-200">
      <div 
        className="w-full max-w-4xl bg-slate-950 border-l-2 border-[#166D74] text-white h-full flex flex-col shadow-2xl relative"
        role="dialog"
        aria-modal="true"
        aria-labelledby="admin-drawer-title"
      >
        {/* Drawer Header */}
        <div className="p-6 border-b-2 border-slate-800 flex items-center justify-between bg-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#166D74] text-white flex items-center justify-center font-black">
              ⚙️
            </div>
            <div>
              <h2 id="admin-drawer-title" className="text-xl font-black text-white">
                {lang === 'bn' ? 'ওয়েবসাইট ম্যানুয়াল এডিটর ও কনটেন্ট প্যানেল' : 'Live Website Content Manager'}
              </h2>
              <p className="text-xs text-[#166D74] font-bold">
                {lang === 'bn' ? 'সব তথ্য সম্পাদনা করুন — রিয়েল-টাইমে সেভ হবে' : 'Edit any section — Changes save in real-time'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-400 mr-2">
              <span className="text-[#166D74]">●</span> Official Seal &amp; White Theme
            </span>
            <button
              onClick={() => setIsAdminOpen(false)}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 transition cursor-pointer"
              aria-label="Close admin drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 px-6 py-3 border-b border-slate-800 bg-slate-950 overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold shrink-0 flex items-center gap-2 transition cursor-pointer ${
                  isActive
                    ? 'bg-[#166D74] text-white shadow-md font-black'
                    : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-[#166D74]'}`} />
                <span>{lang === 'bn' ? tab.labelBn : tab.labelEn}</span>
              </button>
            );
          })}
        </div>

        {/* Drawer Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* 0.1. SEPARATE NUMBERS MANAGEMENT (HEADER HOTLINE, FLOATING WHATSAPP, CONTACT PAGE, FOOTER) */}
          {activeTab === 'numbers' && (
            <div className="space-y-6">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-black text-[#166D74] flex items-center gap-2">
                    <Phone className="w-5 h-5 text-[#166D74]" />
                    <span>{lang === 'bn' ? 'ফোন ও WhatsApp নম্বরের পৃথক সেটিংস' : 'Independent Numbers Settings'}</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {lang === 'bn' 
                      ? 'প্রতিটি নম্বর সম্পূর্ণ আলাদা ও স্বাধীন। একটি পরিবর্তন করলে অন্যটি কখনোই পরিবর্তন হবে না।' 
                      : 'Each number is completely independent. Changing Hotline never alters WhatsApp, and vice-versa.'}
                  </p>
                </div>
                <span className="text-xs font-black bg-[#166D74] text-white px-3 py-1 rounded-full">
                  ৪টি পৃথক সেটিং
                </span>
              </div>

              {/* 1. Header Hotline Number */}
              <div className="p-5 bg-slate-900 border-2 border-[#166D74] rounded-2xl space-y-3 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-[#166D74] text-white flex items-center justify-center">
                      <Phone className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-white">
                        {lang === 'bn' ? '১. হেডার হটলাইন নম্বর (Header Hotline Number)' : '1. Header Hotline Number'}
                      </h4>
                      <p className="text-[11px] text-slate-400">ওয়েবসাইটের শীর্ষ হেডার বারে প্রদর্শিত হটলাইন কল নম্বর</p>
                    </div>
                  </div>
                  <span className="text-[11px] bg-slate-800 text-[#166D74] font-bold px-2 py-0.5 rounded border border-slate-700">
                    স্বাধীন নম্বর
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      হটলাইন ফোন নম্বর (Hotline Phone)
                    </label>
                    <input
                      type="text"
                      value={content.numbers?.headerHotline?.phone || ''}
                      onChange={(e) => updateHeaderHotline({ phone: e.target.value })}
                      placeholder="01712431613"
                      className="w-full bg-slate-950 border border-slate-700 focus:border-[#166D74] text-white font-mono font-bold p-2.5 rounded-xl text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      লেবেল (বাংলা)
                    </label>
                    <input
                      type="text"
                      value={content.numbers?.headerHotline?.labelBn || ''}
                      onChange={(e) => updateHeaderHotline({ labelBn: e.target.value })}
                      placeholder="হটলাইন"
                      className="w-full bg-slate-950 border border-slate-700 focus:border-[#166D74] text-white p-2.5 rounded-xl text-sm"
                    />
                  </div>
                </div>
                <p className="text-[11px] text-[#166D74] font-semibold">
                  ✓ এই নম্বর পরিবর্তন করলে WhatsApp নম্বরে কোনো প্রভাব পড়বে না।
                </p>
              </div>

              {/* 2. Floating WhatsApp Number */}
              <div className="p-5 bg-slate-900 border-2 border-[#166D74] rounded-2xl space-y-3 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-[#166D74] text-white flex items-center justify-center">
                      <MessageCircle className="w-4 h-4 fill-white text-white" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-white">
                        {lang === 'bn' ? '২. ভাসমান WhatsApp নম্বর (Floating WhatsApp Number)' : '2. Floating WhatsApp Number'}
                      </h4>
                      <p className="text-[11px] text-slate-400">স্ক্রিনের নিচে ডানপাশে ভাসমান WhatsApp আইকন ও চ্যাট বাটন</p>
                    </div>
                  </div>
                  <span className="text-[11px] bg-slate-800 text-[#166D74] font-bold px-2 py-0.5 rounded border border-slate-700">
                    স্বাধীন নম্বর
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      WhatsApp মোবাইল নম্বর (019...)
                    </label>
                    <input
                      type="text"
                      value={content.numbers?.floatingWhatsApp?.phone || ''}
                      onChange={(e) => updateFloatingWhatsApp({ phone: e.target.value })}
                      placeholder="01914484627"
                      className="w-full bg-slate-950 border border-slate-700 focus:border-[#166D74] text-white font-mono font-bold p-2.5 rounded-xl text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      টুলটিপ লেবেল (বাংলা)
                    </label>
                    <input
                      type="text"
                      value={content.numbers?.floatingWhatsApp?.labelBn || ''}
                      onChange={(e) => updateFloatingWhatsApp({ labelBn: e.target.value })}
                      placeholder="সরাসরি WhatsApp-এ কথা বলুন"
                      className="w-full bg-slate-950 border border-slate-700 focus:border-[#166D74] text-white p-2.5 rounded-xl text-sm"
                    />
                  </div>
                </div>
                <p className="text-[11px] text-[#166D74] font-semibold">
                  ✓ এই নম্বর পরিবর্তন করলে হটলাইন নম্বরে কোনো প্রভাব পড়বে না।
                </p>
              </div>

              {/* 3. Contact Page Number */}
              <div className="p-5 bg-slate-900 border-2 border-[#166D74] rounded-2xl space-y-3 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-[#166D74] text-white flex items-center justify-center">
                      <Building2 className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-white">
                        {lang === 'bn' ? '৩. যোগাযোগ পেইজের নিজস্ব নম্বর (Contact Page Numbers)' : '3. Contact Page Numbers'}
                      </h4>
                      <p className="text-[11px] text-slate-400">যোগাযোগ সেকশনের অফিসিয়াল ফোন ও হোয়াটসঅ্যাপ চ্যাট বাটন</p>
                    </div>
                  </div>
                  <span className="text-[11px] bg-slate-800 text-[#166D74] font-bold px-2 py-0.5 rounded border border-slate-700">
                    স্বাধীন নম্বর
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      যোগাযোগ পেইজ ফোন নম্বর
                    </label>
                    <input
                      type="text"
                      value={content.numbers?.contactPage?.phone || ''}
                      onChange={(e) => updateContactPageNumbers({ phone: e.target.value })}
                      placeholder="01712431613"
                      className="w-full bg-slate-950 border border-slate-700 focus:border-[#166D74] text-white font-mono font-bold p-2.5 rounded-xl text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      যোগাযোগ পেইজ WhatsApp নম্বর
                    </label>
                    <input
                      type="text"
                      value={content.numbers?.contactPage?.whatsappPhone || ''}
                      onChange={(e) => updateContactPageNumbers({ whatsappPhone: e.target.value })}
                      placeholder="01914484627"
                      className="w-full bg-slate-950 border border-slate-700 focus:border-[#166D74] text-white font-mono font-bold p-2.5 rounded-xl text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* 4. Footer Number */}
              <div className="p-5 bg-slate-900 border-2 border-[#166D74] rounded-2xl space-y-3 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-[#166D74] text-white flex items-center justify-center">
                      <Phone className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-white">
                        {lang === 'bn' ? '৪. ফুটার হেল্পলাইন নম্বর (Footer Number)' : '4. Footer Number'}
                      </h4>
                      <p className="text-[11px] text-slate-400">ফুটার এরিয়ায় প্রদর্শিত নিজস্ব জরুরি সহায়তা নম্বর</p>
                    </div>
                  </div>
                  <span className="text-[11px] bg-slate-800 text-[#166D74] font-bold px-2 py-0.5 rounded border border-slate-700">
                    স্বাধীন নম্বর
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      ফুটার ফোন নম্বর (Footer Phone)
                    </label>
                    <input
                      type="text"
                      value={content.numbers?.footerNumber?.phone || ''}
                      onChange={(e) => updateFooterNumbers({ phone: e.target.value })}
                      placeholder="01712431613"
                      className="w-full bg-slate-950 border border-slate-700 focus:border-[#166D74] text-white font-mono font-bold p-2.5 rounded-xl text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 uppercase mb-1">
                      লেবেল (বাংলা)
                    </label>
                    <input
                      type="text"
                      value={content.numbers?.footerNumber?.labelBn || ''}
                      onChange={(e) => updateFooterNumbers({ labelBn: e.target.value })}
                      placeholder="ফুটার জরুরি সহায়তা নম্বর"
                      className="w-full bg-slate-950 border border-slate-700 focus:border-[#166D74] text-white p-2.5 rounded-xl text-sm"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 0.2. DELETED ITEMS MANAGER */}
          {activeTab === 'deleted' && (
            <div className="space-y-6">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-black text-red-400 flex items-center gap-2">
                    <Trash2 className="w-5 h-5 text-red-400" />
                    <span>{lang === 'bn' ? 'মুছে ফেলা উপাদানসমূহ (Deleted Elements)' : 'Deleted Elements'}</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {lang === 'bn' 
                      ? 'ওয়েবসাইট থেকে ডিলিট করা কোনো টেক্সট বা আইকন চাইলে এখান থেকে এক ক্লিকে রিস্টোর (পুনরুদ্ধার) করতে পারবেন।' 
                      : 'Every individually removed item can be previewed and restored here at any time.'}
                  </p>
                </div>
                {deletedCount > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm('আপনি কি মুছে ফেলা সব উপাদান পুনরুদ্ধার করতে চান?')) {
                        restoreAllItems();
                      }
                    }}
                    className="px-4 py-2 bg-[#166D74] hover:bg-[#0E585E] text-white font-black text-xs rounded-xl shadow transition cursor-pointer flex items-center gap-1.5"
                  >
                    <RotateCcw className="w-4 h-4 text-white" />
                    <span>সব পুনরুদ্ধার করুন (Restore All)</span>
                  </button>
                )}
              </div>

              {deletedCount === 0 ? (
                <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-[#166D74] mx-auto" />
                  <p className="text-white font-bold text-sm">
                    {lang === 'bn' ? 'বর্তমানে কোনো উপাদান মুছে ফেলা নেই।' : 'No elements are currently deleted.'}
                  </p>
                  <p className="text-xs text-slate-400">
                    {lang === 'bn' 
                      ? 'এডিট মোডে যে কোনো টেক্সট বা আইকনের পাশের লাল (×) বাটনে ক্লিক করে ডিলিট করা যায়।' 
                      : 'Use the red (×) button on any item in Edit Mode to remove it individually.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="text-xs text-slate-400">
                    মোট মুছে ফেলা উপাদান: <strong className="text-red-400">{deletedCount}</strong> টি
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    {deletedKeys.map((key) => (
                      <div 
                        key={key}
                        className="p-3.5 bg-slate-900 border border-red-500/30 rounded-xl flex items-center justify-between gap-3 shadow-sm"
                      >
                        <div className="overflow-hidden">
                          <span className="text-xs font-mono font-bold text-red-300 block truncate">
                            {key}
                          </span>
                          <span className="text-[10px] text-slate-500">
                            মুছে ফেলা উপাদান
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => restoreItem(key)}
                          className="px-3 py-1.5 bg-[#166D74] hover:bg-[#0E585E] text-white font-black text-xs rounded-lg transition cursor-pointer shrink-0 flex items-center gap-1 shadow"
                        >
                          <RotateCcw className="w-3 h-3 text-white" />
                          <span>ফিরিয়ে আনুন</span>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 1. GENERAL AGENCY INFO */}
          {activeTab === 'general' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-3">
                <h3 className="text-lg font-black text-yellow-400">
                  {lang === 'bn' ? 'সাধারণ ও এজেন্সির মূল তথ্য' : 'Agency Master Information'}
                </h3>
                <p className="text-xs text-neutral-400">
                  {lang === 'bn' ? 'হটলাইন, হোয়াটসঅ্যাপ, ঠিকানা ও অফিস সময় পরিবর্তন করুন' : 'Update hotline, WhatsApp, address & hours'}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'এজেন্সির নাম (বাংলা)' : 'Agency Name (Bengali)'}
                  </label>
                  <input
                    type="text"
                    value={content.agencyInfo.nameBn}
                    onChange={(e) => updateAgencyInfo({ nameBn: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'এজেন্সির নাম (English)' : 'Agency Name (English)'}
                  </label>
                  <input
                    type="text"
                    value={content.agencyInfo.name}
                    onChange={(e) => updateAgencyInfo({ name: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>

                <div className="col-span-2 p-3 bg-slate-900 border border-[#166D74]/40 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-[#166D74] flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-[#166D74]" />
                      <span>{lang === 'bn' ? 'ফোন ও WhatsApp নম্বর পৃথক সেটিংস' : 'Separate Phone & WhatsApp Settings'}</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setActiveTab('numbers')}
                      className="text-[11px] text-[#166D74] hover:underline font-bold"
                    >
                      {lang === 'bn' ? 'সবগুলো বিস্তারিত দেখুন →' : 'View All Details →'}
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-slate-400 block mb-0.5">১. হেডার হটলাইন:</span>
                      <input
                        type="text"
                        value={content.numbers?.headerHotline?.phone || ''}
                        onChange={(e) => updateHeaderHotline({ phone: e.target.value })}
                        placeholder="01712431613"
                        className="w-full bg-slate-950 border border-slate-700 focus:border-[#166D74] text-white font-mono p-1.5 rounded-lg text-xs"
                      />
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-0.5">২. ভাসমান WhatsApp:</span>
                      <input
                        type="text"
                        value={content.numbers?.floatingWhatsApp?.phone || ''}
                        onChange={(e) => updateFloatingWhatsApp({ phone: e.target.value })}
                        placeholder="01914484627"
                        className="w-full bg-slate-950 border border-slate-700 focus:border-[#166D74] text-white font-mono p-1.5 rounded-lg text-xs"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'প্রতিষ্ঠিত সাল' : 'Established Year'}
                  </label>
                  <input
                    type="number"
                    value={content.agencyInfo.established}
                    onChange={(e) => updateAgencyInfo({ established: Number(e.target.value) })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'অভিজ্ঞতার বছর' : 'Years Experience'}
                  </label>
                  <input
                    type="number"
                    value={content.agencyInfo.yearsOfExperience}
                    onChange={(e) => updateAgencyInfo({ yearsOfExperience: Number(e.target.value) })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'প্রধান কার্যালয়ের ঠিকানা (বাংলা)' : 'Office Address (Bengali)'}
                  </label>
                  <input
                    type="text"
                    value={content.agencyInfo.addressBn}
                    onChange={(e) => updateAgencyInfo({ addressBn: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'প্রধান কার্যালয়ের ঠিকানা (English)' : 'Office Address (English)'}
                  </label>
                  <input
                    type="text"
                    value={content.agencyInfo.address}
                    onChange={(e) => updateAgencyInfo({ address: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'অফিস সময় (বাংলা)' : 'Working Hours (Bengali)'}
                  </label>
                  <input
                    type="text"
                    value={content.agencyInfo.openingHoursBn}
                    onChange={(e) => updateAgencyInfo({ openingHoursBn: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'অফিস সময় (English)' : 'Working Hours (English)'}
                  </label>
                  <input
                    type="text"
                    value={content.agencyInfo.openingHoursEn}
                    onChange={(e) => updateAgencyInfo({ openingHoursEn: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>
              </div>
            </div>
          )}

          {/* 1.1. TEXT & FONTS CUSTOMIZATION */}
          {activeTab === 'typography' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-black text-yellow-400">
                    {lang === 'bn' ? 'টেক্সট ও ফন্ট কাস্টমাইজেশন (Text & Fonts)' : 'Typography & Font Settings'}
                  </h3>
                  <p className="text-xs text-neutral-400">
                    {lang === 'bn' ? 'ওয়েবসাইটের বাংলা ও ইংরেজি ফন্ট এবং লেখার সাইজ পরিবর্তন করুন' : 'Change Bengali/English font families and text scaling'}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    updateTypography({
                      fontFamilyBn: 'Hind Siliguri',
                      fontFamilyEn: 'Inter',
                      sizeScale: 'standard',
                      letterSpacing: 'normal',
                    });
                  }}
                  className="px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-yellow-400 border border-neutral-700 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-yellow-400" />
                  <span>{lang === 'bn' ? 'ডিফল্ট ফন্ট' : 'Reset Fonts'}</span>
                </button>
              </div>

              {/* Bangla Font Family Selection */}
              <div className="p-5 bg-neutral-950 border-2 border-neutral-800 rounded-2xl space-y-3">
                <label className="block text-xs font-black text-yellow-400 uppercase tracking-wider">
                  ১. বাংলা ফন্ট পরিবার (Bengali Font Family)
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    {
                      id: 'Hind Siliguri',
                      nameBn: 'হিন্দ শিলিগুড়ি (ডিফল্ট)',
                      nameEn: 'Hind Siliguri (Modern Clean)',
                      preview: 'হাওর ট্রাভেলস সুনামগঞ্জ'
                    },
                    {
                      id: 'Noto Sans Bengali',
                      nameBn: 'নোতো সান্স বাংলা',
                      nameEn: 'Noto Sans Bengali (Geometric)',
                      preview: 'মালয়েশিয়া ভিসা ও টিকিট'
                    },
                    {
                      id: 'Tiro Bangla',
                      nameBn: 'তিরো বাংলা',
                      nameEn: 'Tiro Bangla (Editorial Serif)',
                      preview: '১৭+ বছরের বিশ্বস্ত প্রতিষ্ঠান'
                    }
                  ].map((font) => {
                    const isSelected = (content.typography?.fontFamilyBn || 'Hind Siliguri') === font.id;
                    return (
                      <button
                        key={font.id}
                        type="button"
                        onClick={() => updateTypography({ fontFamilyBn: font.id })}
                        className={`p-3.5 rounded-xl border-2 text-left transition cursor-pointer flex flex-col justify-between ${
                          isSelected
                            ? 'bg-yellow-400 text-black border-yellow-400 shadow-md font-bold'
                            : 'bg-neutral-900 text-white border-neutral-700 hover:border-yellow-400/50'
                        }`}
                        style={{ fontFamily: font.id }}
                      >
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-black">{font.nameBn}</span>
                            {isSelected && <Check className="w-4 h-4 text-black stroke-[3]" />}
                          </div>
                          <p className={`text-[11px] ${isSelected ? 'text-neutral-900' : 'text-neutral-400'}`}>
                            {font.nameEn}
                          </p>
                        </div>
                        <p className="mt-2 text-sm font-semibold truncate">
                          {font.preview}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* English Font Family Selection */}
              <div className="p-5 bg-neutral-950 border-2 border-neutral-800 rounded-2xl space-y-3">
                <label className="block text-xs font-black text-yellow-400 uppercase tracking-wider">
                  ২. ইংরেজি ও সংখ্যা ফন্ট (English & Numerics Font)
                </label>
                <div className="grid grid-cols-4 gap-3">
                  {[
                    { id: 'Inter', name: 'Inter', desc: 'Standard Clean' },
                    { id: 'Poppins', name: 'Poppins', desc: 'Bold Geometric' },
                    { id: 'Roboto', name: 'Roboto', desc: 'Classic Tech' },
                    { id: 'Outfit', name: 'Outfit', desc: 'Sharp Modern' },
                  ].map((font) => {
                    const isSelected = (content.typography?.fontFamilyEn || 'Inter') === font.id;
                    return (
                      <button
                        key={font.id}
                        type="button"
                        onClick={() => updateTypography({ fontFamilyEn: font.id })}
                        className={`p-3 rounded-xl border-2 text-left transition cursor-pointer ${
                          isSelected
                            ? 'bg-yellow-400 text-black border-yellow-400 font-bold shadow-md'
                            : 'bg-neutral-900 text-white border-neutral-700 hover:border-yellow-400/50'
                        }`}
                        style={{ fontFamily: font.id }}
                      >
                        <div className="flex items-center justify-between mb-0.5">
                          <span className="text-sm font-black">{font.name}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-black stroke-[3]" />}
                        </div>
                        <p className={`text-[11px] ${isSelected ? 'text-neutral-900' : 'text-neutral-400'}`}>
                          {font.desc}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Font Size Scaling */}
              <div className="p-5 bg-neutral-950 border-2 border-neutral-800 rounded-2xl space-y-3">
                <label className="block text-xs font-black text-yellow-400 uppercase tracking-wider">
                  ৩. লেখার সামগ্রিক সাইজ স্কেল (Font Size Scale)
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: 'compact', labelBn: 'কমপ্যাক্ট (Compact 95%)', desc: 'স্ক্রিনে একসাথে বেশি লেখা দেখা যাবে' },
                    { id: 'standard', labelBn: 'স্ট্যান্ডার্ড (Standard 100%)', desc: 'আদর্শ ও স্বাভাবিক সাইজ' },
                    { id: 'large', labelBn: 'লার্জ (Large 105%)', desc: 'বড় ও স্পষ্ট ফন্ট সাইজ' },
                  ].map((scale) => {
                    const isSelected = (content.typography?.sizeScale || 'standard') === scale.id;
                    return (
                      <button
                        key={scale.id}
                        type="button"
                        onClick={() => updateTypography({ sizeScale: scale.id as any })}
                        className={`p-3 rounded-xl border-2 text-left transition cursor-pointer ${
                          isSelected
                            ? 'bg-yellow-400 text-black border-yellow-400 font-bold shadow-md'
                            : 'bg-neutral-900 text-white border-neutral-700 hover:border-yellow-400/50'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-0.5">
                          <span className="text-xs font-black">{scale.labelBn}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-black stroke-[3]" />}
                        </div>
                        <p className={`text-[11px] ${isSelected ? 'text-neutral-900' : 'text-neutral-400'}`}>
                          {scale.desc}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Real-time Font Preview Sandbox */}
              <div className="p-5 bg-black border-2 border-yellow-400 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-yellow-400 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
                    <span>লাইভ ফন্ট প্রিভিউ (Live Preview)</span>
                  </span>
                  <span className="text-[11px] text-neutral-400">
                    বর্তমান ফন্ট: <strong className="text-white">{content.typography?.fontFamilyBn || 'Hind Siliguri'}</strong> &amp; <strong className="text-white">{content.typography?.fontFamilyEn || 'Inter'}</strong>
                  </span>
                </div>

                <div 
                  className="p-4 bg-neutral-950 border border-neutral-800 rounded-xl space-y-2"
                  style={{
                    fontFamily: `'${content.typography?.fontFamilyBn || 'Hind Siliguri'}', '${content.typography?.fontFamilyEn || 'Inter'}', sans-serif`,
                    fontSize: content.typography?.sizeScale === 'compact' ? '15px' : content.typography?.sizeScale === 'large' ? '17px' : '16px'
                  }}
                >
                  <h4 className="text-xl font-black text-white">
                    হাওর ট্রাভেলস অ্যান্ড ট্যুরস — EST. 2008 (Sunamganj)
                  </h4>
                  <p className="text-yellow-400 font-bold text-sm">
                    মালয়েশিয়া ওয়ার্ক পারমিট, কলিং ভিসা ও এয়ার টিকেটের নির্ভরযোগ্য ঠিকানা
                  </p>
                  <p className="text-neutral-300 text-xs leading-relaxed">
                    আমরা মানুষকে কাজ, পড়াশোনা এবং ভ্রমণের জন্য বিদেশে পাঠিয়ে থাকি। সুনামগঞ্জের ষোলঘর পয়েন্ট থেকে সমগ্র বাংলাদেশের সেবা।
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 1.2. MANUAL LINK ADD & LINK MANAGER */}
          {activeTab === 'links' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-3">
                <h3 className="text-lg font-black text-yellow-400">
                  {lang === 'bn' ? 'ম্যানুয়ালি লিংক যোগ ও পরিচালনা (Manual Link Manager)' : 'Manual Link Manager'}
                </h3>
                <p className="text-xs text-neutral-400">
                  {lang === 'bn' ? 'হেডার ও ফুটার মেনুর লিংক ম্যানুয়ালি যোগ, পরিবর্তন বা ডিলিট করুন' : 'Add custom links, modify URLs or delete existing navigation items'}
                </p>
              </div>

              {/* Add New Link Card */}
              <div className="p-5 bg-neutral-950 border-2 border-yellow-400 rounded-2xl space-y-4 shadow-lg">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <Plus className="w-4 h-4 text-yellow-400" />
                    <span>+ নতুন লিংক ম্যানুয়ালি যোগ করুন (Add Custom Link)</span>
                  </h4>
                  <span className="text-xs bg-yellow-400 text-black px-2 py-0.5 rounded font-black">
                    নতুন লিংক
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                      কোথায় যোগ করবেন? (Target Location)
                    </label>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setNewLinkTarget('header')}
                        className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer border ${
                          newLinkTarget === 'header'
                            ? 'bg-yellow-400 text-black border-yellow-400'
                            : 'bg-neutral-900 text-neutral-300 border-neutral-700'
                        }`}
                      >
                        হেডার মেনু (Top Nav)
                      </button>
                      <button
                        type="button"
                        onClick={() => setNewLinkTarget('footer')}
                        className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer border ${
                          newLinkTarget === 'footer'
                            ? 'bg-yellow-400 text-black border-yellow-400'
                            : 'bg-neutral-900 text-neutral-300 border-neutral-700'
                        }`}
                      >
                        ফুটার লিংক (Footer)
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                      লিংকের নাম বাংলা (Label BN) *
                    </label>
                    <input
                      type="text"
                      value={newLinkLabelBn}
                      onChange={(e) => setNewLinkLabelBn(e.target.value)}
                      placeholder="যেমন: জরুরি নোটিশ / অফার"
                      className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2 rounded-xl text-xs font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                      লিংকের নাম English (Label EN)
                    </label>
                    <input
                      type="text"
                      value={newLinkLabelEn}
                      onChange={(e) => setNewLinkLabelEn(e.target.value)}
                      placeholder="e.g. Special Offer / Notices"
                      className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2 rounded-xl text-xs font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                      লিংক URL (Destination) *
                    </label>
                    <input
                      type="text"
                      value={newLinkUrl}
                      onChange={(e) => {
                        const val = e.target.value;
                        setNewLinkUrl(val);
                        if (val.startsWith('http')) setNewLinkIsExternal(true);
                      }}
                      placeholder="যেমন: #services বা https://wa.me/..."
                      className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-yellow-400 p-2 rounded-xl text-xs font-mono font-bold"
                    />
                  </div>
                </div>

                {/* Quick Shortcuts for Link URL */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[10px] text-neutral-400 font-bold">কুইক সেকশন লিংক:</span>
                  {['#home', '#malaysia', '#services', '#checker', '#why-us', '#team', '#gallery', '#contact'].map((sec) => (
                    <button
                      key={sec}
                      type="button"
                      onClick={() => setNewLinkUrl(sec)}
                      className="px-2 py-0.5 rounded bg-neutral-900 hover:bg-yellow-400 hover:text-black text-neutral-300 text-[11px] font-mono border border-neutral-800 transition"
                    >
                      {sec}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => {
                      setNewLinkUrl(content.agencyInfo.whatsappLink);
                      setNewLinkIsExternal(true);
                    }}
                    className="px-2 py-0.5 rounded bg-neutral-900 hover:bg-yellow-400 hover:text-black text-yellow-400 text-[11px] border border-neutral-800 transition"
                  >
                    WhatsApp Link
                  </button>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-neutral-300">
                    <input
                      type="checkbox"
                      checked={newLinkIsExternal}
                      onChange={(e) => setNewLinkIsExternal(e.target.checked)}
                      className="w-4 h-4 accent-yellow-400"
                    />
                    <span>নতুন উইন্ডোতে খুলুন (Open in new tab / external)</span>
                  </label>

                  <button
                    type="button"
                    onClick={() => {
                      if (!newLinkLabelBn.trim()) {
                        alert('অনুগ্রহ করে লিংকের নাম দিন (Please enter link label)');
                        return;
                      }
                      if (!newLinkUrl.trim()) {
                        alert('অনুগ্রহ করে লিংক URL দিন (Please enter link URL)');
                        return;
                      }

                      const id = `link-${Date.now()}`;
                      const item = {
                        id,
                        labelBn: newLinkLabelBn.trim(),
                        labelEn: newLinkLabelEn.trim() || newLinkLabelBn.trim(),
                        url: newLinkUrl.trim(),
                        isExternal: newLinkIsExternal
                      };

                      if (newLinkTarget === 'header') {
                        addNavLink(item);
                      } else {
                        addFooterLink(item);
                      }

                      setNewLinkLabelBn('');
                      setNewLinkLabelEn('');
                      setNewLinkUrl('');
                      setLinkSuccess(`লিংক "${item.labelBn}" সফলভাবে যুক্ত হয়েছে!`);
                      setTimeout(() => setLinkSuccess(null), 3000);
                    }}
                    className="px-5 py-2 bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs rounded-xl shadow transition cursor-pointer flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4 text-black stroke-[3]" />
                    <span>+ লিংক যোগ করুন (Save Link)</span>
                  </button>
                </div>

                {linkSuccess && (
                  <p className="text-xs text-yellow-400 font-bold bg-neutral-900 p-2 rounded-lg border border-yellow-400/40">
                    {linkSuccess}
                  </p>
                )}
              </div>

              {/* Header Navigation Links List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <Link2 className="w-4 h-4 text-yellow-400" />
                    <span>হেডার মেনুর লিংকসমূহ ({content.navLinks?.length || 0})</span>
                  </h4>
                  <span className="text-[11px] text-neutral-400">রিয়াররেঞ্জ করতে তীর চিহ্ন ব্যবহার করুন</span>
                </div>

                <div className="space-y-2">
                  {(content.navLinks || []).map((link, idx) => (
                    <div 
                      key={link.id} 
                      className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl flex items-center gap-3 hover:border-neutral-700 transition"
                    >
                      <span className="w-6 h-6 rounded-md bg-yellow-400 text-black font-black text-xs flex items-center justify-center shrink-0">
                        {idx + 1}
                      </span>

                      <div className="flex-1 grid grid-cols-3 gap-2">
                        <input
                          type="text"
                          value={link.labelBn}
                          onChange={(e) => updateNavLink(link.id, { labelBn: e.target.value })}
                          placeholder="বাংলা নাম"
                          className="bg-neutral-900 border border-neutral-700 text-white px-2.5 py-1.5 rounded-lg text-xs font-bold"
                        />
                        <input
                          type="text"
                          value={link.labelEn}
                          onChange={(e) => updateNavLink(link.id, { labelEn: e.target.value })}
                          placeholder="English Label"
                          className="bg-neutral-900 border border-neutral-700 text-white px-2.5 py-1.5 rounded-lg text-xs font-bold"
                        />
                        <input
                          type="text"
                          value={link.url}
                          onChange={(e) => updateNavLink(link.id, { url: e.target.value })}
                          placeholder="URL"
                          className="bg-neutral-900 border border-neutral-700 text-yellow-400 font-mono px-2.5 py-1.5 rounded-lg text-xs"
                        />
                      </div>

                      {/* Controls: Up, Down, Delete */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => moveNavLink(idx, idx - 1)}
                          disabled={idx === 0}
                          className="p-1 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-30 text-white rounded border border-neutral-700 transition cursor-pointer"
                          title="উপরে নিন"
                        >
                          <ChevronUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => moveNavLink(idx, idx + 1)}
                          disabled={idx === (content.navLinks?.length || 0) - 1}
                          className="p-1 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-30 text-white rounded border border-neutral-700 transition cursor-pointer"
                          title="নিচে নিন"
                        >
                          <ChevronDown className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (window.confirm(`আপনি কি "${link.labelBn}" লিংকটি ডিলিট করতে চান?`)) {
                              deleteNavLink(link.id);
                            }
                          }}
                          className="p-1.5 bg-neutral-900 hover:bg-yellow-400 hover:text-black text-yellow-400 rounded-lg border border-neutral-700 transition cursor-pointer"
                          title="লিংক ডিলিট করুন (Delete link)"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Footer Quick Links List */}
              <div className="space-y-3 pt-3 border-t border-neutral-800">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <Link2 className="w-4 h-4 text-yellow-400" />
                    <span>ফুটার কুইক লিংকসমূহ ({content.footerLinks?.length || 0})</span>
                  </h4>
                </div>

                <div className="space-y-2">
                  {(content.footerLinks || []).map((link) => (
                    <div 
                      key={link.id} 
                      className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl flex items-center gap-3 hover:border-neutral-700 transition"
                    >
                      <div className="flex-1 grid grid-cols-3 gap-2">
                        <input
                          type="text"
                          value={link.labelBn}
                          onChange={(e) => updateFooterLink(link.id, { labelBn: e.target.value })}
                          placeholder="বাংলা নাম"
                          className="bg-neutral-900 border border-neutral-700 text-white px-2.5 py-1.5 rounded-lg text-xs font-bold"
                        />
                        <input
                          type="text"
                          value={link.labelEn}
                          onChange={(e) => updateFooterLink(link.id, { labelEn: e.target.value })}
                          placeholder="English Label"
                          className="bg-neutral-900 border border-neutral-700 text-white px-2.5 py-1.5 rounded-lg text-xs font-bold"
                        />
                        <input
                          type="text"
                          value={link.url}
                          onChange={(e) => updateFooterLink(link.id, { url: e.target.value })}
                          placeholder="URL"
                          className="bg-neutral-900 border border-neutral-700 text-yellow-400 font-mono px-2.5 py-1.5 rounded-lg text-xs"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          if (window.confirm(`আপনি কি ফুটার লিংক "${link.labelBn}" ডিলিট করতে চান?`)) {
                            deleteFooterLink(link.id);
                          }
                        }}
                        className="p-1.5 bg-neutral-900 hover:bg-yellow-400 hover:text-black text-yellow-400 rounded-lg border border-neutral-700 transition cursor-pointer shrink-0"
                        title="ফুটার লিংক ডিলিট করুন (Delete link)"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 1.3. FILES & MEDIA MANAGER (DELETE FILE) */}
          {activeTab === 'files' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-black text-yellow-400">
                    {lang === 'bn' ? 'ফাইল ও মিডিয়া ম্যানেজার (Files & Delete File)' : 'Files & Delete Media'}
                  </h3>
                  <p className="text-xs text-neutral-400">
                    {lang === 'bn' ? 'নতুন ফাইল বা ছবি আপলোড করুন, লিঙ্ক কপি করুন এবং যেকোনো ফাইল সরাসরি ডিলিট করুন' : 'Upload custom media, copy URLs or delete any stored file'}
                  </p>
                </div>
                <span className="text-xs bg-yellow-400 text-black px-2.5 py-1 rounded-xl font-black">
                  মোট ফাইল: {content.uploadedFiles?.length || 0}
                </span>
              </div>

              {/* Upload Card */}
              <div className="p-6 bg-neutral-950 border-2 border-dashed border-yellow-400 rounded-2xl text-center space-y-4">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*,application/pdf"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;

                    if (file.size > 5 * 1024 * 1024) {
                      setUploadError('ফাইল সাইজ ৫ মেগাবাইটের বেশি হতে পারবে না (Max 5MB)');
                      return;
                    }

                    const reader = new FileReader();
                    reader.onload = () => {
                      const dataUrl = reader.result as string;
                      const sizeInKb = Math.round(file.size / 1024);
                      const sizeStr = sizeInKb > 1024 ? `${(sizeInKb / 1024).toFixed(1)} MB` : `${sizeInKb} KB`;

                      uploadFile({
                        id: `file-${Date.now()}`,
                        name: file.name,
                        size: sizeStr,
                        type: file.type,
                        dataUrl,
                        createdAt: new Date().toISOString().split('T')[0]
                      });

                      setUploadSuccess(`"${file.name}" ফাইলটি সফলভাবে আপলোড হয়েছে!`);
                      setUploadError(null);
                      setTimeout(() => setUploadSuccess(null), 4000);
                    };
                    reader.onerror = () => {
                      setUploadError('ফাইল পড়তে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
                    };
                    reader.readAsDataURL(file);
                  }}
                />

                <div className="w-14 h-14 mx-auto rounded-2xl bg-yellow-400 text-black flex items-center justify-center font-black shadow-lg">
                  <Upload className="w-7 h-7 text-black" />
                </div>

                <div>
                  <h4 className="text-base font-black text-white">
                    {lang === 'bn' ? 'কম্পিউটার বা ফোন থেকে ফাইল আপলোড করুন' : 'Upload Images or Documents'}
                  </h4>
                  <p className="text-xs text-neutral-400 mt-1 max-w-md mx-auto">
                    {lang === 'bn' 
                      ? 'যেকোনো ছবি (PNG, JPG, WEBP) বা ডকুমেন্ট সিলেক্ট করুন। সাইজ ৫MB পর্যন্ত অনুমোদিত।' 
                      : 'Select any image or file from your device to store and use across the website.'}
                  </p>
                </div>

                <div className="flex justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-6 py-2.5 bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs rounded-xl shadow-md transition cursor-pointer flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4 text-black stroke-[3]" />
                    <span>{lang === 'bn' ? 'ফাইল নির্বাচন করুন (Browse File)' : 'Browse & Upload File'}</span>
                  </button>
                </div>

                {uploadError && (
                  <p className="text-xs text-yellow-400 font-bold bg-neutral-900 p-2 rounded-lg border border-yellow-400">
                    {uploadError}
                  </p>
                )}
                {uploadSuccess && (
                  <p className="text-xs text-black font-black bg-yellow-400 p-2 rounded-lg">
                    {uploadSuccess}
                  </p>
                )}
              </div>

              {/* Stored Files List with Delete File Action */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <FileText className="w-4 h-4 text-yellow-400" />
                    <span>সংরক্ষিত ফাইল ও ডিলিট তালিকা (Stored Files &amp; Delete Option)</span>
                  </h4>
                </div>

                {(!content.uploadedFiles || content.uploadedFiles.length === 0) ? (
                  <div className="p-8 text-center bg-neutral-950 border border-neutral-800 rounded-2xl text-neutral-400 text-xs">
                    কোনো সংরক্ষিত ফাইল নেই। উপরে ফাইল আপলোড করুন।
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    {content.uploadedFiles.map((f) => (
                      <div 
                        key={f.id} 
                        className="p-4 bg-neutral-950 border-2 border-neutral-800 hover:border-yellow-400/70 rounded-2xl space-y-3 transition shadow"
                      >
                        <div className="flex items-start gap-3">
                          <div className="w-16 h-16 rounded-xl overflow-hidden bg-neutral-900 border border-neutral-700 shrink-0 flex items-center justify-center">
                            {f.type.startsWith('image') || f.dataUrl.startsWith('data:image') || f.dataUrl.includes('assets') || f.dataUrl.includes('unsplash') ? (
                              <img src={f.dataUrl} alt={f.name} className="w-full h-full object-cover" />
                            ) : (
                              <FileText className="w-8 h-8 text-yellow-400" />
                            )}
                          </div>

                          <div className="flex-1 min-w-0">
                            <h5 className="font-bold text-white text-xs truncate" title={f.name}>
                              {f.name}
                            </h5>
                            <p className="text-[11px] text-yellow-400 font-bold mt-0.5">
                              {f.size} • {f.createdAt}
                            </p>
                            <p className="text-[10px] text-neutral-500 truncate mt-0.5 font-mono">
                              {f.type || 'file'}
                            </p>
                          </div>
                        </div>

                        {/* Actions for this file: Copy URL, Use as Logo, Add to Gallery, Delete File */}
                        <div className="pt-2 border-t border-neutral-800 flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                navigator.clipboard.writeText(f.dataUrl);
                                setCopiedId(f.id);
                                setTimeout(() => setCopiedId(null), 2000);
                              }}
                              className="px-2.5 py-1 bg-neutral-900 hover:bg-neutral-800 text-white text-[11px] font-bold rounded-lg border border-neutral-700 transition flex items-center gap-1 cursor-pointer"
                              title="লিংক কপি করুন"
                            >
                              {copiedId === f.id ? (
                                <>
                                  <Check className="w-3 h-3 text-yellow-400" />
                                  <span className="text-yellow-400">কপি হয়েছে!</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3 h-3 text-yellow-400" />
                                  <span>কপি URL</span>
                                </>
                              )}
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                updateAgencyInfo({ logoUrl: f.dataUrl });
                                alert('লোগো হিসেবে সফলভাবে সেট করা হয়েছে!');
                              }}
                              className="px-2 py-1 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white text-[11px] rounded-lg border border-neutral-700 transition cursor-pointer"
                            >
                              লোগো সেট
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                addGalleryItem({
                                  id: Date.now(),
                                  type: 'office',
                                  titleBn: f.name,
                                  titleEn: f.name,
                                  image: f.dataUrl,
                                  tagBn: 'ফাইল',
                                  tagEn: 'File'
                                });
                                alert('গ্যালারিতে যুক্ত করা হয়েছে!');
                              }}
                              className="px-2 py-1 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white text-[11px] rounded-lg border border-neutral-700 transition cursor-pointer"
                            >
                              + গ্যালারি
                            </button>
                          </div>

                          {/* Explicit Delete File Button */}
                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm(`আপনি কি "${f.name}" ফাইলটি স্থায়ীভাবে ডিলিট করতে চান? / Delete this file permanently?`)) {
                                deleteFile(f.id);
                              }
                            }}
                            className="px-3 py-1 bg-neutral-900 hover:bg-yellow-400 hover:text-black text-yellow-400 border border-neutral-700 text-xs font-black rounded-lg transition flex items-center gap-1 cursor-pointer"
                            title="ফাইল ডিলিট করুন (Delete File)"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>ডিলিট ফাইল (Delete)</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 2. HERO & HEADLINES */}
          {activeTab === 'hero' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-3">
                <h3 className="text-lg font-black text-yellow-400">
                  {lang === 'bn' ? 'হিরো সেকশন ও ব্যানার কনটেন্ট' : 'Hero Section & Main Headline'}
                </h3>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'টপ ট্রাস্ট ব্যাজ (বাংলা)' : 'Top Trust Badge (BN)'}
                  </label>
                  <input
                    type="text"
                    value={content.hero.badgeBn}
                    onChange={(e) => updateHero({ badgeBn: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                      {lang === 'bn' ? 'মূল হেডলাইন লাইন ১ (বাংলা)' : 'Headline Line 1 (BN)'}
                    </label>
                    <input
                      type="text"
                      value={content.hero.titleLine1Bn}
                      onChange={(e) => updateHero({ titleLine1Bn: e.target.value })}
                      className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                      {lang === 'bn' ? 'মূল হেডলাইন লাইন ২ (হলুদ টেক্সট)' : 'Headline Line 2 (Yellow Text)'}
                    </label>
                    <input
                      type="text"
                      value={content.hero.titleLine2Bn}
                      onChange={(e) => updateHero({ titleLine2Bn: e.target.value })}
                      className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-yellow-400 p-2.5 rounded-xl text-sm font-bold"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'বিবরণ প্যারাগ্রাফ (বাংলা)' : 'Subtitle Paragraph (BN)'}
                  </label>
                  <textarea
                    rows={3}
                    value={content.hero.subtitleBn}
                    onChange={(e) => updateHero({ subtitleBn: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                      {lang === 'bn' ? 'স্ট্যাটাস ব্যাজ' : 'Live Status Badge'}
                    </label>
                    <input
                      type="text"
                      value={content.hero.statusBadgeBn}
                      onChange={(e) => updateHero({ statusBadgeBn: e.target.value })}
                      className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                      {lang === 'bn' ? 'সাব-ট্যাগলাইন' : 'Sub-Tagline'}
                    </label>
                    <input
                      type="text"
                      value={content.hero.taglineBn}
                      onChange={(e) => updateHero({ taglineBn: e.target.value })}
                      className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 3. MALAYSIA SPECIAL */}
          {activeTab === 'malaysia' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-3">
                <h3 className="text-lg font-black text-yellow-400">
                  {lang === 'bn' ? 'মালয়েশিয়া ওয়ার্ক ও কলিং স্পটলাইট' : 'Malaysia Signature Spotlight'}
                </h3>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'সেকশন শিরোনাম' : 'Section Title'}
                  </label>
                  <input
                    type="text"
                    value={content.malaysia.titleBn}
                    onChange={(e) => updateMalaysia({ titleBn: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'বিশেষ উক্তি / হাইলাইট কোট' : 'Special Highlight Quote'}
                  </label>
                  <textarea
                    rows={2}
                    value={content.malaysia.quoteBn}
                    onChange={(e) => updateMalaysia({ quoteBn: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-yellow-400 p-2.5 rounded-xl text-sm font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    {lang === 'bn' ? 'বিস্তারিত বর্ণনা' : 'Description'}
                  </label>
                  <textarea
                    rows={3}
                    value={content.malaysia.descBn}
                    onChange={(e) => updateMalaysia({ descBn: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>

                {/* Sectors */}
                <div className="pt-2">
                  <h4 className="text-sm font-black text-white mb-2">
                    {lang === 'bn' ? '৪টি কাজের সেক্টর:' : '4 Work Sectors:'}
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    {content.malaysia.sectors.map((sec, idx) => (
                      <div key={idx} className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl space-y-2">
                        <input
                          type="text"
                          value={sec.titleBn}
                          onChange={(e) => {
                            const newSec = [...content.malaysia.sectors];
                            newSec[idx].titleBn = e.target.value;
                            updateMalaysia({ sectors: newSec });
                          }}
                          className="w-full bg-neutral-900 border border-neutral-700 text-yellow-400 font-bold p-1.5 rounded-lg text-xs"
                        />
                        <input
                          type="text"
                          value={sec.descBn}
                          onChange={(e) => {
                            const newSec = [...content.malaysia.sectors];
                            newSec[idx].descBn = e.target.value;
                            updateMalaysia({ sectors: newSec });
                          }}
                          className="w-full bg-neutral-900 border border-neutral-700 text-white p-1.5 rounded-lg text-xs"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 4. SERVICES MANAGER */}
          {activeTab === 'services' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-black text-yellow-400">
                    {lang === 'bn' ? 'সেবাসমূহ পরিচালনা' : 'Services Manager'}
                  </h3>
                  <p className="text-xs text-neutral-400">
                    {lang === 'bn' ? 'সেবার নাম, সময়কাল, বিবরণ ও কাগজপত্র এডিট করুন' : 'Edit service titles, timelines & requirements'}
                  </p>
                </div>

                <button
                  onClick={() => {
                    const newId = `service-${Date.now()}`;
                    addService({
                      id: newId,
                      titleBn: 'নতুন সেবা (New Service)',
                      titleEn: 'New Visa Service',
                      badgeBn: 'নতুন সেবা',
                      badgeEn: 'New',
                      descriptionBn: 'সেবার সংক্ষিপ্ত বিবরণ এখানে লিখুন।',
                      descriptionEn: 'Service brief description.',
                      iconName: 'Sparkles',
                      timelineBn: '১৫ - ৩০ দিন',
                      timelineEn: '15 - 30 Days',
                      requirementsBn: ['পাসপোর্ট সাইজ ছবি', 'মূল পাসপোর্ট'],
                      requirementsEn: ['Passport photo', 'Valid passport'],
                      keyHighlightsBn: ['১০০% বিশ্বস্ত প্রক্রিয়া'],
                      keyHighlightsEn: ['100% Genuine process']
                    });
                  }}
                  className="px-3 py-1.5 bg-yellow-400 hover:bg-yellow-300 text-black text-xs font-black rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow"
                >
                  <Plus className="w-4 h-4 text-black" />
                  <span>{lang === 'bn' ? 'নতুন সেবা যোগ করুন' : 'Add New Service'}</span>
                </button>
              </div>

              <div className="space-y-4">
                {content.services.map((svc) => (
                  <div key={svc.id} className="p-4 bg-neutral-950 border-2 border-neutral-800 rounded-2xl space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="bg-yellow-400 text-black font-black text-xs px-2.5 py-0.5 rounded-md">
                          {svc.badgeBn}
                        </span>
                        <h4 className="font-bold text-white text-base">{svc.titleBn}</h4>
                      </div>

                      <button
                        onClick={() => deleteService(svc.id)}
                        className="p-1.5 bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-yellow-400 rounded-lg transition cursor-pointer"
                        title="Delete service"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-400 uppercase mb-1">
                          সেবার শিরোনাম (বাংলা)
                        </label>
                        <input
                          type="text"
                          value={svc.titleBn}
                          onChange={(e) => updateService(svc.id, { titleBn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 text-white p-2 rounded-lg text-xs"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-neutral-400 uppercase mb-1">
                          ব্যাজ লেবেল
                        </label>
                        <input
                          type="text"
                          value={svc.badgeBn}
                          onChange={(e) => updateService(svc.id, { badgeBn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 text-white p-2 rounded-lg text-xs"
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="block text-[11px] font-bold text-neutral-400 uppercase mb-1">
                          বিবরণ
                        </label>
                        <textarea
                          rows={2}
                          value={svc.descriptionBn}
                          onChange={(e) => updateService(svc.id, { descriptionBn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 text-white p-2 rounded-lg text-xs"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-neutral-400 uppercase mb-1">
                          সময়কাল (Timeline)
                        </label>
                        <input
                          type="text"
                          value={svc.timelineBn}
                          onChange={(e) => updateService(svc.id, { timelineBn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 text-yellow-400 font-bold p-2 rounded-lg text-xs"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 5. TEAM MEMBERS */}
          {activeTab === 'team' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="text-lg font-black text-yellow-400">
                      {lang === 'bn' ? 'টিম সদস্য ও পরিচালনা পর্ষদ' : 'Leadership Team Management'}
                    </h3>
                    <p className="text-xs text-neutral-400">
                      {lang === 'bn' ? 'টিমে নতুন সদস্য যোগ করুন, ক্রমানুসার পরিবর্তন বা তথ্য এডিট করুন' : 'Add members, reorder, and configure roles'}
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      const id = `team-${Date.now()}`;
                      addTeamMember({
                        id,
                        nameBn: 'নতুন টিম মেম্বার',
                        nameEn: 'New Team Member',
                        roleBn: 'ভিসা ও ট্রাভেল স্পেশালিস্ট',
                        roleEn: 'Visa & Travel Specialist',
                        titleBn: 'Haor Travels & Tours',
                        titleEn: 'Haor Travels & Tours',
                        image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=800&q=80',
                        experienceBn: '৫+ বছর',
                        experienceEn: '5+ Years',
                        bioBn: 'সততা ও নিষ্ঠার সাথে গ্রাহকদের নির্ভরযোগ্য পরামর্শ প্রদানে অঙ্গীকারবদ্ধ।',
                        bioEn: 'Dedicated to providing reliable overseas visa consultancy and customer support.',
                        phone: content.agencyInfo.phone,
                        whatsapp: content.agencyInfo.whatsappLink
                      });
                    }}
                    className="bg-yellow-400 hover:bg-yellow-300 text-black font-black px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
                  >
                    <Plus className="w-4 h-4 text-black stroke-[3]" />
                    <span>{lang === 'bn' ? '+ নতুন মেম্বার যোগ করুন' : '+ Add Team Member'}</span>
                  </button>
                </div>

                {/* Quick Preset Buttons */}
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <span className="text-[11px] font-bold text-neutral-400">
                    {lang === 'bn' ? 'দ্রুত যোগ করুন:' : 'Quick Presets:'}
                  </span>
                  <button
                    onClick={() => {
                      const id = `team-${Date.now()}`;
                      addTeamMember({
                        id,
                        nameBn: 'ভিসা প্রসেসিং অফিসার',
                        nameEn: 'Visa Processing Officer',
                        roleBn: 'ভিসা ও ডকুমেন্টেশন স্পেশালিস্ট',
                        roleEn: 'Visa & Documentation Specialist',
                        titleBn: 'Haor Travels & Tours',
                        titleEn: 'Haor Travels & Tours',
                        image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=800&q=80',
                        experienceBn: '৬+ বছর',
                        experienceEn: '6+ Years',
                        bioBn: 'মালয়েশিয়া ও মধ্যপ্রাচ্যের ভিসা আবেদন, বায়োমেট্রিক ও পেপারস ভেরিফিকেশনে বিশেষজ্ঞ।',
                        bioEn: 'Specializes in overseas work permits, bio-metrics, and embassy document endorsements.',
                        phone: content.agencyInfo.phone,
                        whatsapp: content.agencyInfo.whatsappLink
                      });
                    }}
                    className="px-2.5 py-1 bg-neutral-900 hover:bg-neutral-800 text-yellow-400 hover:text-white border border-neutral-700 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3 text-yellow-400" />
                    <span>+ ভিসা অফিসার</span>
                  </button>
                  <button
                    onClick={() => {
                      const id = `team-${Date.now()}`;
                      addTeamMember({
                        id,
                        nameBn: 'সিনিয়র কনসালট্যান্ট',
                        nameEn: 'Senior Travel Consultant',
                        roleBn: 'ইউরোপ ও স্টুডেন্ট ভিসা ডেস্ক',
                        roleEn: 'Europe & Study Abroad Desk',
                        titleBn: 'Haor Travels & Tours',
                        titleEn: 'Haor Travels & Tours',
                        image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80',
                        experienceBn: '৫+ বছর',
                        experienceEn: '5+ Years',
                        bioBn: 'উচ্চশিক্ষা ও ইউরোপ স্টুডেন্ট ভিসা প্রসেসিংয়ে দক্ষ পরামর্শক।',
                        bioEn: 'Expert guidance on university applications and European visa processing.',
                        phone: content.agencyInfo.phone,
                        whatsapp: content.agencyInfo.whatsappLink
                      });
                    }}
                    className="px-2.5 py-1 bg-neutral-900 hover:bg-neutral-800 text-yellow-400 hover:text-white border border-neutral-700 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3 text-yellow-400" />
                    <span>+ সিনিয়র কনসালট্যান্ট</span>
                  </button>
                  <button
                    onClick={() => {
                      const id = `team-${Date.now()}`;
                      addTeamMember({
                        id,
                        nameBn: 'কুয়ালালামপুর প্রতিনিধি',
                        nameEn: 'Kuala Lumpur Representative',
                        roleBn: 'মালয়েশিয়া লিয়াজোঁ ও অন-গ্রাউন্ড সাপোর্ট',
                        roleEn: 'Malaysia Liaison & On-Ground Support',
                        titleBn: 'Haor Travels & Tours',
                        titleEn: 'Haor Travels & Tours',
                        image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
                        experienceBn: '৭+ বছর',
                        experienceEn: '7+ Years',
                        bioBn: 'মালয়েশিয়ায় অবস্থানরত কর্মীদের এয়ারপোর্ট রিসিপশন ও সার্বিক সহযোগিতা করেন।',
                        bioEn: 'Overseas ground support in Malaysia managing employer coordination and client assistance.',
                        phone: content.agencyInfo.phone,
                        whatsapp: content.agencyInfo.whatsappLink
                      });
                    }}
                    className="px-2.5 py-1 bg-neutral-900 hover:bg-neutral-800 text-yellow-400 hover:text-white border border-neutral-700 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3 text-yellow-400" />
                    <span>+ কুয়ালালামপুর প্রতিনিধি</span>
                  </button>
                </div>
              </div>

              {/* Members List */}
              <div className="space-y-6">
                {content.team.map((member, index) => (
                  <div key={member.id} className="p-6 bg-neutral-950 border-2 border-neutral-800 hover:border-yellow-400/60 rounded-3xl space-y-5 transition shadow-xl">
                    <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-yellow-400 shrink-0 bg-neutral-900 shadow-md">
                          <img src={member.image} alt={member.nameBn} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="w-6 h-6 rounded-full bg-yellow-400 text-black font-black text-xs flex items-center justify-center">
                              {index + 1}
                            </span>
                            <h4 className="font-black text-white text-base">{member.nameBn}</h4>
                          </div>
                          <p className="text-yellow-400 text-xs font-bold mt-0.5">{member.roleBn} • {member.experienceBn}</p>
                        </div>
                      </div>

                      {/* Action Controls: Move Up, Move Down, Delete */}
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => moveTeamMember(index, index - 1)}
                          disabled={index === 0}
                          title="Move member up"
                          className="p-1.5 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-30 text-white rounded-lg border border-neutral-700 transition cursor-pointer"
                        >
                          <ChevronUp className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => moveTeamMember(index, index + 1)}
                          disabled={index === content.team.length - 1}
                          title="Move member down"
                          className="p-1.5 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-30 text-white rounded-lg border border-neutral-700 transition cursor-pointer"
                        >
                          <ChevronDown className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`আপনি কি "${member.nameBn}"-কে টিম থেকে ডিলিট করতে চান?`)) {
                              deleteTeamMember(member.id);
                            }
                          }}
                          title="Delete this team member"
                          className="p-1.5 bg-neutral-900 hover:bg-yellow-400 hover:text-black text-yellow-400 rounded-lg border border-neutral-700 transition cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Member Detailed Fields */}
                    <div className="grid grid-cols-2 gap-4">
                      {/* Name Bangla */}
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                          নাম (বাংলা) *
                        </label>
                        <input
                          type="text"
                          value={member.nameBn}
                          onChange={(e) => updateTeamMember(member.id, { nameBn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-xs font-bold"
                        />
                      </div>

                      {/* Name English */}
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                          নাম (English) *
                        </label>
                        <input
                          type="text"
                          value={member.nameEn}
                          onChange={(e) => updateTeamMember(member.id, { nameEn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-xs font-bold"
                        />
                      </div>

                      {/* Role Bangla */}
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                          ডিপার্টমেন্ট / ভূমিকা (বাংলা)
                        </label>
                        <input
                          type="text"
                          value={member.roleBn}
                          onChange={(e) => updateTeamMember(member.id, { roleBn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-xs"
                        />
                      </div>

                      {/* Role English */}
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                          Department / Role (English)
                        </label>
                        <input
                          type="text"
                          value={member.roleEn}
                          onChange={(e) => updateTeamMember(member.id, { roleEn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-xs"
                        />
                      </div>

                      {/* Designation Title Bangla */}
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                          পদবী / উপাধি (বাংলা)
                        </label>
                        <input
                          type="text"
                          value={member.titleBn}
                          onChange={(e) => updateTeamMember(member.id, { titleBn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-xs"
                        />
                      </div>

                      {/* Designation Title English */}
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                          Designation Title (English)
                        </label>
                        <input
                          type="text"
                          value={member.titleEn}
                          onChange={(e) => updateTeamMember(member.id, { titleEn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-xs"
                        />
                      </div>

                      {/* Experience Bangla */}
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                          অভিজ্ঞতা (বাংলা, যেমন: ১৭+ বছর)
                        </label>
                        <input
                          type="text"
                          value={member.experienceBn}
                          onChange={(e) => updateTeamMember(member.id, { experienceBn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-yellow-400 font-bold p-2.5 rounded-xl text-xs"
                        />
                      </div>

                      {/* Experience English */}
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                          Experience (English, e.g. 17+ Years)
                        </label>
                        <input
                          type="text"
                          value={member.experienceEn}
                          onChange={(e) => updateTeamMember(member.id, { experienceEn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-yellow-400 font-bold p-2.5 rounded-xl text-xs"
                        />
                      </div>

                      {/* Direct Phone */}
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1 flex items-center gap-1">
                          <Phone className="w-3 h-3 text-yellow-400" />
                          <span>সরাসরি ফোন নম্বর</span>
                        </label>
                        <input
                          type="text"
                          value={member.phone}
                          onChange={(e) => updateTeamMember(member.id, { phone: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white font-mono p-2.5 rounded-xl text-xs"
                        />
                      </div>

                      {/* Direct WhatsApp Link */}
                      <div>
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1 flex items-center gap-1">
                          <MessageCircle className="w-3 h-3 text-yellow-400" />
                          <span>WhatsApp লিঙ্ক</span>
                        </label>
                        <input
                          type="text"
                          value={member.whatsapp}
                          onChange={(e) => updateTeamMember(member.id, { whatsapp: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white font-mono p-2.5 rounded-xl text-xs"
                        />
                      </div>

                      {/* Image URL with Preset Selector */}
                      <div className="col-span-2">
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                          ছবির পাথ / Image URL
                        </label>
                        <input
                          type="text"
                          value={member.image}
                          onChange={(e) => updateTeamMember(member.id, { image: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-xs font-mono mb-2"
                        />
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-[10px] text-neutral-500 font-bold">ছবির প্রিসেট:</span>
                          <button
                            type="button"
                            onClick={() => updateTeamMember(member.id, { image: content.agencyInfo.founderImage })}
                            className="px-2 py-0.5 bg-neutral-900 hover:bg-yellow-400 hover:text-black text-[11px] text-neutral-300 rounded border border-neutral-700 transition"
                          >
                            প্রতিষ্ঠাতা
                          </button>
                          <button
                            type="button"
                            onClick={() => updateTeamMember(member.id, { image: content.agencyInfo.marketingImage })}
                            className="px-2 py-0.5 bg-neutral-900 hover:bg-yellow-400 hover:text-black text-[11px] text-neutral-300 rounded border border-neutral-700 transition"
                          >
                            মার্কেটিং
                          </button>
                          <button
                            type="button"
                            onClick={() => updateTeamMember(member.id, { image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=800&q=80' })}
                            className="px-2 py-0.5 bg-neutral-900 hover:bg-yellow-400 hover:text-black text-[11px] text-neutral-300 rounded border border-neutral-700 transition"
                          >
                            অফিসার (Male)
                          </button>
                          <button
                            type="button"
                            onClick={() => updateTeamMember(member.id, { image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80' })}
                            className="px-2 py-0.5 bg-neutral-900 hover:bg-yellow-400 hover:text-black text-[11px] text-neutral-300 rounded border border-neutral-700 transition"
                          >
                            কনসালট্যান্ট (Female)
                          </button>
                        </div>
                      </div>

                      {/* Bio Bangla */}
                      <div className="col-span-2">
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                          বায়োগ্রাফি / বিবরণ (বাংলা)
                        </label>
                        <textarea
                          rows={3}
                          value={member.bioBn}
                          onChange={(e) => updateTeamMember(member.id, { bioBn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-xs leading-relaxed"
                        />
                      </div>

                      {/* Bio English */}
                      <div className="col-span-2">
                        <label className="block text-[11px] font-bold text-neutral-300 uppercase mb-1">
                          Biography / Details (English)
                        </label>
                        <textarea
                          rows={3}
                          value={member.bioEn}
                          onChange={(e) => updateTeamMember(member.id, { bioEn: e.target.value })}
                          className="w-full bg-neutral-900 border border-neutral-700 focus:border-yellow-400 text-white p-2.5 rounded-xl text-xs leading-relaxed"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 6. WHY CHOOSE US */}
          {activeTab === 'whyUs' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-3">
                <h3 className="text-lg font-black text-yellow-400">
                  {lang === 'bn' ? 'কেন আমরা ও ৪টি মূল স্তম্ভ' : 'Why Choose Us Content'}
                </h3>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    হেডলাইন
                  </label>
                  <input
                    type="text"
                    value={content.whyUs.titleBn}
                    onChange={(e) => updateWhyUs({ titleBn: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 text-white p-2.5 rounded-xl text-sm font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    প্রতিষ্ঠাতার মূল উক্তি (Quote)
                  </label>
                  <textarea
                    rows={3}
                    value={content.whyUs.quoteBn}
                    onChange={(e) => updateWhyUs({ quoteBn: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 text-yellow-400 font-bold p-2.5 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 uppercase mb-1">
                    বিবরণ
                  </label>
                  <textarea
                    rows={3}
                    value={content.whyUs.descBn}
                    onChange={(e) => updateWhyUs({ descBn: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-700 text-white p-2.5 rounded-xl text-sm"
                  />
                </div>
              </div>
            </div>
          )}

          {/* 7. GALLERY */}
          {activeTab === 'gallery' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-black text-yellow-400">
                    {lang === 'bn' ? 'ফটো গ্যালারি পরিচালনা' : 'Photo Gallery Items'}
                  </h3>
                  <p className="text-xs text-neutral-400">
                    {lang === 'bn' ? 'ছবি যুক্ত বা পরিবর্তন করুন' : 'Add or replace gallery photos'}
                  </p>
                </div>

                <button
                  onClick={() => {
                    addGalleryItem({
                      id: Date.now(),
                      type: 'travel',
                      titleBn: 'নতুন ভ্রমণের দৃশ্য',
                      titleEn: 'New Travel Scene',
                      image: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=800&q=80',
                      tagBn: 'ভ্রমণ',
                      tagEn: 'Travel'
                    });
                  }}
                  className="px-3 py-1.5 bg-yellow-400 hover:bg-yellow-300 text-black text-xs font-black rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow"
                >
                  <Plus className="w-4 h-4 text-black" />
                  <span>{lang === 'bn' ? 'ছবি যুক্ত করুন' : 'Add Photo'}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {content.gallery.map((item, idx) => (
                  <div key={item.id} className="p-3 bg-neutral-950 border-2 border-neutral-800 rounded-2xl space-y-2">
                    <div className="h-32 rounded-xl overflow-hidden bg-neutral-900 border border-neutral-800">
                      <img src={item.image} alt={item.titleBn} className="w-full h-full object-cover" />
                    </div>

                    <input
                      type="text"
                      value={item.titleBn}
                      onChange={(e) => updateGalleryItem(idx, { ...item, titleBn: e.target.value })}
                      placeholder="শিরোনাম (বাংলা)"
                      className="w-full bg-neutral-900 border border-neutral-700 text-white p-2 rounded-lg text-xs"
                    />

                    <input
                      type="text"
                      value={item.image}
                      onChange={(e) => updateGalleryItem(idx, { ...item, image: e.target.value })}
                      placeholder="Image URL"
                      className="w-full bg-neutral-900 border border-neutral-700 text-neutral-400 p-2 rounded-lg text-xs font-mono"
                    />

                    <div className="flex items-center justify-between pt-1">
                      <input
                        type="text"
                        value={item.tagBn}
                        onChange={(e) => updateGalleryItem(idx, { ...item, tagBn: e.target.value })}
                        placeholder="ট্যাগ"
                        className="w-28 bg-neutral-900 border border-neutral-700 text-yellow-400 p-1.5 rounded-lg text-xs font-bold"
                      />

                      <button
                        onClick={() => {
                          if (window.confirm(`আপনি কি "${item.titleBn}" ছবিটি গ্যালারি থেকে ডিলিট করতে চান? / Delete this photo?`)) {
                            deleteGalleryItem(idx);
                          }
                        }}
                        className="p-1.5 px-2.5 bg-neutral-900 hover:bg-yellow-400 hover:text-black text-yellow-400 rounded-lg text-xs font-black transition cursor-pointer flex items-center gap-1"
                        title="Delete photo / file"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>ছবি ডিলিট</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 8. FAQS */}
          {activeTab === 'faqs' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-black text-yellow-400">
                    {lang === 'bn' ? 'সাধারণ প্রশ্নোত্তর (FAQ)' : 'Frequently Asked Questions'}
                  </h3>
                  <p className="text-xs text-neutral-400">
                    {lang === 'bn' ? 'প্রশ্ন ও উত্তর যোগ বা পরিমার্জন করুন' : 'Add or modify questions and answers'}
                  </p>
                </div>

                <button
                  onClick={() => {
                    addFaq({
                      qBn: 'নতুন প্রশ্ন এখানে লিখুন?',
                      qEn: 'New question here?',
                      aBn: 'উত্তরের বিস্তারিত বিবরণ এখানে দিন।',
                      aEn: 'Answer details here.'
                    });
                  }}
                  className="px-3 py-1.5 bg-yellow-400 hover:bg-yellow-300 text-black text-xs font-black rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow"
                >
                  <Plus className="w-4 h-4 text-black" />
                  <span>{lang === 'bn' ? 'প্রশ্ন যোগ করুন' : 'Add FAQ'}</span>
                </button>
              </div>

              <div className="space-y-4">
                {content.faqs.map((faq, idx) => (
                  <div key={idx} className="p-4 bg-neutral-950 border-2 border-neutral-800 rounded-2xl space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-yellow-400">প্রশ্ন #{idx + 1}</span>
                      <button
                        onClick={() => deleteFaq(idx)}
                        className="p-1 text-neutral-400 hover:text-yellow-400 transition cursor-pointer"
                        title="Delete FAQ"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <input
                      type="text"
                      value={faq.qBn}
                      onChange={(e) => updateFaq(idx, { ...faq, qBn: e.target.value })}
                      placeholder="প্রশ্ন (বাংলা)"
                      className="w-full bg-neutral-900 border border-neutral-700 text-white font-bold p-2.5 rounded-xl text-sm"
                    />

                    <textarea
                      rows={2}
                      value={faq.aBn}
                      onChange={(e) => updateFaq(idx, { ...faq, aBn: e.target.value })}
                      placeholder="উত্তর (বাংলা)"
                      className="w-full bg-neutral-900 border border-neutral-700 text-neutral-300 p-2.5 rounded-xl text-xs leading-relaxed"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 9. VISIBILITY & SECTION TOGGLE */}
          {activeTab === 'visibility' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-3">
                <h3 className="text-lg font-black text-yellow-400">
                  {lang === 'bn' ? 'সেকশন দৃশ্যমানতা ও রিমুভ নিয়ন্ত্রণ' : 'Section Visibility & Removal Control'}
                </h3>
                <p className="text-xs text-neutral-400">
                  {lang === 'bn' ? 'যেকোনো সেকশন মুহূর্তেই লুকিয়ে রাখতে বা দেখাতে পারেন' : 'Toggle any section on or off instantly'}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {[
                  { key: 'hero', name: '১. হিরো ব্যানার (Hero Section)' },
                  { key: 'malaysia', name: '২. মালয়েশিয়া ওয়ার্ক স্পটলাইট' },
                  { key: 'services', name: '৩. আমাদের ৫টি সেবা (Services)' },
                  { key: 'checker', name: '৪. ভিসা যোগ্যতা ক্যালকুলেটর' },
                  { key: 'whyUs', name: '৫. কেন আমরা (Why Choose Us)' },
                  { key: 'team', name: '৬. পরিচালনা পর্ষদ ও টিম' },
                  { key: 'process', name: '৭. ৪টি সহজ ধাপ (Process Steps)' },
                  { key: 'gallery', name: '৮. ফটো গ্যালারি (Gallery)' },
                  { key: 'faqs', name: '৯. সাধারণ প্রশ্নোত্তর (FAQs)' },
                  { key: 'contact', name: '১০. যোগাযোগ ও অনলাইন ফর্ম' },
                ].map(({ key, name }) => {
                  const isVisible = content.visibility[key as keyof SectionVisibility];
                  return (
                    <div 
                      key={key} 
                      className={`p-4 rounded-2xl border-2 flex items-center justify-between transition ${
                        isVisible 
                          ? 'bg-neutral-950 border-neutral-800' 
                          : 'bg-black border-dashed border-neutral-800 opacity-60'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {isVisible ? (
                          <Eye className="w-5 h-5 text-yellow-400" />
                        ) : (
                          <EyeOff className="w-5 h-5 text-neutral-500" />
                        )}
                        <span className="font-bold text-sm text-white">{name}</span>
                      </div>

                      <button
                        onClick={() => toggleSectionVisibility(key as keyof SectionVisibility)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer ${
                          isVisible
                            ? 'bg-yellow-400 text-black shadow'
                            : 'bg-neutral-900 text-neutral-400 border border-neutral-700'
                        }`}
                      >
                        {isVisible ? (lang === 'bn' ? 'দৃশ্যমান (Visible)' : 'Visible') : (lang === 'bn' ? 'লুকায়িত (Hidden)' : 'Hidden')}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 10. BACKUP & RESTORE */}
          {activeTab === 'backup' && (
            <div className="space-y-6">
              <div className="border-b border-neutral-800 pb-3">
                <h3 className="text-lg font-black text-yellow-400">
                  {lang === 'bn' ? 'ডাটা ব্যাকআপ, এক্সপোর্ট ও রিস্টোর' : 'Data Backup, Export & Restore'}
                </h3>
                <p className="text-xs text-neutral-400">
                  {lang === 'bn' ? 'আপনার সকল এডিট করা টেক্সট ও কনটেন্ট ব্যাকআপ ফাইল হিসেবে ডাউনলোড বা রিস্টোর করুন' : 'Export JSON file or reset to original template'}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-6">
                {/* Export box */}
                <div className="p-6 bg-neutral-950 border-2 border-neutral-800 rounded-2xl space-y-3">
                  <h4 className="font-black text-white text-base">
                    {lang === 'bn' ? '১. ব্যাকআপ ডাউনলোড (Export JSON)' : '1. Download Backup'}
                  </h4>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {lang === 'bn' 
                      ? 'সম্পূর্ণ ওয়েবসাইটের বর্তমান টেক্সট, ফোন নম্বর, টিম ও সেবাসমূহ একটি JSON ফাইল হিসেবে ডাউনলোড করুন।' 
                      : 'Download a JSON file containing all your customized text, services, and photos.'}
                  </p>
                  <button
                    onClick={exportContentJson}
                    className="w-full bg-yellow-400 hover:bg-yellow-300 text-black font-black py-3 px-4 rounded-xl text-sm transition flex items-center justify-center gap-2 cursor-pointer shadow-md"
                  >
                    <Download className="w-4 h-4 text-black" />
                    <span>{lang === 'bn' ? 'ব্যাকআপ ডাউনলোড করুন' : 'Export JSON Backup'}</span>
                  </button>
                </div>

                {/* Reset box */}
                <div className="p-6 bg-neutral-950 border-2 border-neutral-800 rounded-2xl space-y-3">
                  <h4 className="font-black text-white text-base">
                    {lang === 'bn' ? '২. আসল অবস্থায় ফিরুন (Reset)' : '2. Reset to Original'}
                  </h4>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {lang === 'bn'
                      ? 'সব ম্যানুয়াল পরিবর্তন মুছে দিয়ে ওয়েবসাইটের মূল প্রাথমিক কনটেন্টে ফিরে যেতে চাইলে রিসেট করুন।'
                      : 'Erase all customized changes and restore the default template data.'}
                  </p>
                  <button
                    onClick={resetToDefaults}
                    className="w-full bg-neutral-900 hover:bg-neutral-800 text-white border border-neutral-700 font-bold py-3 px-4 rounded-xl text-sm transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4 text-yellow-400" />
                    <span>{lang === 'bn' ? 'ডিফল্ট রিস্টোর করুন' : 'Reset to Defaults'}</span>
                  </button>
                </div>

                {/* Import Box */}
                <div className="col-span-2 p-6 bg-neutral-950 border-2 border-neutral-800 rounded-2xl space-y-3">
                  <h4 className="font-black text-white text-base">
                    {lang === 'bn' ? '৩. ব্যাকআপ থেকে রিস্টোর (Import JSON)' : '3. Import from JSON Backup'}
                  </h4>
                  <textarea
                    rows={4}
                    value={importText}
                    onChange={(e) => setImportText(e.target.value)}
                    placeholder='{"agencyInfo": { ... }, "services": [ ... ]}'
                    className="w-full bg-black border border-neutral-700 focus:border-yellow-400 text-white p-3 rounded-xl text-xs font-mono"
                  />
                  {importStatus && (
                    <p className="text-xs text-yellow-400 font-bold">{importStatus}</p>
                  )}
                  <button
                    onClick={handleImport}
                    className="bg-white hover:bg-yellow-400 text-black font-black py-2.5 px-6 rounded-xl text-xs transition cursor-pointer flex items-center gap-2 shadow"
                  >
                    <Upload className="w-4 h-4 text-black" />
                    <span>{lang === 'bn' ? 'ইমপোর্ট সম্পন্ন করুন' : 'Apply JSON Import'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Drawer Footer */}
        <div className="p-4 border-t-2 border-neutral-800 bg-neutral-950 flex items-center justify-between">
          <p className="text-xs text-neutral-400">
            {lang === 'bn' ? 'সব পরিবর্তন ব্রাউজারে স্বয়ংক্রিয়ভাবে সংরক্ষিত রয়েছে।' : 'All changes are instantly persisted in your browser.'}
          </p>
          <button
            onClick={() => setIsAdminOpen(false)}
            className="px-6 py-2.5 bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs rounded-xl shadow-md cursor-pointer transition flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-4 h-4 text-black" />
            <span>{lang === 'bn' ? 'সম্পাদনা শেষ করুন (Done)' : 'Done Editing'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
