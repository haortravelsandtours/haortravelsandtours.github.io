import React from 'react';
import { Trash2, Plus } from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';

interface GallerySectionProps {
  lang: 'bn' | 'en';
}

export const GallerySection: React.FC<GallerySectionProps> = ({ lang }) => {
  const { content, updateGalleryItem, deleteGalleryItem, addGalleryItem, isEditMode } = useContent();

  return (
    <section id="gallery" className="py-20 bg-slate-50 border-t border-slate-200 text-slate-900 relative">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <Deletable id="gallery.badge" label="গ্যালারি ব্যাজ">
            <span className="inline-block bg-[#166D74] text-white font-black px-4 py-1 rounded-full text-xs uppercase tracking-wider shadow-sm mb-3">
              {lang === 'bn' ? 'ফটো ও অফিস গ্যালারি' : 'Photo & Office Gallery'}
            </span>
          </Deletable>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">
            <EditableText
              id="gallery.title"
              label="গ্যালারি টাইটেল"
              value={lang === 'bn' ? 'অফিস পরিবেশ ও সাফল্যের মুহূর্ত' : 'Our Brand, Office & Travel Moments'}
              onSave={() => {}}
            />
          </h2>
          <div className="text-slate-600 mt-2 text-sm leading-relaxed">
            <EditableText
              id="gallery.subtitle"
              label="গ্যালারি সাবটাইটেল"
              value={
                lang === 'bn'
                  ? 'সুনামগঞ্জ ষোলঘর পয়েন্টে অবস্থিত আমাদের অফিস ও সেবাগ্রহীতাদের আস্থার প্রতিচ্ছবি।'
                  : 'Glimpses of our Sunamganj office, verified visa milestones, and traveler journeys.'
              }
              onSave={() => {}}
            />
          </div>

          {isEditMode && (
            <div className="mt-4">
              <button
                onClick={() => {
                  addGalleryItem({
                    id: Date.now(),
                    type: 'travel',
                    titleBn: 'নতুন ভিসা ডকুমেন্টেশন মুহূর্ত',
                    titleEn: 'New Documentation Milestone',
                    image: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80',
                    tagBn: 'ভিসা ও টিকিট',
                    tagEn: 'Visa & Tickets'
                  });
                }}
                className="px-4 py-2 bg-[#166D74] hover:bg-[#0E585E] text-white font-black text-xs rounded-xl shadow-md inline-flex items-center gap-1.5 transition cursor-pointer"
              >
                <Plus className="w-4 h-4 text-white" />
                <span>+ নতুন ছবি যোগ করুন (Add Photo)</span>
              </button>
            </div>
          )}
        </div>

        {/* Gallery Grid - Fixed 3 Columns on PC and Phone */}
        <div className="grid grid-cols-3 gap-6">
          {content.gallery.map((item, idx) => (
            <Deletable key={item.id} id={`gallery.card.${item.id}`} label={`ছবি: ${item.titleBn}`}>
              <div
                className="group relative rounded-3xl overflow-hidden shadow-md border-2 border-slate-200 hover:border-[#166D74] transition duration-300 h-72 bg-slate-200"
              >
                {isEditMode && (
                  <button
                    onClick={() => deleteGalleryItem(idx)}
                    title="এই ছবিটি মুছুন (Delete this photo)"
                    className="absolute top-3 right-3 z-30 bg-white/90 text-red-600 border border-red-500 hover:bg-red-500 hover:text-white p-1.5 rounded-full shadow-lg transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}

                <img
                  src={item.image}
                  alt={item.titleEn}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/30 to-transparent" />
                
                {/* Tag */}
                <Deletable id={`gallery.tag.${item.id}`} inline label={`ট্যাগ: ${item.tagBn}`}>
                  <div className="absolute top-4 left-4 bg-white/95 text-[#166D74] border border-[#166D74]/40 text-[11px] font-black px-3 py-1 rounded-full shadow-sm backdrop-blur-sm">
                    <EditableText
                      id={`gallery.tagText.${item.id}`}
                      label="ট্যাগ টেক্সট"
                      value={lang === 'bn' ? item.tagBn : item.tagEn}
                      onSave={(val) => {
                        if (lang === 'bn') updateGalleryItem(idx, { ...item, tagBn: val });
                        else updateGalleryItem(idx, { ...item, tagEn: val });
                      }}
                    />
                  </div>
                </Deletable>

                {/* Title overlay */}
                <div className="absolute bottom-4 left-4 right-4">
                  <p className="text-white font-bold text-sm leading-snug">
                    <EditableText
                      id={`gallery.titleText.${item.id}`}
                      label="ছবির ক্যাপশন"
                      value={lang === 'bn' ? item.titleBn : item.titleEn}
                      onSave={(val) => {
                        if (lang === 'bn') updateGalleryItem(idx, { ...item, titleBn: val });
                        else updateGalleryItem(idx, { ...item, titleEn: val });
                      }}
                    />
                  </p>
                </div>
              </div>
            </Deletable>
          ))}
        </div>

      </div>
    </section>
  );
};
