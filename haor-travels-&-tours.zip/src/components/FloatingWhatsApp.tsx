import React, { useState } from 'react';
import { MessageCircle, X, Edit3 } from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';

interface FloatingWhatsAppProps {
  lang: 'bn' | 'en';
}

export const FloatingWhatsApp: React.FC<FloatingWhatsAppProps> = ({ lang }) => {
  const { content, updateFloatingWhatsApp, isEditMode, isAdminAuthenticated } = useContent();
  const [showTooltip, setShowTooltip] = useState(true);

  const canEdit = isEditMode && isAdminAuthenticated;

  const floatingPhone = content.numbers?.floatingWhatsApp?.phone || content.agencyInfo.phone;
  const floatingWhatsAppLink = content.numbers?.floatingWhatsApp?.whatsappLink || `https://wa.me/88${floatingPhone}`;

  return (
    <Deletable id="floating.whatsappWidget" label="ভাসমান হোয়াটসঅ্যাপ বাটন">
      <div className="fixed bottom-8 right-8 z-50 flex flex-col items-end">
        {/* Helper tooltip */}
        {showTooltip && (
          <Deletable id="floating.tooltip" label="হোয়াটসঅ্যাপ টুলটিপ">
            <div className="flex flex-col gap-1 bg-white text-slate-900 text-xs py-2 px-3.5 rounded-xl shadow-2xl border-2 border-[#166D74] mb-2 font-bold max-w-xs">
              <div className="flex items-center justify-between gap-2">
                <EditableText
                  id="floating.tooltipText"
                  label="টুলটিপ টেক্সট"
                  value={lang === 'bn' ? (content.numbers?.floatingWhatsApp?.labelBn || 'সরাসরি WhatsApp-এ কথা বলুন') : (content.numbers?.floatingWhatsApp?.labelEn || 'Chat with us on WhatsApp')}
                  onSave={(val) => {
                    if (lang === 'bn') updateFloatingWhatsApp({ labelBn: val });
                    else updateFloatingWhatsApp({ labelEn: val });
                  }}
                />
                <button
                  onClick={() => setShowTooltip(false)}
                  className="text-slate-400 hover:text-slate-900 cursor-pointer ml-1 p-0.5"
                  aria-label="Dismiss tooltip"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* In Edit mode: separate number edit */}
              {canEdit && (
                <div className="pt-1.5 mt-1 border-t border-slate-100 flex items-center justify-between text-[11px] text-[#166D74]">
                  <span className="font-bold">ভাসমান WA নম্বর:</span>
                  <EditableText
                    id="floating.phoneNumber"
                    label="ভাসমান হোয়াটসঅ্যাপ নম্বর"
                    value={floatingPhone}
                    onSave={(val) => updateFloatingWhatsApp({ phone: val })}
                  />
                </div>
              )}
            </div>
          </Deletable>
        )}

        {/* Floating button */}
        <a
          href={floatingWhatsAppLink}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Open WhatsApp chat with Haor Travels & Tours"
          className="w-14 h-14 bg-[#166D74] hover:bg-[#0E585E] text-white rounded-full flex items-center justify-center text-3xl shadow-2xl whatsapp-pulse-logo transition hover:scale-105 active:scale-95 cursor-pointer relative group"
        >
          <Deletable id="floating.whatsappIcon" inline label="ভাসমান হোয়াটসঅ্যাপ আইকন">
            <MessageCircle className="w-7 h-7 fill-white text-white" />
          </Deletable>
        </a>
      </div>
    </Deletable>
  );
};
