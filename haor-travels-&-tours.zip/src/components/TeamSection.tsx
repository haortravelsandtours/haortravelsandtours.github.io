import React, { useState } from 'react';
import { 
  Users, 
  Phone, 
  MessageCircle, 
  Award, 
  Plus, 
  Trash2, 
  Image as ImageIcon, 
  Check, 
  X, 
  Sparkles,
  ChevronDown
} from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';
import { TeamMember } from '../data/content';

interface TeamSectionProps {
  lang: 'bn' | 'en';
}

export const TeamSection: React.FC<TeamSectionProps> = ({ lang }) => {
  const { 
    content, 
    updateTeamMember, 
    addTeamMember, 
    deleteTeamMember, 
    isEditMode, 
    isAdminAuthenticated 
  } = useContent();

  const [editingImageMemberId, setEditingImageMemberId] = useState<string | null>(null);
  const [imageUrlDraft, setImageUrlDraft] = useState('');
  const [showAddMenu, setShowAddMenu] = useState(false);

  const canEdit = isEditMode && isAdminAuthenticated;

  const handleAddMember = (presetType: 'officer' | 'consultant' | 'coordinator' | 'custom') => {
    const id = `team-${Date.now()}`;
    let newMember: TeamMember;

    if (presetType === 'officer') {
      newMember = {
        id,
        nameBn: 'ভিসা প্রসেসিং অফিসার',
        nameEn: 'Visa Processing Officer',
        roleBn: 'ভিসা ও ডকুমেন্টেশন স্পেশালিস্ট',
        roleEn: 'Visa & Documentation Specialist',
        titleBn: 'Haor Travels & Tours',
        titleEn: 'Haor Travels & Tours',
        image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=800&q=80',
        experienceBn: '৬+ বছর',
        experienceEn: '6+ Years',
        bioBn: 'মালয়েশিয়া ও মধ্যপ্রাচ্যের ভিসা আবেদন, বায়োমেট্রিক ও পেপারস ভেরিফিকেশনে বিশেষজ্ঞ। প্রতিটি ক্লায়েন্টের ফাইল অত্যন্ত সতর্কতার সাথে প্রস্তুত করেন।',
        bioEn: 'Specializes in overseas work permits, bio-metrics, and embassy document endorsements with 6+ years of dedicated service.',
        phone: content.agencyInfo.phone,
        whatsapp: content.agencyInfo.whatsappLink
      };
    } else if (presetType === 'consultant') {
      newMember = {
        id,
        nameBn: 'সিনিয়র কনসালট্যান্ট',
        nameEn: 'Senior Travel Consultant',
        roleBn: 'ইউরোপ ও স্টুডেন্ট ভিসা ডেস্ক',
        roleEn: 'Europe & Study Abroad Desk',
        titleBn: 'Haor Travels & Tours',
        titleEn: 'Haor Travels & Tours',
        image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80',
        experienceBn: '৫+ বছর',
        experienceEn: '5+ Years',
        bioBn: 'উচ্চশিক্ষা, ইউরোপ স্টুডেন্ট ভিসা এবং ফ্যামিলি ভিজিট ভিসা প্রসেসিংয়ে দক্ষ পরামর্শক। অফার লেটার থেকে ফ্লাইট পর্যন্ত সার্বক্ষণিক দিকনির্দেশনা দেন।',
        bioEn: 'Expert guidance on university applications, statement of purpose, and European visa processing for Bangladeshi students.',
        phone: content.agencyInfo.phone,
        whatsapp: content.agencyInfo.whatsappLink
      };
    } else if (presetType === 'coordinator') {
      newMember = {
        id,
        nameBn: 'কুয়ালালামপুর সমন্বয়ক',
        nameEn: 'Kuala Lumpur Coordinator',
        roleBn: 'মালয়েশিয়া লিয়াজোঁ ও অন-গ্রাউন্ড সাপোর্ট',
        roleEn: 'Malaysia Liaison & On-Ground Support',
        titleBn: 'Haor Travels & Tours',
        titleEn: 'Haor Travels & Tours',
        image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
        experienceBn: '৭+ বছর',
        experienceEn: '7+ Years',
        bioBn: 'মালয়েশিয়ায় অবস্থানরত কর্মীদের এয়ারপোর্ট রিসিপশন, কোম্পানির চুক্তিপত্র এবং সার্বিক অন-গ্রাউন্ড সহযোগিতায় নিয়োজিত।',
        bioEn: 'Overseas ground support in Malaysia, managing airport reception, employer coordination, and workforce assistance.',
        phone: content.agencyInfo.phone,
        whatsapp: content.agencyInfo.whatsappLink
      };
    } else {
      newMember = {
        id,
        nameBn: 'নতুন টিম মেম্বার',
        nameEn: 'New Team Member',
        roleBn: 'ট্রাভেল ও ভিসা কনসালট্যান্ট',
        roleEn: 'Travel & Visa Consultant',
        titleBn: 'Haor Travels & Tours',
        titleEn: 'Haor Travels & Tours',
        image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=800&q=80',
        experienceBn: '৩+ বছর',
        experienceEn: '3+ Years',
        bioBn: 'গ্রাহকদের আন্তরিক পরামর্শ ও সেবা প্রদানে অঙ্গীকারবদ্ধ। সঠিক নিয়মে ভিসা আবেদন প্রক্রিয়ায় সহযোগিতা করেন।',
        bioEn: 'Dedicated to helping clients achieve their overseas goals with precision and care.',
        phone: content.agencyInfo.phone,
        whatsapp: content.agencyInfo.whatsappLink
      };
    }

    addTeamMember(newMember);
    setShowAddMenu(false);
  };

  const handleDeleteMember = (member: TeamMember) => {
    if (window.confirm(
      lang === 'bn' 
        ? `আপনি কি নিশ্চিতভাবে "${member.nameBn}"-কে টিম থেকে ডিলিট করতে চান?` 
        : `Are you sure you want to delete "${member.nameEn}" from the team?`
    )) {
      deleteTeamMember(member.id);
    }
  };

  const openImageModal = (member: TeamMember) => {
    setEditingImageMemberId(member.id);
    setImageUrlDraft(member.image);
  };

  const saveImageModal = () => {
    if (editingImageMemberId && imageUrlDraft.trim()) {
      updateTeamMember(editingImageMemberId, { image: imageUrlDraft.trim() });
    }
    setEditingImageMemberId(null);
  };

  const imagePresets = [
    { label: 'প্রতিষ্ঠাতা (Founder)', url: content.agencyInfo.founderImage },
    { label: 'মার্কেটিং (Manager)', url: content.agencyInfo.marketingImage },
    { label: 'অফিসার (Male Professional)', url: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=800&q=80' },
    { label: 'কনসালট্যান্ট (Female Consultant)', url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80' },
    { label: 'এক্সিকিউটিভ (Young Executive)', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80' },
  ];

  return (
    <section id="team" className="py-20 bg-slate-50 text-slate-900 relative border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <Deletable id="team.badge" label="টিম ব্যাজ">
            <span className="inline-flex items-center gap-2 bg-[#166D74] text-white font-black px-4 py-1.5 rounded-full text-xs uppercase tracking-wider shadow-sm mb-3">
              <Deletable id="team.badgeIcon" inline label="টিম আইকন">
                <Users className="w-4 h-4 text-white" />
              </Deletable>
              <span>{lang === 'bn' ? 'আমাদের নেতৃত্ব ও টিম' : 'Our Leadership Team'}</span>
            </span>
          </Deletable>
          <h2 className="text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            <EditableText
              id="team.title"
              label="টিম টাইটেল"
              value={lang === 'bn' ? 'অভিজ্ঞ ও নিবেদিতপ্রাণ পরিচালনা পর্ষদ' : 'Dedicated Leadership for Your Safe Journey'}
              onSave={() => {}}
            />
          </h2>
          <div className="text-slate-600 mt-3 text-base leading-relaxed">
            <EditableText
              id="team.subtitle"
              label="টিম সাবটাইটেল"
              value={
                lang === 'bn'
                  ? 'যাদের দূরদর্শিতা ও সততায় ২০০৮ সাল থেকে সুনামের সাথে পরিচালিত হয়ে আসছে হাওর ট্রাভেলস অ্যান্ড ট্যুরস।'
                  : 'The visionaries steering Haor Travels & Tours with 17+ years of integrity, authenticity, and personal client care.'
              }
              onSave={() => {}}
            />
          </div>

          {/* Add Team Member Control in Edit Mode */}
          {canEdit && (
            <div className="mt-6 flex flex-col items-center">
              <div className="relative inline-block">
                <button
                  onClick={() => setShowAddMenu((prev) => !prev)}
                  className="bg-[#166D74] hover:bg-[#0E585E] text-white font-black px-5 py-2.5 rounded-2xl text-xs flex items-center gap-2 shadow-md cursor-pointer transition hover:scale-105"
                >
                  <Plus className="w-4 h-4 text-white stroke-[3]" />
                  <span>{lang === 'bn' ? '+ নতুন টিম মেম্বার যোগ করুন (Add Member)' : '+ Add Team Member'}</span>
                  <ChevronDown className="w-3.5 h-3.5 text-white" />
                </button>

                {showAddMenu && (
                  <div className="absolute left-1/2 -translate-x-1/2 mt-2 w-80 bg-white border-2 border-[#166D74] rounded-2xl p-3 shadow-2xl z-40 space-y-1 text-left">
                    <p className="text-[10px] font-black uppercase text-[#166D74] px-3 py-1">
                      {lang === 'bn' ? 'টিম মেম্বারের ধরন নির্বাচন করুন:' : 'Select Member Preset:'}
                    </p>
                    <button
                      onClick={() => handleAddMember('officer')}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-slate-800 hover:bg-[#166D74] hover:text-white transition flex items-center gap-2"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#166D74]" />
                      <span>{lang === 'bn' ? '+ ভিসা প্রসেসিং অফিসার' : '+ Visa Processing Officer'}</span>
                    </button>
                    <button
                      onClick={() => handleAddMember('consultant')}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-slate-800 hover:bg-[#166D74] hover:text-white transition flex items-center gap-2"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#166D74]" />
                      <span>{lang === 'bn' ? '+ সিনিয়র কনসালট্যান্ট (Europe Desk)' : '+ Senior Consultant (Europe)'}</span>
                    </button>
                    <button
                      onClick={() => handleAddMember('coordinator')}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-slate-800 hover:bg-[#166D74] hover:text-white transition flex items-center gap-2"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#166D74]" />
                      <span>{lang === 'bn' ? '+ কুয়ালালামপুর সমন্বয়ক' : '+ KL Office Coordinator'}</span>
                    </button>
                    <button
                      onClick={() => handleAddMember('custom')}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold text-[#166D74] hover:bg-slate-100 border border-slate-200 transition flex items-center gap-2"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{lang === 'bn' ? '+ কাস্টম টিম মেম্বার' : '+ Custom Member'}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Leadership Grid - Fixed 2 Columns side-by-side on all devices */}
        <div className="grid grid-cols-2 gap-8 max-w-6xl mx-auto">
          {content.team.map((member) => (
            <Deletable key={member.id} id={`team.card.${member.id}`} label={`টিম মেম্বার: ${member.nameBn}`}>
              <div
                className="bg-white border-2 border-slate-200 hover:border-[#166D74] rounded-3xl overflow-hidden shadow-lg transition duration-300 group flex flex-col justify-between relative h-full"
              >
                {/* Delete Button in Edit Mode */}
                {canEdit && (
                  <button
                    onClick={() => handleDeleteMember(member)}
                    title={lang === 'bn' ? 'এই টিম মেম্বারকে মুছুন' : 'Delete this team member'}
                    className="absolute top-4 right-4 z-30 p-2 rounded-xl bg-white/90 border border-red-500 hover:bg-red-500 text-red-600 hover:text-white shadow-xl transition cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}

                {/* Photo Container - Exact same large size on PC and Phone */}
                <div className="relative h-96 w-full overflow-hidden bg-slate-100">
                  <img
                    src={member.image}
                    alt={member.nameEn}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent" />

                  {/* Change Photo Button in Edit Mode */}
                  {canEdit && (
                    <button
                      onClick={() => openImageModal(member)}
                      className="absolute bottom-5 left-5 z-20 bg-white/95 hover:bg-[#166D74] hover:text-white text-slate-900 text-[11px] font-black px-3 py-1.5 rounded-xl border border-slate-300 flex items-center gap-1.5 shadow-lg transition cursor-pointer backdrop-blur-sm"
                    >
                      <ImageIcon className="w-3.5 h-3.5" />
                      <span>{lang === 'bn' ? 'ছবি পরিবর্তন' : 'Change Photo'}</span>
                    </button>
                  )}

                  {/* Role Badge in Photo */}
                  <Deletable id={`team.roleBadge.${member.id}`} inline label={`পদবি ব্যাজ: ${member.nameBn}`}>
                    <div className="absolute top-5 left-5 bg-[#166D74] text-white font-black px-4 py-1.5 rounded-full text-xs flex items-center gap-2 shadow-lg">
                      <Award className="w-4 h-4 text-white" />
                      <EditableText
                        id={`team.roleText.${member.id}`}
                        label="পদবি টেক্সট"
                        value={lang === 'bn' ? member.roleBn : member.roleEn}
                        onSave={(val) => {
                          if (lang === 'bn') updateTeamMember(member.id, { roleBn: val });
                          else updateTeamMember(member.id, { roleEn: val });
                        }}
                      />
                    </div>
                  </Deletable>

                  {/* Experience Badge */}
                  <Deletable id={`team.expBadge.${member.id}`} inline label={`অভিজ্ঞতা ব্যাজ: ${member.nameBn}`}>
                    <div className="absolute bottom-5 right-5 bg-white/95 border border-[#166D74] text-[#166D74] font-black px-4 py-1.5 rounded-xl text-xs shadow-lg backdrop-blur-sm">
                      <span>
                        {lang === 'bn' ? 'অভিজ্ঞতা: ' : 'Exp: '}
                        <EditableText
                          id={`team.expText.${member.id}`}
                          label="অভিজ্ঞতা টেক্সট"
                          value={lang === 'bn' ? member.experienceBn : member.experienceEn}
                          onSave={(val) => {
                            if (lang === 'bn') updateTeamMember(member.id, { experienceBn: val });
                            else updateTeamMember(member.id, { experienceEn: val });
                          }}
                        />
                      </span>
                    </div>
                  </Deletable>
                </div>

                {/* Bio & Details */}
                <div className="p-8 text-left space-y-5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-3xl font-black text-slate-900 group-hover:text-[#166D74] transition">
                      <EditableText
                        id={`team.name.${member.id}`}
                        label="টিম মেম্বারের নাম"
                        value={lang === 'bn' ? member.nameBn : member.nameEn}
                        onSave={(val) => {
                          if (lang === 'bn') updateTeamMember(member.id, { nameBn: val });
                          else updateTeamMember(member.id, { nameEn: val });
                        }}
                      />
                    </h3>
                    <div className="text-[#166D74] font-bold text-xs uppercase tracking-wider mt-1">
                      <EditableText
                        id={`team.title.${member.id}`}
                        label="টিম মেম্বার টাইটেল"
                        value={lang === 'bn' ? member.titleBn : member.titleEn}
                        onSave={(val) => {
                          if (lang === 'bn') updateTeamMember(member.id, { titleBn: val });
                          else updateTeamMember(member.id, { titleEn: val });
                        }}
                      />
                    </div>

                    <div className="text-slate-600 text-sm mt-4 leading-relaxed font-medium">
                      <EditableText
                        id={`team.bio.${member.id}`}
                        label="টিম মেম্বার পরিচিতি"
                        multiline
                        value={lang === 'bn' ? member.bioBn : member.bioEn}
                        onSave={(val) => {
                          if (lang === 'bn') updateTeamMember(member.id, { bioBn: val });
                          else updateTeamMember(member.id, { bioEn: val });
                        }}
                      />
                    </div>
                  </div>

                  {/* Editable Phone & WhatsApp in Edit Mode */}
                  {canEdit && (
                    <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500 font-bold">ফোন নম্বর:</span>
                        <EditableText
                          id={`team.phone.${member.id}`}
                          label="ফোন নম্বর"
                          value={member.phone}
                          onSave={(val) => updateTeamMember(member.id, { phone: val })}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500 font-bold">WhatsApp লিংক:</span>
                        <EditableText
                          id={`team.wa.${member.id}`}
                          label="WhatsApp লিংক"
                          value={member.whatsapp}
                          onSave={(val) => updateTeamMember(member.id, { whatsapp: val })}
                        />
                      </div>
                    </div>
                  )}

                  {/* Action Buttons: Slate-100 (Call) & Logo Color #166D74 (WhatsApp) */}
                  <Deletable id={`team.actions.${member.id}`} label={`অ্যাকশন বাটন: ${member.nameBn}`}>
                    <div className="pt-4 border-t border-slate-200 flex flex-row gap-3">
                      <a
                        href={`tel:${member.phone}`}
                        className="flex-1 inline-flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 font-black rounded-xl text-sm py-3 px-4 shadow-sm transition cursor-pointer"
                      >
                        <Phone className="w-4 h-4 text-slate-700" />
                        <span>{lang === 'bn' ? 'সরাসরি কল করুন' : 'Call Directly'}</span>
                      </a>

                      <a
                        href={member.whatsapp}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 inline-flex items-center justify-center gap-2 bg-[#166D74] hover:bg-[#0E585E] text-white font-black rounded-xl text-sm py-3 px-4 shadow-md transition cursor-pointer"
                      >
                        <MessageCircle className="w-4 h-4 fill-white text-white" />
                        <span>WhatsApp</span>
                      </a>
                    </div>
                  </Deletable>
                </div>
              </div>
            </Deletable>
          ))}
        </div>

        {/* Leadership Commitment Quote */}
        <Deletable id="team.commitment" label="পরিচালকদের অঙ্গীকার বক্স">
          <div className="max-w-4xl mx-auto mt-14 p-8 rounded-2xl bg-white border-2 border-[#166D74] text-center space-y-2 shadow-lg">
            <p className="text-[#166D74] font-black text-sm uppercase tracking-wider">
              {lang === 'bn' ? 'আমাদের পরিচালকদের অঙ্গিকার' : 'Our Leadership Commitment'}
            </p>
            <p className="text-lg text-slate-900 font-bold leading-relaxed">
              {lang === 'bn'
                ? '“প্রতিটি ক্লায়েন্ট আমাদের পরিবারের সদস্যের মতো। আপনার উপার্জিত অর্থ ও সোনালী ভবিষ্যৎ রক্ষায় আমরা শতভাগ স্বচ্ছতা বজায় রাখি।”'
                : '“Every client is treated with the highest integrity as our own family. We protect your hard-earned investment and future through authentic, verified consultancy.”'}
            </p>
          </div>
        </Deletable>

      </div>

      {/* Photo Picker Modal */}
      {editingImageMemberId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white border-2 border-[#166D74] rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl text-slate-900">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h4 className="font-black text-slate-900 text-base">
                {lang === 'bn' ? 'টিম সদস্যের ছবি পরিবর্তন' : 'Change Member Photo'}
              </h4>
              <button 
                onClick={() => setEditingImageMemberId(null)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  {lang === 'bn' ? 'ছবির URL বা পাথ:' : 'Image URL / Path:'}
                </label>
                <input
                  type="text"
                  value={imageUrlDraft}
                  onChange={(e) => setImageUrlDraft(e.target.value)}
                  placeholder="https://... or /assets/..."
                  className="w-full bg-slate-50 border border-slate-300 focus:border-[#166D74] text-slate-900 p-2.5 rounded-xl text-xs font-mono"
                />
              </div>

              <div>
                <p className="text-xs font-bold text-slate-500 mb-2">
                  {lang === 'bn' ? 'অথবা রেডিমেড ছবি নির্বাচন করুন:' : 'Or Select From Presets:'}
                </p>
                <div className="space-y-1.5">
                  {imagePresets.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setImageUrlDraft(preset.url)}
                      className={`w-full text-left p-2 rounded-xl text-xs flex items-center justify-between transition border ${
                        imageUrlDraft === preset.url
                          ? 'bg-[#166D74] text-white border-[#166D74] font-bold'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-[#166D74]/50'
                      }`}
                    >
                      <span>{preset.label}</span>
                      {imageUrlDraft === preset.url && <Check className="w-4 h-4 text-white" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 border-t border-slate-200">
              <button
                onClick={() => setEditingImageMemberId(null)}
                className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2.5 rounded-xl text-xs border border-slate-300 transition"
              >
                {lang === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={saveImageModal}
                className="flex-1 bg-[#166D74] hover:bg-[#0E585E] text-white font-black py-2.5 rounded-xl text-xs shadow transition"
              >
                {lang === 'bn' ? 'সংরক্ষণ করুন' : 'Save Photo'}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
