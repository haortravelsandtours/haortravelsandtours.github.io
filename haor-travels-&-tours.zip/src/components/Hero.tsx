import React from 'react';
import { 
  Phone, 
  MessageCircle, 
  CheckCircle2, 
  ArrowRight, 
  Award, 
  Plane, 
  FileCheck, 
  Sparkles 
} from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';

interface HeroProps {
  lang: 'bn' | 'en';
  onExploreServices: () => void;
  onOpenChecker: () => void;
}

export const Hero: React.FC<HeroProps> = ({ lang, onExploreServices, onOpenChecker }) => {
  const { content, updateHero, updateAgencyInfo } = useContent();

  const hotlinePhone = content.numbers?.headerHotline?.phone || '01712431613';
  const whatsappPhone = content.numbers?.floatingWhatsApp?.phone || content.numbers?.headerWhatsApp?.phone || '01914484627';

  return (
    <section id="home" className="relative bg-white text-slate-900 py-20 overflow-hidden border-b border-slate-200">
      {/* Subtle logo ambient accent glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#166D74]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-8 relative z-10 grid grid-cols-12 gap-12 items-center">
        {/* Left Column: Heading, Value proposition & CTAs (7 cols) */}
        <div className="col-span-7 space-y-6 text-left">
          {/* Trust badge */}
          <Deletable id="hero.badge" label="হিরো ট্রাস্ট ব্যাজ">
            <div className="inline-flex items-center gap-2 bg-[#166D74] text-white font-black px-4 py-1.5 rounded-full text-sm shadow-md">
              <Deletable id="hero.badgeIcon" inline label="ব্যাজ অ্যাওয়ার্ড আইকন">
                <Award className="w-4 h-4 text-white" />
              </Deletable>
              <EditableText
                id="hero.badgeText"
                label="হিরো ব্যাজ টেক্সট"
                value={lang === 'bn' ? content.hero.badgeBn : content.hero.badgeEn}
                onSave={(val) => {
                  if (lang === 'bn') updateHero({ badgeBn: val });
                  else updateHero({ badgeEn: val });
                }}
              />
            </div>
          </Deletable>

          <h1 className="text-5xl lg:text-6xl font-black tracking-tight leading-[1.15] text-slate-900">
            <EditableText
              id="hero.titleLine1"
              label="হিরো টাইটেল লাইন ১"
              value={lang === 'bn' ? content.hero.titleLine1Bn : content.hero.titleLine1En}
              onSave={(val) => {
                if (lang === 'bn') updateHero({ titleLine1Bn: val });
                else updateHero({ titleLine1En: val });
              }}
            />
            <br />
            <span className="text-[#166D74]">
              <EditableText
                id="hero.titleLine2"
                label="হিরো টাইটেল লাইন ২"
                value={lang === 'bn' ? content.hero.titleLine2Bn : content.hero.titleLine2En}
                onSave={(val) => {
                  if (lang === 'bn') updateHero({ titleLine2Bn: val });
                  else updateHero({ titleLine2En: val });
                }}
              />
            </span>
          </h1>

          <div className="text-slate-600 text-lg max-w-2xl leading-relaxed font-normal">
            <EditableText
              id="hero.subtitle"
              label="হিরো সাবটাইটেল"
              multiline
              value={lang === 'bn' ? content.hero.subtitleBn : content.hero.subtitleEn}
              onSave={(val) => {
                if (lang === 'bn') updateHero({ subtitleBn: val });
                else updateHero({ subtitleEn: val });
              }}
            />
          </div>

          {/* Core Action Buttons */}
          <div className="flex flex-row items-center gap-4 pt-2">
            <Deletable id="hero.whatsappBtn" label="হিরো হোয়াটসঅ্যাপ বাটন">
              <a
                href={`https://wa.me/88${whatsappPhone}?text=${encodeURIComponent(
                  'Assalamu Alaikum, I would like to consult regarding visa processing with Haor Travels & Tours.'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 bg-[#166D74] hover:bg-[#0E585E] text-white font-black rounded-xl text-base px-7 py-4 shadow-xl transition hover:-translate-y-0.5 active:translate-y-0"
              >
                <Deletable id="hero.whatsappIcon" inline label="হোয়াটসঅ্যাপ আইকন">
                  <MessageCircle className="w-5 h-5 fill-white text-white" />
                </Deletable>
                <span>WhatsApp: {whatsappPhone}</span>
              </a>
            </Deletable>

            <Deletable id="hero.callBtn" label="হিরো হটলাইন কল বাটন">
              <a
                href={`tel:${hotlinePhone}`}
                className="inline-flex items-center justify-center gap-2.5 bg-slate-900 hover:bg-[#166D74] text-white font-black rounded-xl text-base px-7 py-4 shadow-xl transition hover:-translate-y-0.5 active:translate-y-0"
              >
                <Deletable id="hero.callIcon" inline label="হটলাইন কল আইকন">
                  <Phone className="w-5 h-5 text-white" />
                </Deletable>
                <span>{lang === 'bn' ? `হটলাইন: ${hotlinePhone}` : `Call: ${hotlinePhone}`}</span>
              </a>
            </Deletable>

            <Deletable id="hero.checkerBtn" label="যোগ্যতা যাচাই বাটন">
              <button
                onClick={onOpenChecker}
                className="inline-flex items-center justify-center gap-2 bg-white hover:bg-slate-50 text-[#166D74] border-2 border-[#166D74] font-black rounded-xl text-base px-6 py-4 transition cursor-pointer shadow-sm"
              >
                <Deletable id="hero.checkerIcon" inline label="যাচাই আইকন">
                  <FileCheck className="w-5 h-5 text-[#166D74]" />
                </Deletable>
                <span>{lang === 'bn' ? 'যোগ্যতা যাচাই' : 'Check Eligibility'}</span>
              </button>
            </Deletable>
          </div>

          {/* Trust bullets */}
          <div className="pt-2 flex flex-row items-center gap-6 text-sm text-slate-700 font-semibold">
            <Deletable id="hero.bullet1" label="বুলেট ১">
              <span className="inline-flex items-center gap-2">
                <Deletable id="hero.bullet1Icon" inline label="বুলেট ১ আইকন">
                  <CheckCircle2 className="w-4 h-4 text-[#166D74]" />
                </Deletable>
                <EditableText
                  id="hero.bullet1Text"
                  label="বুলেট ১ টেক্সট"
                  value={lang === 'bn' ? '১০০% সঠিক ও বৈধ প্রসেসিং' : '100% Genuine Processing'}
                  onSave={() => {}}
                />
              </span>
            </Deletable>
            <Deletable id="hero.bullet2" label="বুলেট ২">
              <span className="inline-flex items-center gap-2">
                <Deletable id="hero.bullet2Icon" inline label="বুলেট ২ আইকন">
                  <CheckCircle2 className="w-4 h-4 text-[#166D74]" />
                </Deletable>
                <EditableText
                  id="hero.bullet2Text"
                  label="বুলেট ২ টেক্সট"
                  value={lang === 'bn' ? 'মালয়েশিয়া ওয়ার্ক পারমিট স্পেশালিস্ট' : 'Malaysia Work Specialists'}
                  onSave={() => {}}
                />
              </span>
            </Deletable>
            <Deletable id="hero.bullet3" label="বুলেট ৩">
              <span className="inline-flex items-center gap-2">
                <Deletable id="hero.bullet3Icon" inline label="বুলেট ৩ আইকন">
                  <CheckCircle2 className="w-4 h-4 text-[#166D74]" />
                </Deletable>
                <EditableText
                  id="hero.bullet3Text"
                  label="বুলেট ৩ টেক্সট"
                  value={lang === 'bn' ? 'সুলভ মূল্যে নিশ্চিত এয়ার টিকিট' : 'Best Flight Fares'}
                  onSave={() => {}}
                />
              </span>
            </Deletable>
          </div>
        </div>

        {/* Right Column: Hero Visual Showcase with Official Logo (5 cols) */}
        <div className="col-span-5 relative w-full">
          <Deletable id="hero.showcaseCard" label="হিরো শো-কেস কার্ড">
            <div className="relative bg-slate-50 border-2 border-[#166D74]/30 rounded-3xl p-8 shadow-xl overflow-hidden">
              {/* Top brand header */}
              <div className="flex items-center justify-between border-b border-slate-200 pb-4 mb-6">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black text-[#166D74] uppercase tracking-wider">
                    <EditableText
                      id="hero.statusBadge"
                      label="স্ট্যাটাস ব্যাজ"
                      value={lang === 'bn' ? content.hero.statusBadgeBn : content.hero.statusBadgeEn}
                      onSave={(val) => {
                        if (lang === 'bn') updateHero({ statusBadgeBn: val });
                        else updateHero({ statusBadgeEn: val });
                      }}
                    />
                  </span>
                </div>
                <Deletable id="hero.estBadge" label="EST ব্যাজ">
                  <span className="text-xs font-black text-white bg-[#166D74] px-3 py-1 rounded-md">
                    EST. {content.agencyInfo.established}
                  </span>
                </Deletable>
              </div>

              {/* Official Logo Emblem Centered */}
              <div className="flex flex-col items-center text-center space-y-5">
                <Deletable id="hero.logoEmblem" label="অফিসিয়াল লোগো এমব্লেম">
                  <div className="relative group">
                    <div className="w-44 h-44 rounded-full overflow-hidden border-4 border-[#166D74] shadow-xl bg-white p-1">
                      <img 
                        src={content.agencyInfo.logoUrl} 
                        alt="Haor Travels & Tours Official Seal" 
                        className="w-full h-full object-cover rounded-full group-hover:scale-105 transition duration-300"
                      />
                    </div>
                    <Deletable id="hero.planeIcon" inline label="প্লেন আইকন">
                      <div className="absolute -bottom-2 -right-2 bg-[#166D74] text-white rounded-full p-2.5 shadow-lg">
                        <Plane className="w-5 h-5 text-white" />
                      </div>
                    </Deletable>
                  </div>
                </Deletable>

                <div>
                  <h2 className="text-2xl font-black text-slate-900">
                    <EditableText
                      id="hero.agencyName"
                      label="এজেন্সি নাম"
                      value={content.agencyInfo.name}
                      onSave={(val) => updateAgencyInfo({ name: val })}
                    />
                  </h2>
                  <p className="text-[#166D74] text-sm font-bold mt-1">
                    <EditableText
                      id="hero.tagline"
                      label="ট্যাগলাইন"
                      value={lang === 'bn' ? content.hero.taglineBn : content.hero.taglineEn}
                      onSave={(val) => {
                        if (lang === 'bn') updateHero({ taglineBn: val });
                        else updateHero({ taglineEn: val });
                      }}
                    />
                  </p>
                </div>

                {/* Office location highlight */}
                <Deletable id="hero.officeBox" label="অফিস লোকেশন বক্স">
                  <div className="w-full bg-white rounded-2xl p-5 border border-slate-200 text-left space-y-2 shadow-sm">
                    <div className="flex items-start gap-3">
                      <Deletable id="hero.sparkleIcon" inline label="স্পার্কল আইকন">
                        <div className="w-8 h-8 rounded-lg bg-[#166D74] text-white flex items-center justify-center shrink-0 mt-0.5">
                          <Sparkles className="w-4 h-4 text-white" />
                        </div>
                      </Deletable>
                      <div>
                        <p className="text-xs font-black text-[#166D74] uppercase tracking-wider">
                          {lang === 'bn' ? 'প্রধান কার্যালয়:' : 'Head Office:'}
                        </p>
                        <p className="text-sm font-medium text-slate-800 mt-0.5">
                          <EditableText
                            id="hero.officeAddress"
                            label="অফিস ঠিকানা টেক্সট"
                            value={lang === 'bn' ? content.agencyInfo.addressBn : content.agencyInfo.address}
                            onSave={(val) => {
                              if (lang === 'bn') updateAgencyInfo({ addressBn: val });
                              else updateAgencyInfo({ address: val });
                            }}
                          />
                        </p>
                      </div>
                    </div>
                  </div>
                </Deletable>
              </div>

              {/* Quick Service Link */}
              <Deletable id="hero.servicesLink" label="সার্ভিসেস লিংক বাটন">
                <div className="mt-6 text-center">
                  <button 
                    onClick={onExploreServices}
                    className="text-sm font-bold text-slate-700 hover:text-[#166D74] inline-flex items-center gap-2 transition cursor-pointer"
                  >
                    <span>{lang === 'bn' ? 'আমাদের ৫টি মূল সেবা বিস্তারিত দেখুন' : 'Explore All 5 Core Services'}</span>
                    <Deletable id="hero.servicesArrow" inline label="তীর আইকন">
                      <ArrowRight className="w-4 h-4 text-[#166D74]" />
                    </Deletable>
                  </button>
                </div>
              </Deletable>
            </div>
          </Deletable>
        </div>
      </div>

      {/* Bottom Key Stats Strip - Fixed 4 Columns */}
      <Deletable id="hero.statsStrip" label="পরিসংখ্যান স্ট্রিপ">
        <div className="max-w-7xl mx-auto px-8 mt-16 pt-8 border-t border-slate-200">
          <div className="grid grid-cols-4 gap-6 text-center">
            {content.stats.map((stat, idx) => (
              <Deletable key={idx} id={`hero.stat.${idx}`} label={`পরিসংখ্যান কার্ড ${idx + 1}`}>
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 shadow-sm">
                  <p className="text-4xl font-black text-[#166D74]">
                    <EditableText
                      id={`hero.stat.val.${idx}`}
                      label={`পরিসংখ্যান মান ${idx + 1}`}
                      value={lang === 'bn' ? stat.valueBn : stat.valueEn}
                      onSave={() => {}}
                    />
                  </p>
                  <p className="text-sm text-slate-700 font-bold mt-1.5">
                    <EditableText
                      id={`hero.stat.lbl.${idx}`}
                      label={`পরিসংখ্যান লেবেল ${idx + 1}`}
                      value={lang === 'bn' ? stat.labelBn : stat.labelEn}
                      onSave={() => {}}
                    />
                  </p>
                </div>
              </Deletable>
            ))}
          </div>
        </div>
      </Deletable>
    </section>
  );
};
