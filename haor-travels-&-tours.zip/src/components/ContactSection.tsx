import React, { useState } from 'react';
import { 
  Phone, 
  MapPin, 
  MessageCircle, 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  Clock 
} from 'lucide-react';
import { validatePhoneNumber, generateWhatsAppUrl } from '../utils/calculator';
import { useContent } from '../context/ContentContext';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';

interface ContactSectionProps {
  lang: 'bn' | 'en';
}

export const ContactSection: React.FC<ContactSectionProps> = ({ lang }) => {
  const { content, updateAgencyInfo, updateContactPageNumbers } = useContent();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('Malaysia');
  const [purpose, setPurpose] = useState('Work');
  const [message, setMessage] = useState('');
  
  const [phoneError, setPhoneError] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [submittedData, setSubmittedData] = useState<{
    name: string;
    phone: string;
    country: string;
    purpose: string;
    message: string;
  } | null>(null);

  const contactPhone = content.numbers?.contactPage?.phone || content.agencyInfo.phone;
  const contactWhatsAppPhone = content.numbers?.contactPage?.whatsappPhone || content.agencyInfo.whatsappNumber;
  const contactWhatsAppLink = content.numbers?.contactPage?.whatsappLink || `https://wa.me/88${contactWhatsAppPhone}`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validatePhoneNumber(phone)) {
      setPhoneError(
        lang === 'bn' 
          ? 'অনুগ্রহ করে সঠিক মোবাইল নাম্বার প্রদান করুন (যেমন: 01914484627)' 
          : 'Please enter a valid phone number (e.g. 01914484627)'
      );
      return;
    }
    setPhoneError('');

    const inquiry = { name, phone, country, purpose, message };
    setSubmittedData(inquiry);
    setSubmitted(true);

    // Reset fields
    setName('');
    setPhone('');
    setMessage('');
  };

  const openWhatsAppWithInquiry = () => {
    if (!submittedData) return;
    const url = generateWhatsAppUrl(contactWhatsAppPhone, {
      name: submittedData.name,
      phone: submittedData.phone,
      country: submittedData.country,
      service: submittedData.purpose,
      message: submittedData.message,
    });
    window.open(url, '_blank');
  };

  return (
    <section id="contact" className="py-20 bg-slate-50 border-t border-slate-200 text-slate-900 relative">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <Deletable id="contact.badge" label="যোগাযোগ ব্যাজ">
            <span className="inline-block bg-[#166D74] text-white font-black px-4 py-1 rounded-full text-xs uppercase tracking-wider shadow-sm mb-3">
              {lang === 'bn' ? 'যোগাযোগ করুন' : 'Get In Touch'}
            </span>
          </Deletable>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">
            <EditableText
              id="contact.title"
              label="যোগাযোগ টাইটেল"
              value={lang === 'bn' ? 'আমাদের সাথে সরাসরি কথা বলুন' : 'Reach Out to Our Sunamganj Office'}
              onSave={(val) => {}}
            />
          </h2>
          <p className="text-slate-600 mt-2 text-sm leading-relaxed">
            <EditableText
              id="contact.subtitle"
              label="যোগাযোগ সাবটাইটেল"
              value={
                lang === 'bn'
                  ? 'সুনামগঞ্জ অফিসে সরাসরি আসুন অথবা নিচের অনলাইন ফর্ম পূরণ করে এখনই আপনার ফাইল প্রসেস শুরু করুন।'
                  : 'Visit our Shologhar Point office in Sunamganj or send your query online for fast response.'
              }
              onSave={(val) => {}}
            />
          </p>
        </div>

        {/* 2-Column Grid: Contact Info + Map & Interactive Form - Fixed Side-by-Side (5 cols & 7 cols) on PC & Phone */}
        <div className="grid grid-cols-12 gap-8">
          
          {/* Left Column: Office Details & Map (5 cols) */}
          <div className="col-span-5 space-y-6">
            <Deletable id="contact.officeCard" label="অফিস তথ্য কার্ড">
              <div className="bg-white p-8 rounded-3xl shadow-lg border-2 border-slate-200 space-y-6">
                <h3 className="text-2xl font-black text-slate-900">
                  <EditableText
                    id="contact.officeCardTitle"
                    label="অফিস কার্ড হেডিং"
                    value={lang === 'bn' ? 'অফিসের বিবরণ ও ঠিকানা' : 'Office Information'}
                    onSave={(val) => {}}
                  />
                </h3>

                {/* Address */}
                <Deletable id="contact.addressRow" label="ঠিকানা ব্লক">
                  <div className="flex items-start gap-4">
                    <Deletable id="contact.addressIcon" inline label="ঠিকানা আইকন">
                      <div className="w-11 h-11 rounded-2xl bg-[#166D74] text-white flex items-center justify-center shrink-0 mt-0.5 shadow-md">
                        <MapPin className="w-5 h-5" />
                      </div>
                    </Deletable>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">
                        {lang === 'bn' ? 'প্রধান কার্যালয়ের ঠিকানা' : 'Headquarters Address'}
                      </h4>
                      <div className="text-slate-600 text-sm mt-1 leading-relaxed">
                        <EditableText
                          id="contact.addressText"
                          label="অফিস ঠিকানা"
                          value={lang === 'bn' ? content.agencyInfo.addressBn : content.agencyInfo.address}
                          onSave={(val) => {
                            if (lang === 'bn') updateAgencyInfo({ addressBn: val });
                            else updateAgencyInfo({ address: val });
                          }}
                          multiline
                        />
                      </div>
                    </div>
                  </div>
                </Deletable>

                {/* Phone Hotline (Separately Editable) */}
                <Deletable id="contact.phoneRow" label="হটলাইন ফোন ব্লক">
                  <div className="flex items-start gap-4">
                    <Deletable id="contact.phoneIcon" inline label="হটলাইন আইকন">
                      <div className="w-11 h-11 rounded-2xl bg-[#166D74] text-white flex items-center justify-center shrink-0 mt-0.5 shadow-md">
                        <Phone className="w-5 h-5" />
                      </div>
                    </Deletable>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">
                        {lang === 'bn' ? 'অফিসিয়াল ফোন / হটলাইন' : 'Official Hotline'}
                      </h4>
                      <div className="mt-1 font-black text-[#166D74] hover:text-[#0E585E] text-lg">
                        <EditableText
                          id="contact.hotlineNumber"
                          label="যোগাযোগ পেইজের নিজস্ব হটলাইন নম্বর"
                          value={contactPhone}
                          onSave={(val) => updateContactPageNumbers({ phone: val })}
                        />
                      </div>
                    </div>
                  </div>
                </Deletable>

                {/* Working Hours */}
                <Deletable id="contact.hoursRow" label="অফিস সময় ব্লক">
                  <div className="flex items-start gap-4">
                    <Deletable id="contact.clockIcon" inline label="ঘড়ি আইকন">
                      <div className="w-11 h-11 rounded-2xl bg-slate-100 border border-slate-200 text-[#166D74] flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                        <Clock className="w-5 h-5" />
                      </div>
                    </Deletable>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">
                        {lang === 'bn' ? 'অফিস খোলা থাকার সময়' : 'Working Hours'}
                      </h4>
                      <div className="text-slate-600 text-sm mt-1">
                        <EditableText
                          id="contact.hoursText"
                          label="অফিস সময় টেক্সট"
                          value={lang === 'bn' ? content.agencyInfo.openingHoursBn : content.agencyInfo.openingHoursEn}
                          onSave={(val) => {
                            if (lang === 'bn') updateAgencyInfo({ openingHoursBn: val });
                            else updateAgencyInfo({ openingHoursEn: val });
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </Deletable>

                {/* Fast WhatsApp Chat Button (Separately Editable WhatsApp Number) */}
                <Deletable id="contact.chatBtn" label="হোয়াটসঅ্যাপ চ্যাট বাটন">
                  <div className="pt-2">
                    <a
                      href={contactWhatsAppLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full bg-[#166D74] hover:bg-[#0E585E] text-white font-black rounded-xl text-sm py-3.5 px-4 shadow-md flex items-center justify-center gap-2 transition cursor-pointer"
                    >
                      <Deletable id="contact.chatIcon" inline label="চ্যাট আইকন">
                        <MessageCircle className="w-4 h-4 fill-white" />
                      </Deletable>
                      <span>
                        {lang === 'bn' 
                          ? `WhatsApp-এ চ্যাট করুন (${contactWhatsAppPhone})` 
                          : `Start WhatsApp Chat (${contactWhatsAppPhone})`}
                      </span>
                    </a>
                  </div>
                </Deletable>
              </div>
            </Deletable>

            {/* Embedded Google Map */}
            <Deletable id="contact.mapCard" label="গুগল ম্যাপ কার্ড">
              <div className="bg-white p-3 rounded-3xl shadow-lg border-2 border-slate-200 overflow-hidden">
                <div className="w-full h-56 rounded-2xl overflow-hidden bg-slate-100 relative">
                  <iframe
                    title="Haor Travels & Tours Sunamganj Location"
                    className="w-full h-full border-0"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14474.30818073369!2d91.3900!3d25.0680!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3750ca13d03c3913%3A0x6b107c11f4d92415!2sSunamganj!5e0!3m2!1sen!2sbd!4v1700000000000!5m2!1sen!2sbd"
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  />
                </div>
                <p className="text-[11px] text-slate-600 text-center mt-2 font-medium">
                  📍 {lang === 'bn' ? 'ষোলঘর পয়েন্ট, সুনামগঞ্জ, সিলেট - ৩০০০' : 'Shologhar Point, Sunamganj, Sylhet - 3000'}
                </p>
              </div>
            </Deletable>
          </div>

          {/* Right Column: Online Inquiry Form (7 cols) */}
          <div className="col-span-7">
            <Deletable id="contact.formCard" label="ইনকোয়ারি ফর্ম কার্ড">
              <div className="bg-white p-8 rounded-3xl shadow-lg border-2 border-[#166D74] flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-2xl font-black text-slate-900">
                      <EditableText
                        id="contact.formTitle"
                        label="ফর্ম টাইটেল"
                        value={lang === 'bn' ? 'অনলাইন ইনকোয়ারি ফর্ম' : 'Online Consultation Inquiry'}
                        onSave={(val) => {}}
                      />
                    </h3>
                    <Deletable id="contact.fastBadge" label="দ্রুত রেসপন্স ব্যাজ">
                      <span className="bg-[#166D74] text-white font-black text-xs px-3 py-1 rounded-full">
                        {lang === 'bn' ? 'দ্রুত রেসপন্স' : 'Fast Response'}
                      </span>
                    </Deletable>
                  </div>
                  <p className="text-slate-600 text-sm mb-6">
                    <EditableText
                      id="contact.formSubtitle"
                      label="ফর্ম সাবটাইটেল"
                      value={
                        lang === 'bn'
                          ? 'আপনার সঠিক তথ্য দিন, আমাদের প্রধান কার্যালয় থেকে অবিলম্বে আপনার সাথে ফোনে যোগাযোগ করা হবে।'
                          : 'Submit your query below. Our consultancy desk will follow up promptly via phone or WhatsApp.'
                      }
                      onSave={(val) => {}}
                    />
                  </p>
                </div>

              {/* Form Element */}
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Name */}
                <div>
                  <label htmlFor="inquiry-full-name" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    {lang === 'bn' ? 'আপনার নাম (Full Name) *' : 'Full Name *'}
                  </label>
                  <input
                    id="inquiry-full-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={lang === 'bn' ? 'যেমন: মোহাম্মদ রহিম' : 'e.g. Mohammad Rahim'}
                    className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 focus:outline-none focus:border-[#166D74] text-sm bg-slate-50 text-slate-900 placeholder-slate-400"
                  />
                </div>

                {/* Phone */}
                <div>
                  <label htmlFor="inquiry-phone-number" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    {lang === 'bn' ? 'মোবাইল / WhatsApp নাম্বার *' : 'Mobile / WhatsApp Number *'}
                  </label>
                  <input
                    id="inquiry-phone-number"
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => {
                      setPhone(e.target.value);
                      if (phoneError) setPhoneError('');
                    }}
                    placeholder="01914484627"
                    className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 focus:outline-none focus:border-[#166D74] text-sm bg-slate-50 text-slate-900 placeholder-slate-400"
                  />
                  {phoneError && (
                    <p className="text-xs text-red-600 font-bold mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 text-red-600" />
                      <span>{phoneError}</span>
                    </p>
                  )}
                </div>

                {/* 2-Column: Country + Purpose - Fixed Side-by-Side on PC & Phone */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="inquiry-target-country" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      {lang === 'bn' ? 'কাঙ্ক্ষিত দেশ (Target Country)' : 'Interested Country'}
                    </label>
                    <select
                      id="inquiry-target-country"
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 focus:outline-none focus:border-[#166D74] text-sm bg-slate-50 text-slate-900 font-medium"
                    >
                      <option value="Malaysia">মালয়েশিয়া (Malaysia) - Prime Specialty</option>
                      <option value="Middle East">মধ্যপ্রাচ্য (Saudi, UAE, Qatar, Oman)</option>
                      <option value="Europe">ইউরোপ (Romania, Poland, Italy, etc.)</option>
                      <option value="UK & Others">যুক্তরাজ্য ও অন্যান্য (UK / Canada / etc.)</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="inquiry-visa-purpose" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      {lang === 'bn' ? 'উদ্দেশ্য (Purpose)' : 'Purpose'}
                    </label>
                    <select
                      id="inquiry-visa-purpose"
                      value={purpose}
                      onChange={(e) => setPurpose(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 focus:outline-none focus:border-[#166D74] text-sm bg-slate-50 text-slate-900 font-medium"
                    >
                      <option value="Work Visa">কাজের ভিসা / Work Permit</option>
                      <option value="Calling Visa">কলিং ভিসা (মালয়েশিয়া)</option>
                      <option value="Student Visa">পড়াশোনা / Student Visa</option>
                      <option value="Tourist Visa">ভ্রমণ / Tourist Visa & Tour</option>
                      <option value="Air Ticket">এয়ার টিকিট বুকিং / Flights</option>
                    </select>
                  </div>
                </div>

                {/* Message */}
                <div>
                  <label htmlFor="inquiry-message" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    {lang === 'bn' ? 'আপনার জিজ্ঞাসা বা বিবরণ (ঐচ্ছিক)' : 'Details or Questions (Optional)'}
                  </label>
                  <textarea
                    id="inquiry-message"
                    rows={3}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder={
                      lang === 'bn'
                        ? 'আপনার বর্তমান শিক্ষাগত যোগ্যতা, পাসপোর্ট আছে কিনা বা কোনো বিশেষ প্রশ্ন থাকলে লিখুন...'
                        : 'Share your background, passport readiness, or specific question...'
                    }
                    className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 focus:outline-none focus:border-[#166D74] text-sm bg-slate-50 text-slate-900 placeholder-slate-400"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#166D74] hover:bg-[#0E585E] text-white font-black rounded-xl text-sm py-3.5 px-6 shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4 text-white" />
                  <span>{lang === 'bn' ? 'তথ্য জমা দিন (Submit Inquiry)' : 'Submit Inquiry'}</span>
                </button>
              </form>

              {/* Submission Success Box */}
              {submitted && submittedData && (
                <div className="mt-6 p-5 rounded-2xl bg-slate-50 border-2 border-[#166D74] text-slate-900 space-y-3">
                  <div className="flex items-center gap-2 font-black text-[#166D74] text-sm">
                    <CheckCircle2 className="w-5 h-5 text-[#166D74]" />
                    <span>
                      {lang === 'bn'
                        ? 'ধন্যবাদ! আপনার ইনকোয়ারি সফলভাবে গ্রহণ করা হয়েছে।'
                        : 'Thank you! Your inquiry has been received.'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {lang === 'bn'
                      ? `নাম: ${submittedData.name} • দেশ: ${submittedData.country} • উদ্দেশ্য: ${submittedData.purpose}`
                      : `Name: ${submittedData.name} • Destination: ${submittedData.country} • Category: ${submittedData.purpose}`}
                  </p>
                  <div className="pt-1">
                    <button
                      onClick={openWhatsAppWithInquiry}
                      className="w-full bg-[#166D74] hover:bg-[#0E585E] text-white font-black rounded-xl text-sm py-2.5 px-4 shadow flex items-center justify-center gap-2 transition cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4 fill-white" />
                      <span>{lang === 'bn' ? 'হোয়াটসঅ্যাপে এই তথ্য পাঠিয়ে দ্রুত উত্তর নিন' : 'Send this inquiry to WhatsApp for instant reply'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
            </Deletable>

            <Deletable id="contact.privacyNotice" label="গোপনীয়তা তথ্য">
              <p className="text-[11px] text-slate-500 text-center mt-6">
                🔒 {lang === 'bn' ? 'আপনার ব্যক্তিগত তথ্যের গোপনীয়তা রক্ষা করা আমাদের অঙ্গীকার।' : 'Your data is strictly confidential and protected.'}
              </p>
            </Deletable>
          </div>

        </div>

      </div>
    </section>
  );
};
