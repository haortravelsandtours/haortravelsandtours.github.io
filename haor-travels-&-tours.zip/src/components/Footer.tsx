import React from 'react';
import { 
  ShieldCheck, 
  ArrowUp,
  Phone
} from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';

interface FooterProps {
  lang: 'bn' | 'en';
}

export const Footer: React.FC<FooterProps> = ({ lang }) => {
  const { content, updateAgencyInfo, updateFooterNumbers, isEditMode, addFooterLink, deleteFooterLink } = useContent();

  const footerPhone = content.numbers?.footerNumber?.phone || '01712431613';

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-white text-slate-700 pt-16 pb-14 border-t-2 border-slate-200">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-12 gap-12">
        
        {/* Brand identity column (7 cols) */}
        <div className="col-span-7 space-y-4">
          <Deletable id="footer.brand" label="ফুটার ব্র্যান্ড পরিচিতি">
            <div className="flex items-center gap-3">
              <Deletable id="footer.logo" inline label="ফুটার লোগো">
                <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-[#166D74] shrink-0 bg-white shadow-sm">
                  <img
                    src={content.agencyInfo.logoUrl}
                    alt="Haor Travels & Tours Seal"
                    className="w-full h-full object-cover"
                  />
                </div>
              </Deletable>
              <div>
                <h3 className="font-black text-xl text-slate-900 tracking-tight">
                  <EditableText
                    id="footer.agencyName"
                    label="ফুটার এজেন্সি নাম"
                    value={lang === 'bn' ? content.agencyInfo.nameBn : content.agencyInfo.name}
                    onSave={(val) => {
                      if (lang === 'bn') updateAgencyInfo({ nameBn: val });
                      else updateAgencyInfo({ name: val });
                    }}
                  />
                </h3>
                <p className="text-[#166D74] text-xs font-bold">
                  EST. {content.agencyInfo.established} • {lang === 'bn' ? '১৭+ বছরের অভিজ্ঞতা' : '17+ Years of Trust'}
                </p>
              </div>
            </div>
          </Deletable>

          <Deletable id="footer.desc" label="ফুটার বিবরণ">
            <div className="text-slate-600 text-sm leading-relaxed max-w-lg">
              <EditableText
                id="footer.descText"
                label="ফুটার বিবরণ টেক্সট"
                multiline
                value={
                  lang === 'bn'
                    ? 'সুনামগঞ্জের সবচেয়ে বিশ্বস্ত ট্রাভেল ও ভিসা এজেন্সি। কাজ, উচ্চশিক্ষা ও ভ্রমণের জন্য বৈধ ও নির্ভরযোগ্য প্রতিষ্ঠান।'
                    : 'Sunamganj’s benchmark in authentic overseas work, student visas, holiday tours, and lowest airfares since 2008.'
                }
                onSave={() => {}}
              />
            </div>
          </Deletable>

          {/* Footer Dedicated Contact Number (Completely Separate) */}
          <Deletable id="footer.phoneBlock" label="ফুটার হেল্পলাইন ব্লক">
            <div className="flex items-center gap-3 pt-1">
              <Deletable id="footer.phoneIcon" inline label="ফুটার ফোন আইকন">
                <div className="w-8 h-8 rounded-lg bg-slate-100 border border-slate-200 text-[#166D74] flex items-center justify-center shrink-0">
                  <Phone className="w-4 h-4 text-[#166D74]" />
                </div>
              </Deletable>
              <div className="text-xs">
                <span className="font-bold text-slate-900 block">
                  {lang === 'bn' ? 'ফুটার সরাসরি হেল্পলাইন:' : 'Footer Helpline:'}
                </span>
                <span className="font-black text-[#166D74] text-sm">
                  <EditableText
                    id="footer.phoneNumber"
                    label="ফুটার নিজস্ব হেল্পলাইন নম্বর"
                    value={footerPhone}
                    onSave={(val) => updateFooterNumbers({ phone: val })}
                  />
                </span>
              </div>
            </div>
          </Deletable>

          <Deletable id="footer.trustBadge" label="ফুটার বিশ্বস্ততা ব্যাজ">
            <div className="flex items-center gap-2 pt-1 text-xs text-slate-600">
              <Deletable id="footer.shieldIcon" inline label="ফুটার শিল্ড আইকন">
                <ShieldCheck className="w-4 h-4 text-[#166D74]" />
              </Deletable>
              <span>{lang === 'bn' ? 'সরকারি নিয়ম মেনে স্বচ্ছ প্রসেসিং' : 'Govt verified and authentic processing'}</span>
            </div>
          </Deletable>
        </div>

        {/* Quick Links Column (5 cols) */}
        <div className="col-span-5 space-y-3">
          <Deletable id="footer.linksHeader" label="ফুটার লিংক হেডার">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-slate-900 text-sm uppercase tracking-wider">
                {lang === 'bn' ? 'প্রয়োজনীয় লিংক' : 'Quick Navigation'}
              </h4>
              {isEditMode && (
                <button
                  type="button"
                  onClick={() => {
                    const labelBn = window.prompt('নতুন ফুটার লিংকের নাম (বাংলা):', 'জরুরি নোটিশ');
                    if (!labelBn) return;
                    const url = window.prompt('লিংক URL (যেমন: #contact অথবা https://...):', '#contact');
                    if (!url) return;
                    addFooterLink({
                      id: `fl-${Date.now()}`,
                      labelBn,
                      labelEn: labelBn,
                      url,
                      isExternal: url.startsWith('http')
                    });
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#166D74] text-white font-black text-xs hover:bg-[#0E585E] transition cursor-pointer shadow-sm"
                  title="ফুটার লিংক ম্যানুয়ালি যোগ করুন"
                >
                  <span>+ লিংক যোগ</span>
                </button>
              )}
            </div>
          </Deletable>
          <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm text-slate-600">
            {(content.footerLinks || []).map((link) => (
              <Deletable key={link.id} id={`footer.link.${link.id}`} label={`ফুটার লিংক: ${link.labelBn}`}>
                <div className="group/flink flex items-center justify-between py-1">
                  <a 
                    href={link.url}
                    target={link.isExternal ? '_blank' : undefined}
                    rel={link.isExternal ? 'noopener noreferrer' : undefined}
                    className="hover:text-[#166D74] transition block truncate font-medium"
                  >
                    {lang === 'bn' ? link.labelBn : link.labelEn}
                  </a>
                  {isEditMode && (
                    <button
                      type="button"
                      onClick={() => {
                        if (window.confirm(`ফুটার লিংক "${link.labelBn}" ডিলিট করতে চান?`)) {
                          deleteFooterLink(link.id);
                        }
                      }}
                      className="opacity-0 group-hover/flink:opacity-100 p-0.5 text-slate-400 hover:text-red-600 transition cursor-pointer"
                      title="ডিলিট করুন"
                    >
                      ×
                    </button>
                  )}
                </div>
              </Deletable>
            ))}
          </div>
        </div>

      </div>

      {/* Copyright & Scroll to top */}
      <div className="max-w-7xl mx-auto px-6 mt-12 pt-6 border-t border-slate-200 flex flex-row items-center justify-between text-xs text-slate-500">
        <Deletable id="footer.copyright" label="ফুটার কপিরাইট">
          <p>
            &copy; {content.agencyInfo.established} - {new Date().getFullYear()} {content.agencyInfo.name}. All rights reserved. Shologhar Point, Sunamganj.
          </p>
        </Deletable>

        <Deletable id="footer.backToTop" label="উপরে যান বাটন">
          <button
            onClick={scrollToTop}
            className="inline-flex items-center gap-1.5 text-[#166D74] hover:text-[#0E585E] transition cursor-pointer font-bold"
          >
            <span>{lang === 'bn' ? 'উপরে যান' : 'Back to top'}</span>
            <Deletable id="footer.backToTopIcon" inline label="তীর আইকন">
              <ArrowUp className="w-3.5 h-3.5" />
            </Deletable>
          </button>
        </Deletable>
      </div>
    </footer>
  );
};
