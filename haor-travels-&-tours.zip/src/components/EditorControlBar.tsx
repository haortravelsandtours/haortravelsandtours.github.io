import React from 'react';
import { 
  Edit3, 
  Settings, 
  RotateCcw, 
  CheckCircle2, 
  Download, 
  Lock, 
  Unlock, 
  LogOut, 
  ShieldCheck 
} from 'lucide-react';
import { useContent } from '../context/ContentContext';

interface EditorControlBarProps {
  lang: 'bn' | 'en';
}

export const EditorControlBar: React.FC<EditorControlBarProps> = ({ lang }) => {
  const { 
    isEditMode, 
    toggleEditMode, 
    setIsAdminOpen, 
    resetToDefaults, 
    exportContentJson,
    isAdminAuthenticated,
    setIsAuthModalOpen,
    logoutAdmin,
    deletedCount
  } = useContent();

  // If not authenticated, show a clean, protected admin access trigger bar
  if (!isAdminAuthenticated) {
    return (
      <aside
        aria-label="Website Content Editor Toolbar"
        className="sticky top-0 z-50 bg-white/95 backdrop-blur-md text-slate-900 border-b border-slate-200 px-6 py-2 shadow-sm transition"
      >
        <div className="max-w-7xl mx-auto flex flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-[#166D74]" />
            <span className="text-xs font-bold text-slate-700">
              {lang === 'bn' 
                ? 'হাওর ট্রাভেলস অ্যান্ড ট্যুরস • অফিসিয়াল ওয়েবসাইট' 
                : 'Haor Travels & Tours • Official Portal'}
            </span>
          </div>

          <button
            onClick={() => setIsAuthModalOpen(true)}
            className="px-3.5 py-1.5 bg-slate-100 hover:bg-[#166D74] hover:text-white text-[#166D74] border border-slate-300 hover:border-[#166D74] rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 shadow-sm"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? '🔒 এডমিন লগইন (Edit Mode)' : '🔒 Admin Login (Edit Mode)'}</span>
          </button>
        </div>
      </aside>
    );
  }

  // When Admin is Authenticated: Full CMS Controls
  return (
    <aside
      aria-label="Website Content Editor Toolbar"
      className="sticky top-0 z-50 bg-white/95 backdrop-blur-md text-slate-900 border-b-2 border-[#166D74] px-6 py-2.5 shadow-md transition"
    >
      <div className="max-w-7xl mx-auto flex flex-row items-center justify-between gap-4">
        {/* Left: Mode Title & Live Toggle */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-100 border border-[#166D74]/30 px-3 py-1 rounded-xl">
            <span className="w-2.5 h-2.5 rounded-full bg-[#166D74] animate-pulse" />
            <span className="text-xs font-black text-[#166D74] uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#166D74]" />
              <span>{lang === 'bn' ? 'এডমিন সক্রিয়' : 'Admin Active'}</span>
            </span>
          </div>

          {/* Quick Edit Mode Toggle */}
          <button
            onClick={toggleEditMode}
            className={`px-4 py-1.5 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 shadow-sm ${
              isEditMode 
                ? 'bg-[#166D74] text-white ring-2 ring-[#166D74]/40' 
                : 'bg-slate-100 text-slate-700 border border-slate-300 hover:border-[#166D74]'
            }`}
          >
            <Edit3 className={`w-3.5 h-3.5 ${isEditMode ? 'text-white' : 'text-[#166D74]'}`} />
            <span>
              {isEditMode 
                ? (lang === 'bn' ? '✏️ ইনলাইন এডিট মোড: চালু' : '✏️ Inline Edit: ON') 
                : (lang === 'bn' ? '✏️ ইনলাইন এডিট চালু করুন' : '✏️ Turn ON Inline Edit')}
            </span>
          </button>
          
          {isEditMode && (
            <span className="text-[11px] text-[#166D74] font-bold hidden md:inline">
              {lang === 'bn' ? '💡 যেকোনো টেক্সটে ক্লিক করে সরাসরি পরিবর্তন করুন' : '💡 Click any text directly to edit'}
            </span>
          )}
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2.5">
          {/* Status Saved */}
          <div className="flex items-center gap-1.5 text-xs text-slate-600 font-bold px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#166D74]" />
            <span>{lang === 'bn' ? 'স্বয়ংক্রিয়ভাবে সংরক্ষিত' : 'Auto-Saved'}</span>
          </div>

          {/* Full Admin Panel Drawer Button */}
          <button
            onClick={() => setIsAdminOpen(true)}
            className="px-3.5 py-1.5 bg-[#166D74] hover:bg-[#0E585E] text-white text-xs font-black rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            <Settings className="w-3.5 h-3.5 text-white" />
            <span>{lang === 'bn' ? 'সম্পূর্ণ এডিটর প্যানেল' : 'Full Admin Editor'}</span>
          </button>

          {/* Deleted items quick manager badge */}
          {deletedCount > 0 && (
            <button
              onClick={() => setIsAdminOpen(true)}
              className="px-2.5 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 text-xs font-black rounded-xl transition cursor-pointer flex items-center gap-1 shadow-sm"
              title="মুছে ফেলা উপাদান দেখুন ও রিস্টোর করুন"
            >
              <span>🗑️</span>
              <span>{lang === 'bn' ? `মুছে ফেলা: ${deletedCount}` : `Deleted: ${deletedCount}`}</span>
            </button>
          )}

          {/* Export JSON Backup */}
          <button
            onClick={exportContentJson}
            title="Download backup file of your website content"
            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-[#166D74] border border-slate-300 rounded-lg transition cursor-pointer"
          >
            <Download className="w-4 h-4 text-[#166D74]" />
          </button>

          {/* Reset to Default */}
          <button
            onClick={resetToDefaults}
            title="Reset website content to original defaults"
            className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 border border-slate-300 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#166D74]" />
            <span>{lang === 'bn' ? 'রিস্টোর' : 'Reset'}</span>
          </button>

          {/* Logout Button */}
          <button
            onClick={logoutAdmin}
            title="Logout from admin mode"
            className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-red-600 hover:text-red-700 border border-slate-300 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'লক আউট' : 'Logout'}</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
