import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Trash2, Plus } from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';

interface FAQSectionProps {
  lang: 'bn' | 'en';
}

export const FAQSection: React.FC<FAQSectionProps> = ({ lang }) => {
  const { content, updateFaq, deleteFaq, addFaq, isEditMode } = useContent();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section className="py-20 bg-white border-t border-slate-200 text-slate-900">
      <div className="max-w-4xl mx-auto px-6">
        
        {/* Header */}
        <div className="text-center max-w-xl mx-auto mb-12">
          <Deletable id="faqs.badge" label="প্রশ্নোত্তর ব্যাজ">
            <span className="inline-flex items-center gap-1.5 bg-[#166D74] text-white font-black px-4 py-1 rounded-full text-xs uppercase tracking-wider shadow-sm mb-3">
              <Deletable id="faqs.badgeIcon" inline label="প্রশ্ন আইকন">
                <HelpCircle className="w-3.5 h-3.5" />
              </Deletable>
              <span>{lang === 'bn' ? 'সাধারণ প্রশ্নোত্তর' : 'Frequently Asked Questions'}</span>
            </span>
          </Deletable>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">
            <EditableText
              id="faqs.title"
              label="প্রশ্নোত্তর টাইটেল"
              value={lang === 'bn' ? 'জরুরি কিছু প্রশ্নের উত্তর' : 'Frequently Asked Questions'}
              onSave={() => {}}
            />
          </h2>
          <div className="text-slate-600 mt-2 text-sm">
            <EditableText
              id="faqs.subtitle"
              label="প্রশ্নোত্তর সাবটাইটেল"
              value={
                lang === 'bn' 
                  ? 'ভিসা ও ট্রাভেল সংক্রান্ত আপনার প্রয়োজনীয় প্রশ্নের তাত্ক্ষণিক উত্তর।' 
                  : 'Everything you need to know about our visa consultancy and ticketing services.'
              }
              onSave={() => {}}
            />
          </div>

          {isEditMode && (
            <div className="mt-4">
              <button
                onClick={() => {
                  addFaq({
                    qBn: 'নতুন প্রশ্ন এখানে লিখুন?',
                    qEn: 'New question title?',
                    aBn: 'উত্তরের বিস্তারিত বিবরণ এখানে দিন।',
                    aEn: 'Answer description.'
                  });
                }}
                className="px-4 py-2 bg-[#166D74] hover:bg-[#0E585E] text-white font-black text-xs rounded-xl shadow-md inline-flex items-center gap-1.5 transition cursor-pointer"
              >
                <Plus className="w-4 h-4 text-white" />
                <span>+ প্রশ্ন যোগ করুন (Add FAQ)</span>
              </button>
            </div>
          )}
        </div>

        {/* Accordion list */}
        <div className="space-y-4">
          {content.faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <Deletable key={idx} id={`faqs.item.${idx}`} label={`প্রশ্ন ${idx + 1}`}>
                <div
                  className="border-2 border-slate-200 rounded-2xl overflow-hidden transition bg-slate-50 hover:border-[#166D74] relative"
                >
                  {isEditMode && (
                    <button
                      onClick={() => deleteFaq(idx)}
                      title="এই প্রশ্নটি মুছুন (Delete this FAQ)"
                      className="absolute top-4 right-14 z-20 bg-white/90 text-red-600 border border-red-500 hover:bg-red-500 hover:text-white p-1.5 rounded-lg transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}

                  <button
                    onClick={() => toggle(idx)}
                    className="w-full p-5 text-left flex justify-between items-center gap-4 focus:outline-none cursor-pointer"
                    aria-expanded={isOpen}
                  >
                    <span className="font-bold text-slate-900 text-base flex-1">
                      <EditableText
                        id={`faqs.q.${idx}`}
                        label="প্রশ্নের শিরোনাম"
                        value={lang === 'bn' ? faq.qBn : faq.qEn}
                        onSave={(val) => {
                          if (lang === 'bn') updateFaq(idx, { ...faq, qBn: val });
                          else updateFaq(idx, { ...faq, qEn: val });
                        }}
                      />
                    </span>
                    <span className="w-8 h-8 rounded-full bg-white border border-slate-200 text-[#166D74] flex items-center justify-center shrink-0 shadow-sm">
                      {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-5 pt-2 text-slate-700 text-sm leading-relaxed border-t border-slate-200 bg-white">
                      <EditableText
                        id={`faqs.a.${idx}`}
                        label="প্রশ্নের উত্তর"
                        multiline
                        value={lang === 'bn' ? faq.aBn : faq.aEn}
                        onSave={(val) => {
                          if (lang === 'bn') updateFaq(idx, { ...faq, aBn: val });
                          else updateFaq(idx, { ...faq, aEn: val });
                        }}
                      />
                    </div>
                  )}
                </div>
              </Deletable>
            );
          })}
        </div>

      </div>
    </section>
  );
};
