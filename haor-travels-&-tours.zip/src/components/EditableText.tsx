import React, { useState } from 'react';
import { Edit3, Check, X, Trash2 } from 'lucide-react';
import { useContent } from '../context/ContentContext';

interface EditableTextProps {
  id?: string;
  value: string;
  onSave: (newValue: string) => void;
  multiline?: boolean;
  className?: string;
  as?: 'span' | 'p' | 'h1' | 'h2' | 'h3' | 'h4' | 'div';
  deletable?: boolean;
  label?: string;
}

export const EditableText: React.FC<EditableTextProps> = ({
  id,
  value,
  onSave,
  multiline = false,
  className = '',
  as = 'span',
  deletable = false,
  label
}) => {
  const { isEditMode, isAdminAuthenticated, isDeleted, deleteItem } = useContent();
  const [isEditing, setIsEditing] = useState(false);
  const [draft, setDraft] = useState(value);

  // If this text element has an id and was deleted, do not render
  if (id && isDeleted(id)) {
    return null;
  }

  // Keep draft in sync with value
  React.useEffect(() => {
    setDraft(value);
  }, [value]);

  const canEdit = isEditMode && isAdminAuthenticated;

  if (!canEdit) {
    const Tag = as;
    return <Tag className={className}>{value}</Tag>;
  }

  const handleSave = () => {
    onSave(draft);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setDraft(value);
    setIsEditing(false);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (!id) return;
    const promptText = label 
      ? `আপনি কি "${label}" টেক্সটটি মুছতে চান?` 
      : 'আপনি কি এই টেক্সটটি মুছতে চান? (Delete this text?)';
    if (window.confirm(promptText)) {
      deleteItem(id);
      setIsEditing(false);
    }
  };

  if (isEditing) {
    return (
      <div className="inline-block relative z-30 p-2.5 bg-white border-2 border-[#166D74] rounded-xl shadow-2xl text-slate-900 my-1 w-full max-w-xl">
        <div className="text-[11px] font-black text-[#166D74] uppercase tracking-wider mb-1 flex items-center justify-between">
          <span>টেক্সট এডিট করুন (Edit Text)</span>
          <span className="text-[10px] text-slate-500 font-medium">Auto-Save Enabled</span>
        </div>
        {multiline ? (
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            className="w-full bg-slate-50 text-slate-900 p-2.5 rounded-lg border border-slate-300 focus:border-[#166D74] focus:outline-none text-sm resize-y min-h-[90px]"
            rows={3}
          />
        ) : (
          <input
            type="text"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            className="w-full bg-slate-50 text-slate-900 p-2 rounded-lg border border-slate-300 focus:border-[#166D74] focus:outline-none text-sm font-bold"
          />
        )}
        <div className="flex items-center justify-between gap-2 mt-2 pt-2 border-t border-slate-100">
          <div>
            {id && (
              <button
                type="button"
                onClick={handleDelete}
                className="px-2.5 py-1 bg-red-50 hover:bg-red-600 hover:text-white text-red-600 border border-red-200 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1"
                title="এই টেক্সটটি মুছুন (Delete this text)"
              >
                <Trash2 className="w-3 h-3" />
                <span>মুছুন (Delete)</span>
              </button>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCancel}
              className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1"
            >
              <X className="w-3.5 h-3.5" />
              <span>বাতিল</span>
            </button>
            <button
              onClick={handleSave}
              className="px-3 py-1 bg-[#166D74] hover:bg-[#0E585E] text-white text-xs font-black rounded-lg transition cursor-pointer flex items-center gap-1 shadow-sm"
            >
              <Check className="w-3.5 h-3.5 text-white" />
              <span>সংরক্ষণ (Save)</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const Tag = as;

  return (
    <Tag
      onClick={() => setIsEditing(true)}
      title="ক্লিক করে এই টেক্সট এডিট করুন (Click to edit text)"
      className={`${className} cursor-pointer relative group rounded-md outline-dashed outline-1 outline-[#166D74]/40 hover:outline-2 hover:outline-[#166D74] hover:bg-[#166D74]/10 px-1 transition inline-flex items-center flex-wrap`}
    >
      <span>{value}</span>
      <span className="inline-flex items-center gap-0.5 ml-1.5 opacity-60 group-hover:opacity-100 transition">
        <span className="bg-[#166D74] text-white rounded p-0.5 shadow-sm inline-flex items-center justify-center">
          <Edit3 className="w-3 h-3 text-white" />
        </span>
        {id && (
          <button
            type="button"
            onClick={handleDelete}
            title={label ? `মুছুন: ${label} (Delete)` : 'মুছুন (Delete)'}
            className="w-5 h-5 rounded-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center shadow border-2 border-white cursor-pointer hover:scale-125 active:scale-95"
            aria-label="Delete text element"
          >
            <span className="text-xs font-black leading-none pointer-events-none">×</span>
          </button>
        )}
      </span>
    </Tag>
  );
};
