import React, { useState } from 'react';
import { 
  BadgeCheck, 
  Briefcase, 
  GraduationCap, 
  Compass, 
  Plane, 
  ArrowRight, 
  MessageCircle, 
  CheckCircle2, 
  Clock, 
  Sparkles,
  Trash2,
  Plus
} from 'lucide-react';
import { ServiceItem } from '../data/content';
import { useContent } from '../context/ContentContext';
import { ServiceModal } from './ServiceModal';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';

interface ServicesSectionProps {
  lang: 'bn' | 'en';
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ lang }) => {
  const { content, updateService, deleteService, addService, isEditMode } = useContent();
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);

  const whatsappPhone = content.numbers?.floatingWhatsApp?.phone || content.numbers?.headerWhatsApp?.phone || '01914484627';

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'BadgeCheck':
        return BadgeCheck;
      case 'Briefcase':
        return Briefcase;
      case 'GraduationCap':
        return GraduationCap;
      case 'Compass':
        return Compass;
      case 'Plane':
        return Plane;
      default:
        return Sparkles;
    }
  };

  return (
    <section id="services" className="py-20 bg-white text-slate-900 relative border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <Deletable id="services.badge" label="সার্ভিসেস ব্যাজ">
            <span className="inline-block bg-[#166D74] text-white font-black px-4 py-1.5 rounded-full text-xs uppercase tracking-wider shadow-sm mb-3">
              {lang === 'bn' ? 'আমাদের সেবাসমূহ' : 'Our Professional Services'}
            </span>
          </Deletable>
          <h2 className="text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            <EditableText
              id="services.title"
              label="সার্ভিসেস টাইটেল"
              value={lang === 'bn' ? 'সুনামগঞ্জ থেকে বিশ্বব্যাপী' : 'Sunamganj to Across the World'}
              onSave={() => {}}
            />
          </h2>
          <div className="text-slate-600 mt-3 text-base leading-relaxed">
            <EditableText
              id="services.subtitle"
              label="সার্ভিসেস সাবটাইটেল"
              value={
                lang === 'bn'
                  ? 'আপনার বিদেশ যাত্রা সহজ, সাশ্রয়ী ও নিরাপদ করতে আমরা দিচ্ছি ১৭ বছরের অভিজ্ঞতাপুষ্ট নির্ভরযোগ্য সেবা।'
                  : 'End-to-end assistance from initial paperwork assessment to airport departure with proven integrity.'
              }
              onSave={() => {}}
            />
          </div>

          {isEditMode && (
            <div className="mt-4">
              <button
                onClick={() => {
                  const newId = `service-${Date.now()}`;
                  addService({
                    id: newId,
                    titleBn: 'নতুন সেবা (New Service)',
                    titleEn: 'New Visa Service',
                    badgeBn: 'নতুন সেবা',
                    badgeEn: 'New',
                    descriptionBn: 'সেবার সংক্ষিপ্ত বিবরণ এখানে লিখুন।',
                    descriptionEn: 'Service brief description.',
                    iconName: 'Sparkles',
                    timelineBn: '১৫ - ৩০ দিন',
                    timelineEn: '15 - 30 Days',
                    requirementsBn: ['পাসপোর্ট সাইজ ছবি', 'মূল পাসপোর্ট'],
                    requirementsEn: ['Passport photo', 'Valid passport'],
                    keyHighlightsBn: ['১০০% বিশ্বস্ত প্রক্রিয়া'],
                    keyHighlightsEn: ['100% Genuine process']
                  });
                }}
                className="px-4 py-2 bg-[#166D74] hover:bg-[#0E585E] text-white font-black text-xs rounded-xl shadow-lg inline-flex items-center gap-1.5 transition cursor-pointer"
              >
                <Plus className="w-4 h-4 text-white" />
                <span>+ নতুন সেবা যোগ করুন (Add Service)</span>
              </button>
            </div>
          )}
        </div>

        {/* Services Grid - Fixed 3 Columns on all devices */}
        <div className="grid grid-cols-3 gap-8">
          {content.services.map((service) => {
            const Icon = getServiceIcon(service.iconName);
            const isFeatured = service.featured;

            return (
              <Deletable key={service.id} id={`services.card.${service.id}`} label={`সেবা কার্ড: ${service.titleBn}`}>
                <div
                  className={`rounded-3xl p-8 transition duration-300 flex flex-col justify-between group relative bg-slate-50 h-full ${
                    isFeatured
                      ? 'border-2 border-[#166D74] shadow-lg'
                      : 'border border-slate-200 hover:border-[#166D74] shadow-sm'
                  }`}
                >
                  {/* Edit Mode Delete Button */}
                  {isEditMode && (
                    <button
                      onClick={() => deleteService(service.id)}
                      title="এই সেবাটি মুছুন (Remove this service card)"
                      className="absolute -top-3 -right-3 z-20 bg-white text-[#166D74] border-2 border-[#166D74] hover:bg-[#166D74] hover:text-white p-2 rounded-full shadow-2xl transition cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}

                  {/* Popular / Special Badge */}
                  <div className="flex items-center justify-between mb-6">
                    <Deletable id={`services.icon.${service.id}`} inline label={`আইকন: ${service.titleBn}`}>
                      <div className="w-16 h-16 rounded-2xl bg-[#166D74] text-white flex items-center justify-center font-black group-hover:scale-110 transition shadow-md">
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                    </Deletable>
                    <Deletable id={`services.badge.${service.id}`} inline label={`ব্যাজ: ${service.titleBn}`}>
                      <span className="text-xs font-black uppercase tracking-wider bg-white text-[#166D74] border border-[#166D74] px-3.5 py-1.5 rounded-full">
                        <EditableText
                          id={`services.badgeText.${service.id}`}
                          label="সেবা ব্যাজ টেক্সট"
                          value={lang === 'bn' ? service.badgeBn : service.badgeEn}
                          onSave={(val) => {
                            if (lang === 'bn') updateService(service.id, { badgeBn: val });
                            else updateService(service.id, { badgeEn: val });
                          }}
                        />
                      </span>
                    </Deletable>
                  </div>

                  {/* Content */}
                  <div className="space-y-4 mb-6">
                    <h3 className="text-2xl font-black text-slate-900 group-hover:text-[#166D74] transition">
                      <EditableText
                        id={`services.title.${service.id}`}
                        label="সেবা টাইটেল"
                        value={lang === 'bn' ? service.titleBn : service.titleEn}
                        onSave={(val) => {
                          if (lang === 'bn') updateService(service.id, { titleBn: val });
                          else updateService(service.id, { titleEn: val });
                        }}
                      />
                    </h3>
                    <div className="text-slate-600 text-sm leading-relaxed">
                      <EditableText
                        id={`services.desc.${service.id}`}
                        label="সেবা বিবরণ"
                        multiline
                        value={lang === 'bn' ? service.descriptionBn : service.descriptionEn}
                        onSave={(val) => {
                          if (lang === 'bn') updateService(service.id, { descriptionBn: val });
                          else updateService(service.id, { descriptionEn: val });
                        }}
                      />
                    </div>

                    {/* Processing Time Mini Tag */}
                    <Deletable id={`services.timeline.${service.id}`} label={`সময়কাল ট্যাগ: ${service.titleBn}`}>
                      <div className="inline-flex items-center gap-2 text-xs font-black text-[#166D74] bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-sm">
                        <Clock className="w-4 h-4 text-[#166D74]" />
                        <span>
                          {lang === 'bn' ? 'সময়কাল: ' : 'Timeline: '}
                          <EditableText
                            id={`services.timelineText.${service.id}`}
                            label="সময়কাল টেক্সট"
                            value={lang === 'bn' ? service.timelineBn : service.timelineEn}
                            onSave={(val) => {
                              if (lang === 'bn') updateService(service.id, { timelineBn: val });
                              else updateService(service.id, { timelineEn: val });
                            }}
                          />
                        </span>
                      </div>
                    </Deletable>

                    {/* Highlights Checklist */}
                    <div className="pt-2 space-y-2">
                      {(lang === 'bn' ? service.keyHighlightsBn : service.keyHighlightsEn).slice(0, 2).map((hl, i) => (
                        <Deletable key={i} id={`services.hl.${service.id}.${i}`} label={`হাইলাইট: ${hl}`}>
                          <div className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                            <CheckCircle2 className="w-4 h-4 text-[#166D74] shrink-0" />
                            <span className="truncate">{hl}</span>
                          </div>
                        </Deletable>
                      ))}
                    </div>
                  </div>

                  {/* Interactive Action Buttons */}
                  <div className="pt-4 border-t border-slate-200 flex items-center gap-3">
                    <button
                      onClick={() => setSelectedService(service)}
                      className="flex-1 bg-[#166D74] hover:bg-[#0E585E] text-white font-black rounded-xl text-xs py-3 px-3 text-center transition flex items-center justify-center gap-2 shadow cursor-pointer"
                    >
                      <span>{lang === 'bn' ? 'কাগজপত্র ও বিস্তারিত' : 'Requirements'}</span>
                      <ArrowRight className="w-4 h-4 text-white" />
                    </button>

                    <a
                      href={`https://wa.me/88${whatsappPhone}?text=${encodeURIComponent(
                        `Hello Haor Travels, I want to inquire about: ${lang === 'bn' ? service.titleBn : service.titleEn}`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-11 h-11 rounded-xl bg-slate-900 hover:bg-[#166D74] text-white flex items-center justify-center shrink-0 shadow transition"
                      aria-label={`WhatsApp inquiry for ${service.titleEn}`}
                    >
                      <MessageCircle className="w-5 h-5 fill-white text-white" />
                    </a>
                  </div>
                </div>
              </Deletable>
            );
          })}
        </div>

      </div>

      {/* Service Details Modal */}
      <ServiceModal
        service={selectedService}
        onClose={() => setSelectedService(null)}
        lang={lang}
      />
    </section>
  );
};
