import React from 'react';
import { 
  X, 
  CheckCircle2, 
  Clock, 
  FileText, 
  MessageCircle, 
  Phone 
} from 'lucide-react';
import { ServiceItem } from '../data/content';
import { generateWhatsAppUrl } from '../utils/calculator';
import { useContent } from '../context/ContentContext';

interface ServiceModalProps {
  service: ServiceItem | null;
  onClose: () => void;
  lang: 'bn' | 'en';
}

export const ServiceModal: React.FC<ServiceModalProps> = ({ service, onClose, lang }) => {
  const { content } = useContent();
  if (!service) return null;

  const hotlinePhone = content.numbers?.headerHotline?.phone || '01712431613';
  const whatsappPhone = content.numbers?.floatingWhatsApp?.phone || content.numbers?.headerWhatsApp?.phone || '01914484627';

  const handleWhatsApp = () => {
    const url = generateWhatsAppUrl(whatsappPhone, {
      service: lang === 'bn' ? service.titleBn : service.titleEn,
    });
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="bg-white text-slate-900 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border-2 border-[#166D74] relative"
        role="dialog"
        aria-modal="true"
        aria-labelledby="service-modal-title"
      >
        {/* Header banner */}
        <div className="bg-slate-50 border-b border-slate-200 text-slate-900 p-8 rounded-t-3xl relative">
          <button
            onClick={onClose}
            aria-label="Close modal"
            className="absolute top-6 right-6 w-10 h-10 rounded-full bg-slate-200 hover:bg-[#166D74] hover:text-white text-slate-700 flex items-center justify-center transition font-bold"
          >
            <X className="w-5 h-5" />
          </button>

          <span className="inline-block bg-[#166D74] text-white font-black text-xs px-3 py-1 rounded-full uppercase tracking-wider mb-2">
            {lang === 'bn' ? service.badgeBn : service.badgeEn}
          </span>
          <h2 id="service-modal-title" className="text-3xl font-black text-slate-900">
            {lang === 'bn' ? service.titleBn : service.titleEn}
          </h2>
          <p className="text-slate-600 text-sm mt-2">
            {lang === 'bn' ? service.descriptionBn : service.descriptionEn}
          </p>
        </div>

        {/* Content body */}
        <div className="p-8 space-y-6">
          {/* Estimated timeline */}
          <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-50 border border-[#166D74] text-slate-900">
            <Clock className="w-5 h-5 text-[#166D74] shrink-0" />
            <div>
              <p className="text-xs font-black uppercase tracking-wider text-[#166D74]">
                {lang === 'bn' ? 'প্রসেসিং আনুমানিক সময়' : 'Estimated Processing Time'}
              </p>
              <p className="text-base font-black text-slate-900">
                {lang === 'bn' ? service.timelineBn : service.timelineEn}
              </p>
            </div>
          </div>

          {/* Key highlights */}
          <div>
            <h3 className="font-bold text-slate-900 text-base mb-3 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-[#166D74]" />
              <span>{lang === 'bn' ? 'প্রধান সুবিধা ও সেবা' : 'Key Highlights & Inclusions'}</span>
            </h3>
            <div className="space-y-2">
              {(lang === 'bn' ? service.keyHighlightsBn : service.keyHighlightsEn).map((hl, i) => (
                <div key={i} className="flex items-start gap-3 text-sm text-slate-700 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                  <span className="w-2 h-2 rounded-full bg-[#166D74] mt-2 shrink-0" />
                  <span>{hl}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Required documents checklist */}
          <div>
            <h3 className="font-bold text-slate-900 text-base mb-3 flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#166D74]" />
              <span>{lang === 'bn' ? 'প্রয়োজনীয় কাগজপত্রের তালিকা' : 'Required Documents Checklist'}</span>
            </h3>
            <div className="space-y-2.5">
              {(lang === 'bn' ? service.requirementsBn : service.requirementsEn).map((req, i) => (
                <div key={i} className="flex items-start gap-2.5 text-sm text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-[#166D74] shrink-0 mt-0.5" />
                  <span>{req}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-4 border-t border-slate-200 flex flex-row gap-3">
            <button
              onClick={handleWhatsApp}
              className="flex-1 bg-[#166D74] hover:bg-[#0E585E] text-white font-black rounded-xl text-sm py-3.5 px-4 shadow-md flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-white text-white" />
              <span>{lang === 'bn' ? 'হোয়াটসঅ্যাপে বুকিং বা তথ্য নিন' : 'Inquire on WhatsApp'}</span>
            </button>
            <a
              href={`tel:${hotlinePhone}`}
              className="bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 font-black rounded-xl text-sm py-3.5 px-6 shadow-sm flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <Phone className="w-4 h-4 text-slate-700" />
              <span>{lang === 'bn' ? 'হটলাইনে কল' : 'Call Hotline'}</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
