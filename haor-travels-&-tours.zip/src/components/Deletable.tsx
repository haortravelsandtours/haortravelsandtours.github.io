import React from 'react';
import { useContent } from '../context/ContentContext';

interface DeletableProps {
  id: string;
  children: React.ReactNode;
  className?: string;
  inline?: boolean;
  label?: string;
}

export const Deletable: React.FC<DeletableProps> = ({
  id,
  children,
  className = '',
  inline = false,
  label
}) => {
  const { isDeleted, deleteItem, isEditMode, isAdminAuthenticated } = useContent();

  if (isDeleted(id)) {
    return null;
  }

  const canEdit = isEditMode && isAdminAuthenticated;

  if (!canEdit) {
    if (className) {
      const Tag = inline ? 'span' : 'div';
      return <Tag className={className}>{children}</Tag>;
    }
    return <>{children}</>;
  }

  const Tag = inline ? 'span' : 'div';

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    const promptText = label 
      ? `আপনি কি "${label}" ডিলিট করতে চান? (Delete "${label}"?)`
      : 'আপনি কি এই উপাদানটি মুছতে চান? (Delete this element?)';
    if (window.confirm(promptText)) {
      deleteItem(id);
    }
  };

  return (
    <Tag className={`${className} relative group/deletable hover:ring-1 hover:ring-red-400/50 rounded transition ${inline ? 'inline-flex items-center' : ''}`}>
      {children}
      <button
        type="button"
        onClick={handleDelete}
        title={label ? `মুছুন: ${label} (Delete)` : 'মুছুন (Delete)'}
        aria-label="Delete this element"
        className="opacity-0 group-hover/deletable:opacity-100 transition-opacity duration-150 absolute -top-2 -right-2 z-40 w-5 h-5 rounded-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center shadow-lg border-2 border-white cursor-pointer hover:scale-125 active:scale-95"
      >
        <span className="text-xs font-black leading-none pointer-events-none select-none">×</span>
      </button>
    </Tag>
  );
};
