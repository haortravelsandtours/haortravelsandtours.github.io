import React from 'react';
import { 
  Phone,
  MessageCircle, 
  Globe2,
  Plus,
  Trash2,
  ExternalLink
} from 'lucide-react';
import { useContent } from '../context/ContentContext';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';

interface HeaderProps {
  lang: 'bn' | 'en';
  setLang: (lang: 'bn' | 'en') => void;
  onOpenInquiry: () => void;
}

export const Header: React.FC<HeaderProps> = ({ lang, setLang, onOpenInquiry }) => {
  const { 
    content, 
    updateAgencyInfo, 
    updateHeaderHotline,
    updateHeaderWhatsApp,
    isEditMode, 
    deleteNavLink,
    addNavLink 
  } = useContent();

  const handleQuickAddLink = () => {
    const labelBn = window.prompt('নতুন লিংকের নাম (বাংলা):', 'বিশেষ অফার');
    if (!labelBn) return;
    const url = window.prompt('লিংক URL (যেমন: #contact অথবা https://...):', '#contact');
    if (!url) return;
    addNavLink({
      id: `nav-${Date.now()}`,
      labelBn,
      labelEn: labelBn,
      url,
      isExternal: url.startsWith('http')
    });
  };

  const headerPhone = content.numbers?.headerHotline?.phone || content.agencyInfo.phone;
  const headerWhatsAppLink = content.numbers?.headerWhatsApp?.whatsappLink || `https://wa.me/88${content.numbers?.headerWhatsApp?.phone || content.agencyInfo.phone}`;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md text-slate-900 border-b border-slate-200 shadow-sm">
      <div className="w-full max-w-[1400px] mx-auto px-6 py-2 flex flex-row justify-between items-center gap-4 whitespace-nowrap">
        {/* Logo & Brand Identity (Clean, Small, One-Line Beautiful Layout) */}
        <div className="flex items-center gap-2.5 shrink-0">
          <Deletable id="header.logo" label="লোগো">
            <a href="#home" className="relative w-10 h-10 rounded-full overflow-hidden border-2 border-[#166D74] shadow-sm hover:scale-105 transition shrink-0 bg-white block">
              <img 
                src={content.agencyInfo.logoUrl} 
                alt="Haor Travels & Tours Logo" 
                className="w-full h-full object-cover"
              />
            </a>
          </Deletable>
          <div className="flex flex-col justify-center">
            <div className="flex items-center gap-2">
              <span className="font-black text-base text-slate-900 tracking-tight leading-none hover:text-[#166D74] transition whitespace-nowrap">
                <EditableText
                  id="header.agencyName"
                  label="এজেন্সির নাম"
                  value={lang === 'bn' ? content.agencyInfo.nameBn : content.agencyInfo.name}
                  onSave={(val) => {
                    if (lang === 'bn') updateAgencyInfo({ nameBn: val });
                    else updateAgencyInfo({ name: val });
                  }}
                />
              </span>
              <Deletable id="header.estBadge" label="EST ব্যাজ">
                <span className="text-[10px] bg-[#166D74] text-white font-black px-1.5 py-0.5 rounded leading-none uppercase tracking-wider">
                  EST. {content.agencyInfo.established}
                </span>
              </Deletable>
            </div>
            <p className="text-[11px] text-slate-500 font-semibold mt-1 leading-none">
              <EditableText
                id="header.subtitle"
                label="হেডার সাবটাইটেল"
                value={lang === 'bn' ? 'সুনামগঞ্জ, সিলেট • বিশ্বস্ত ভিসা পার্টনার' : 'Sunamganj, Sylhet • Trusted Partner'}
                onSave={(val) => {
                  if (lang === 'bn') updateAgencyInfo({ taglineBn: val });
                  else updateAgencyInfo({ taglineEn: val });
                }}
              />
            </p>
          </div>
        </div>

        {/* Full Navigation Row (Sleek, Small, Single Line) */}
        <nav className="flex items-center gap-1.5 font-bold text-xs text-slate-700 shrink-0">
          {(content.navLinks || []).map((link) => (
            <Deletable key={link.id} id={`header.nav.${link.id}`} label={link.labelBn}>
              <div className="relative group/link flex items-center">
                <a
                  href={link.url}
                  target={link.isExternal ? '_blank' : undefined}
                  rel={link.isExternal ? 'noopener noreferrer' : undefined}
                  className="px-2.5 py-1 rounded-md text-slate-700 hover:text-white hover:bg-[#166D74] transition duration-150 flex items-center gap-1 font-bold whitespace-nowrap"
                >
                  <span>{lang === 'bn' ? link.labelBn : link.labelEn}</span>
                  {link.isExternal && (
                    <Deletable id={`header.navIcon.${link.id}`} inline label="এক্সটার্নাল আইকন">
                      <ExternalLink className="w-2.5 h-2.5 text-[#166D74] group-hover:text-white inline" />
                    </Deletable>
                  )}
                </a>
                {isEditMode && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      if (window.confirm(`লিংক "${link.labelBn}" ডিলিট করতে চান?`)) {
                        deleteNavLink(link.id);
                      }
                    }}
                    className="ml-0.5 opacity-0 group-hover/link:opacity-100 p-0.5 bg-slate-100 hover:bg-[#166D74] hover:text-white text-[#166D74] rounded transition cursor-pointer"
                    title="লিংক ডিলিট করুন (Delete link)"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            </Deletable>
          ))}

          {/* In Edit mode: Quick add link button */}
          {isEditMode && (
            <button
              type="button"
              onClick={handleQuickAddLink}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#166D74] text-white font-black text-[11px] hover:bg-[#0E585E] transition cursor-pointer shadow whitespace-nowrap"
              title="নতুন লিংক ম্যানুয়ালি যোগ করুন"
            >
              <Plus className="w-3 h-3 stroke-[3]" />
              <span>{lang === 'bn' ? '+ লিংক' : '+ Link'}</span>
            </button>
          )}
        </nav>

        {/* Action Buttons, Independent Hotline & Language Switcher */}
        <div className="flex items-center gap-2 shrink-0 whitespace-nowrap">
          {/* Header Hotline (Independently editable & deletable) */}
          <Deletable id="header.hotlineBtn" label="হেডার হটলাইন বাটন">
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-xs font-black text-slate-800 transition">
              <Deletable id="header.hotlineIcon" inline label="হটলাইন ফোন আইকন">
                <Phone className="w-3.5 h-3.5 text-[#166D74]" />
              </Deletable>
              <a href={`tel:${headerPhone}`} className="hover:underline">
                <EditableText
                  id="header.hotlinePhone"
                  label="হেডার হটলাইন নম্বর"
                  value={headerPhone}
                  onSave={(val) => updateHeaderHotline({ phone: val })}
                />
              </a>
            </div>
          </Deletable>

          {/* Language Toggle Button */}
          <Deletable id="header.langBtn" label="ভাষা পরিবর্তনের বাটন">
            <button
              onClick={() => setLang(lang === 'bn' ? 'en' : 'bn')}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 border border-slate-200 text-[11px] font-bold transition cursor-pointer"
              aria-label="Toggle language"
            >
              <Deletable id="header.globeIcon" inline label="গ্লোব আইকন">
                <Globe2 className="w-3 h-3 text-[#166D74]" />
              </Deletable>
              <span>{lang === 'bn' ? 'English' : 'বাংলা'}</span>
            </button>
          </Deletable>

          {/* Header WhatsApp Button */}
          <Deletable id="header.whatsappBtn" label="হেডার WhatsApp বাটন">
            <a
              href={headerWhatsAppLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 bg-[#166D74] hover:bg-[#0E585E] text-white font-black rounded-lg text-xs px-3.5 py-1.5 shadow transition hover:-translate-y-0.5"
            >
              <Deletable id="header.whatsappIcon" inline label="WhatsApp আইকন">
                <MessageCircle className="w-3.5 h-3.5 fill-white text-white" />
              </Deletable>
              <span>WhatsApp</span>
            </a>
          </Deletable>

          {/* Inquiry Button */}
          <Deletable id="header.inquiryBtn" label="ইনকোয়ারি বাটন">
            <button
              onClick={onOpenInquiry}
              className="inline-flex items-center gap-1.5 bg-slate-900 hover:bg-[#166D74] text-white font-black rounded-lg text-xs px-3.5 py-1.5 shadow transition hover:-translate-y-0.5 cursor-pointer"
            >
              {lang === 'bn' ? 'ইনকোয়ারি' : 'Inquiry'}
            </button>
          </Deletable>
        </div>
      </div>
    </header>
  );
};
