import React, { useState } from 'react';
import { 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  FileText, 
  MessageCircle, 
  Compass, 
  Sparkles
} from 'lucide-react';
import { getRequirementsForService, generateWhatsAppUrl } from '../utils/calculator';
import { useContent } from '../context/ContentContext';
import { EditableText } from './EditableText';
import { Deletable } from './Deletable';

interface VisaEligibilityCheckerProps {
  lang: 'bn' | 'en';
}

export const VisaEligibilityChecker: React.FC<VisaEligibilityCheckerProps> = ({ lang }) => {
  const { content } = useContent();
  const [selectedCountry, setSelectedCountry] = useState('Malaysia');
  const [selectedPurpose, setSelectedPurpose] = useState('Work');
  const [passportMonths, setPassportMonths] = useState<number>(14);
  const [hasMedical, setHasMedical] = useState<boolean>(false);

  const whatsappPhone = content.numbers?.floatingWhatsApp?.phone || content.numbers?.headerWhatsApp?.phone || '01914484627';

  const result = getRequirementsForService(selectedCountry, selectedPurpose);
  const hasSufficientPassport = passportMonths >= result.minPassportMonths;

  const handleSendToWhatsApp = () => {
    const url = generateWhatsAppUrl(whatsappPhone, {
      country: selectedCountry,
      service: selectedPurpose,
      message: `Passport validity: ${passportMonths} months. Medical done: ${hasMedical ? 'Yes' : 'Not yet'}. Please guide me on next steps.`,
    });
    window.open(url, '_blank');
  };

  return (
    <section id="checker" className="py-20 bg-slate-50 text-slate-900 relative border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <Deletable id="checker.badge" label="ক্যালকুলেটর ব্যাজ">
            <span className="inline-flex items-center gap-2 bg-[#166D74] text-white font-black px-4 py-1.5 rounded-full text-xs uppercase tracking-wider shadow-sm mb-3">
              <Deletable id="checker.badgeIcon" inline label="টুল আইকন">
                <Sparkles className="w-4 h-4 text-white" />
              </Deletable>
              <span>{lang === 'bn' ? 'ইন্টারেক্টিভ টুল' : 'Interactive Tool'}</span>
            </span>
          </Deletable>
          <h2 className="text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            <EditableText
              id="checker.title"
              label="ক্যালকুলেটর টাইটেল"
              value={lang === 'bn' ? 'ভিসা যোগ্যতা ও ডকুমেন্টস ক্যালকুলেটর' : 'Visa Eligibility & Document Checklist'}
              onSave={() => {}}
            />
          </h2>
          <p className="text-slate-600 mt-3 text-base">
            {lang === 'bn'
              ? 'আপনার কাঙ্ক্ষিত দেশ ও উদ্দেশ্য নির্বাচন করে তাৎক্ষণিক প্রয়োজনীয় কাগজপত্রের তালিকা এবং সময়কাল জেনে নিন।'
              : 'Select your target country and visa category to immediately view required documents and processing timelines.'}
          </p>
        </div>

        {/* Checker Card Container - Fixed 2 Columns side-by-side */}
        <div className="max-w-5xl mx-auto bg-white border-2 border-[#166D74] rounded-3xl p-10 shadow-xl grid grid-cols-2 gap-10">
          
          {/* Controls Column (Left) */}
          <div className="space-y-6">
            <h3 className="font-black text-xl text-slate-900 border-b border-slate-200 pb-4 flex items-center gap-2.5">
              <Compass className="w-5 h-5 text-[#166D74]" />
              <span>{lang === 'bn' ? '১. আপনার তথ্য নির্বাচন করুন' : '1. Select Your Details'}</span>
            </h3>

            {/* Target Country */}
            <div>
              <label htmlFor="select-destination-country" className="block text-xs font-black text-[#166D74] uppercase tracking-wider mb-2">
                {lang === 'bn' ? 'কাঙ্ক্ষিত দেশ (Destination Country)' : 'Destination Country'}
              </label>
              <select
                id="select-destination-country"
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-4 py-3.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#166D74] font-medium"
              >
                <option value="Malaysia">মালয়েশিয়া (Malaysia - Prime Focus)</option>
                <option value="Middle East">মধ্যপ্রাচ্য (Saudi Arabia, UAE, Qatar)</option>
                <option value="Europe">ইউরোপ (Romania, Poland, Schengen)</option>
                <option value="UK & North America">যুক্তরাজ্য ও অন্যান্য (UK / Canada / USA)</option>
              </select>
            </div>

            {/* Purpose */}
            <div>
              <label htmlFor="select-visa-purpose" className="block text-xs font-black text-[#166D74] uppercase tracking-wider mb-2">
                {lang === 'bn' ? 'উদ্দেশ্য (Visa Purpose)' : 'Visa Category'}
              </label>
              <select
                id="select-visa-purpose"
                value={selectedPurpose}
                onChange={(e) => setSelectedPurpose(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-4 py-3.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#166D74] font-medium"
              >
                <option value="Work">কাজ / Work Visa (ওয়ার্ক পারমিট)</option>
                <option value="Calling">কলিং ভিসা / Calling Visa (মালয়েশিয়া)</option>
                <option value="Student">পড়াশোনা / Student Visa (উচ্চশিক্ষা)</option>
                <option value="Tour">ভ্রমণ / Tourist Visa & Packages</option>
              </select>
            </div>

            {/* Passport Months Slider */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label htmlFor="passport-validity-slider" className="text-xs font-black text-[#166D74] uppercase tracking-wider">
                  {lang === 'bn' ? 'পাসপোর্টের অবশিষ্ট মেয়াদ:' : 'Passport Remaining Validity:'}
                </label>
                <span className="text-white bg-[#166D74] font-black text-xs px-2.5 py-1 rounded-md">
                  {passportMonths} {lang === 'bn' ? 'মাস' : 'Months'}
                </span>
              </div>
              <input
                id="passport-validity-slider"
                type="range"
                min="0"
                max="36"
                step="1"
                value={passportMonths}
                onChange={(e) => setPassportMonths(Number(e.target.value))}
                className="w-full accent-[#166D74] h-2 bg-slate-200 rounded-lg cursor-pointer"
                aria-label="Passport Remaining Validity in Months"
              />
              <div className="flex justify-between text-xs text-slate-500 mt-1 font-bold">
                <span>{lang === 'bn' ? '০ মাস' : '0 Mos'}</span>
                <span>{lang === 'bn' ? '৩৬ মাস (৩ বছর)' : '36 Months'}</span>
              </div>
            </div>

            {/* Checkbox for Medical test */}
            <div className="pt-2">
              <label className="flex items-center gap-3 p-4 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer hover:border-[#166D74] transition">
                <input
                  type="checkbox"
                  checked={hasMedical}
                  onChange={(e) => setHasMedical(e.target.checked)}
                  className="w-5 h-5 rounded text-[#166D74] focus:ring-[#166D74] bg-white border-slate-300 accent-[#166D74]"
                />
                <span className="text-xs text-slate-800 font-bold">
                  {lang === 'bn' 
                    ? 'আমার সরকারি অনুমোদিত মেডিকেল টেস্ট সম্পন্ন করা আছে' 
                    : 'I already have a certified medical fitness test'}
                </span>
              </label>
            </div>
          </div>

          {/* Results Column (Right) */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-7 flex flex-col justify-between space-y-6">
            <div>
              <h3 className="font-black text-xl text-slate-900 border-b border-slate-200 pb-4 flex items-center gap-2.5">
                <FileText className="w-5 h-5 text-[#166D74]" />
                <span>{lang === 'bn' ? '২. যাচাই ফলাফল ও তালিকা' : '2. Requirements Checklist'}</span>
              </h3>

              {/* Passport Warning or Success indicator */}
              <div className="mt-4">
                {hasSufficientPassport ? (
                  <div className="p-4 rounded-xl bg-white border border-[#166D74] text-slate-900 text-xs flex items-center gap-3 shadow-sm">
                    <CheckCircle2 className="w-5 h-5 text-[#166D74] shrink-0" />
                    <span className="font-medium">
                      {lang === 'bn'
                        ? `আপনার পাসপোর্টের মেয়াদ (${passportMonths} মাস) এই আবেদনের জন্য উপযুক্ত (নূন্যতম ${result.minPassportMonths} মাস প্রয়োজন)।`
                        : `Your passport validity (${passportMonths} mos) fulfills the minimum ${result.minPassportMonths} months requirement.`}
                    </span>
                  </div>
                ) : (
                  <div className="p-4 rounded-xl bg-[#166D74] text-white text-xs flex items-center gap-3 font-bold shadow-sm">
                    <AlertCircle className="w-5 h-5 text-white shrink-0" />
                    <span>
                      {lang === 'bn'
                        ? `সতর্কতা: এই ভিসার জন্য পাসপোর্টের নূন্যতম মেয়াদ ${result.minPassportMonths} মাস প্রয়োজন। পাসপোর্ট রিনিউ করতে হবে।`
                        : `Attention: Minimum ${result.minPassportMonths} months validity is required for this category. Please renew.`}
                    </span>
                  </div>
                )}
              </div>

              {/* Processing Timeline */}
              <div className="mt-4 flex items-center gap-3 text-xs font-black text-slate-900 bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                <Clock className="w-4 h-4 text-[#166D74]" />
                <span>{lang === 'bn' ? 'আনুমানিক প্রসেসিং সময়:' : 'Estimated Timeline:'}</span>
                <span className="text-[#166D74] font-black">{result.estimatedDays}</span>
              </div>

              {/* Documents List */}
              <div className="mt-5 space-y-2.5">
                <p className="text-xs font-black text-[#166D74] uppercase tracking-wider">
                  {lang === 'bn' ? 'প্রয়োজনীয় প্রধান কাগজপত্র:' : 'Required Key Documents:'}
                </p>
                <div className="space-y-2 pr-1">
                  {result.requiredDocuments.map((doc, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 font-medium">
                      <span className="w-2 h-2 rounded-full bg-[#166D74] mt-1.5 shrink-0" />
                      <span>{doc}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Direct WhatsApp Call-to-action button */}
            <div className="pt-2">
              <button
                onClick={handleSendToWhatsApp}
                className="w-full bg-[#166D74] hover:bg-[#0E585E] text-white font-black rounded-xl text-sm py-4 px-4 shadow-xl transition flex items-center justify-center gap-2 hover:-translate-y-0.5 cursor-pointer"
              >
                <MessageCircle className="w-5 h-5 fill-white text-white" />
                <span>
                  {lang === 'bn'
                    ? 'এই তথ্য দিয়ে সরাসরি WhatsApp-এ বার্তা পাঠান'
                    : 'Send My Details to WhatsApp Now'}
                </span>
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
