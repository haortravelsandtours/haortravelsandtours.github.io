import React, { useState } from 'react';
import { ContentProvider, useContent } from './context/ContentContext';
import { EditorControlBar } from './components/EditorControlBar';
import { AdminDrawer } from './components/AdminDrawer';
import { AdminAuthModal } from './components/AdminAuthModal';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { MalaysiaSpecial } from './components/MalaysiaSpecial';
import { ServicesSection } from './components/ServicesSection';
import { VisaEligibilityChecker } from './components/VisaEligibilityChecker';
import { WhyChooseUs } from './components/WhyChooseUs';
import { TeamSection } from './components/TeamSection';
import { ProcessSteps } from './components/ProcessSteps';
import { GallerySection } from './components/GallerySection';
import { FAQSection } from './components/FAQSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';

function MainApp() {
  const [lang, setLang] = useState<'bn' | 'en'>('bn');
  const { content } = useContent();

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const fontStyle: React.CSSProperties = {
    fontFamily: `'${content.typography?.fontFamilyBn || 'Hind Siliguri'}', '${content.typography?.fontFamilyEn || 'Inter'}', -apple-system, sans-serif`,
    fontSize: content.typography?.sizeScale === 'compact' ? '15px' : content.typography?.sizeScale === 'large' ? '17px' : '16px',
    letterSpacing: content.typography?.letterSpacing === 'wide' ? '0.025em' : 'normal',
  };

  return (
    <div 
      className="min-h-screen bg-white text-slate-900 min-w-[1240px] flex flex-col selection:bg-[#166D74] selection:text-white transition-all"
      style={fontStyle}
    >
      {/* 0. Live Manual Editor Control Bar */}
      <EditorControlBar lang={lang} />

      {/* 1. Header with Navigation */}
      {content.visibility.header && (
        <Header
          lang={lang}
          setLang={setLang}
          onOpenInquiry={() => scrollToSection('contact')}
        />
      )}

      <main className="flex-1">
        {/* 2. Hero Section */}
        {content.visibility.hero && (
          <Hero
            lang={lang}
            onExploreServices={() => scrollToSection('services')}
            onOpenChecker={() => scrollToSection('checker')}
          />
        )}

        {/* 3. Malaysia Work Permit Special Highlight */}
        {content.visibility.malaysia && (
          <MalaysiaSpecial
            lang={lang}
            onOpenChecklist={() => scrollToSection('checker')}
          />
        )}

        {/* 4. Core Services (5 Services: Calling, Work, Student, Tourist, Air Ticket) */}
        {content.visibility.services && <ServicesSection lang={lang} />}

        {/* 5. Interactive Visa Eligibility & Document Calculator */}
        {content.visibility.checker && <VisaEligibilityChecker lang={lang} />}

        {/* 6. Why Choose Us & Narrative */}
        {content.visibility.whyUs && <WhyChooseUs lang={lang} />}

        {/* 7. Leadership Team (Founder & Marketing Manager) */}
        {content.visibility.team && <TeamSection lang={lang} />}

        {/* 8. Process (4 Easy Steps) */}
        {content.visibility.process && <ProcessSteps lang={lang} />}

        {/* 9. Gallery */}
        {content.visibility.gallery && <GallerySection lang={lang} />}

        {/* 10. Frequently Asked Questions */}
        {content.visibility.faqs && <FAQSection lang={lang} />}

        {/* 11. Contact & Inquiry Form */}
        {content.visibility.contact && <ContactSection lang={lang} />}
      </main>

      {/* 12. Footer */}
      {content.visibility.footer && <Footer lang={lang} />}

      {/* 13. Floating Pulsing WhatsApp Button */}
      <FloatingWhatsApp lang={lang} />

      {/* 14. Full Admin Content Drawer */}
      <AdminDrawer lang={lang} />

      {/* 15. Admin Password Auth Modal */}
      <AdminAuthModal lang={lang} />
    </div>
  );
}

export default function App() {
  return (
    <ContentProvider>
      <MainApp />
    </ContentProvider>
  );
}
