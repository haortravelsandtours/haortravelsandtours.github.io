import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validatePhoneNumber,
  formatPhoneNumberForWhatsApp,
  generateWhatsAppUrl,
  getRequirementsForService,
} from './calculator';

test('validatePhoneNumber correctly validates BD and international phone numbers', () => {
  assert.equal(validatePhoneNumber('01914484627'), true);
  assert.equal(validatePhoneNumber('+8801914484627'), true);
  assert.equal(validatePhoneNumber('8801914484627'), true);
  assert.equal(validatePhoneNumber('01711223344'), true);
  assert.equal(validatePhoneNumber('123'), false);
  assert.equal(validatePhoneNumber(''), false);
  assert.equal(validatePhoneNumber('abcd-efgh-ij'), false);
});

test('formatPhoneNumberForWhatsApp correctly prepends 88 to local 01-numbers', () => {
  assert.equal(formatPhoneNumberForWhatsApp('01914484627'), '8801914484627');
  assert.equal(formatPhoneNumberForWhatsApp('+8801914484627'), '8801914484627');
});

test('generateWhatsAppUrl builds valid wa.me URL with encoded parameters', () => {
  const url = generateWhatsAppUrl('01914484627', {
    name: 'Rahim Uddin',
    phone: '01711000000',
    country: 'Malaysia',
    service: 'Calling Visa',
  });
  assert.ok(url.startsWith('https://wa.me/8801914484627?text='));
  assert.ok(url.includes('Rahim'));
  assert.ok(url.includes('Malaysia'));
});

test('getRequirementsForService returns customized requirements for Malaysia Calling & Work visas', () => {
  const res = getRequirementsForService('Malaysia', 'Work Visa');
  assert.equal(res.minPassportMonths, 12);
  assert.ok(res.requiredDocuments.some((d) => d.includes('Passport')));
  assert.ok(res.requiredDocuments.some((d) => d.includes('Medical')));
  assert.ok(res.estimatedDays.includes('30'));
});
