export interface WhatsAppMessageParams {
  name?: string;
  phone?: string;
  service?: string;
  country?: string;
  message?: string;
}

/**
 * Validates Bangladeshi phone numbers and general phone numbers
 */
export function validatePhoneNumber(phone: string): boolean {
  const cleaned = phone.replace(/[\s\-\(\)\+]/g, '');
  if (!cleaned) return false;
  // BD numbers often start with 01, 8801, +8801 and are 11 digits (excluding 88)
  if (cleaned.startsWith('8801')) {
    return cleaned.length === 13 && /^\d+$/.test(cleaned);
  }
  if (cleaned.startsWith('01')) {
    return cleaned.length === 11 && /^\d+$/.test(cleaned);
  }
  // Generic validation: 8-15 digits
  return cleaned.length >= 8 && cleaned.length <= 15 && /^\d+$/.test(cleaned);
}

/**
 * Normalizes phone number for calling or wa.me links
 */
export function formatPhoneNumberForWhatsApp(phone: string): string {
  let cleaned = phone.replace(/[^\d]/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '88' + cleaned;
  } else if (!cleaned.startsWith('88') && cleaned.length === 10) {
    cleaned = '880' + cleaned;
  }
  return cleaned;
}

/**
 * Generates an encoded WhatsApp URL with structured message
 */
export function generateWhatsAppUrl(recipientPhone: string, params: WhatsAppMessageParams): string {
  const targetNumber = formatPhoneNumberForWhatsApp(recipientPhone);
  
  const lines: string[] = ['*Assalamu Alaikum / Hello Haor Travels & Tours,*'];
  lines.push('I would like to inquire about your travel & visa services:');
  
  if (params.name) {
    lines.push(`• *Name:* ${params.name.trim()}`);
  }
  if (params.phone) {
    lines.push(`• *Contact No:* ${params.phone.trim()}`);
  }
  if (params.country) {
    lines.push(`• *Interested Country:* ${params.country}`);
  }
  if (params.service) {
    lines.push(`• *Service Needed:* ${params.service}`);
  }
  if (params.message) {
    lines.push(`• *Details:* ${params.message.trim()}`);
  }

  lines.push('\nPlease let me know the eligibility, documentation, and cost details. Thank you!');
  
  const fullText = lines.join('\n');
  return `https://wa.me/${targetNumber}?text=${encodeURIComponent(fullText)}`;
}

export interface EligibilityResult {
  eligible: boolean;
  minPassportMonths: number;
  requiredDocuments: string[];
  estimatedDays: string;
  notes: string;
}

/**
 * Evaluates basic visa requirements based on selected country and purpose
 */
export function getRequirementsForService(country: string, purpose: string): EligibilityResult {
  const normCountry = country.toLowerCase();
  const normPurpose = purpose.toLowerCase();

  if (normCountry.includes('malaysia')) {
    if (normPurpose.includes('work') || normPurpose.includes('calling')) {
      return {
        eligible: true,
        minPassportMonths: 12,
        requiredDocuments: [
          'Original Machine Readable / e-Passport (valid at least 12 months)',
          'Recent passport size photos (white/blue background)',
          'Medical Clearance Certificate (FOMEMA compliant)',
          'Police Clearance Certificate',
          'National ID Card (NID) copy',
          'Academic / Technical certificates (if applicable)'
        ],
        estimatedDays: '30 - 60 days',
        notes: 'Malaysia calling visa approval depends on employer quota and immigration department approval. Haor Travels provides end-to-end guidance.'
      };
    }
    if (normPurpose.includes('student') || normPurpose.includes('study')) {
      return {
        eligible: true,
        minPassportMonths: 18,
        requiredDocuments: [
          'Valid Passport (minimum 18 months)',
          'Offer letter from Malaysian University / College',
          'EMGS Visa Approval Letter (VAL)',
          'All academic certificates & transcripts (attested)',
          'Passport size photos with blue background',
          'Financial solvency bank statement'
        ],
        estimatedDays: '45 - 60 days',
        notes: 'EMGS processing requires attested academic transcripts and university offer letter.'
      };
    }
    return {
      eligible: true,
      minPassportMonths: 6,
      requiredDocuments: [
        'Valid Passport (minimum 6 months)',
        'Return air ticket booking',
        'Hotel booking confirmation',
        'Bank statement (last 6 months with min balance)',
        'Passport photos'
      ],
      estimatedDays: '5 - 10 working days',
      notes: 'eNTRI / eVisa processing available for Bangladeshi tourists.'
    };
  }

  if (normCountry.includes('middle east') || normCountry.includes('saudi') || normCountry.includes('dubai')) {
    return {
      eligible: true,
      minPassportMonths: 6,
      requiredDocuments: [
        'Valid Passport (at least 6-12 months)',
        'Medical fitness certificate (GAMCA)',
        'Police Clearance Certificate',
        'Biometric enrollment',
        'NID copy'
      ],
      estimatedDays: '15 - 30 working days',
      notes: 'Direct embassy submission and verified agency processing.'
    };
  }

  // Default / Other countries
  return {
    eligible: true,
    minPassportMonths: 6,
    requiredDocuments: [
      'Original Passport with minimum 6 months validity',
      'Passport size photographs',
      'Bank statement & solvency certificate (last 6 months)',
      'Proof of employment / business or student ID',
      'Travel itinerary / invitation or job letter'
    ],
    estimatedDays: '15 - 45 days',
    notes: 'Personalized consultation provided for European, Asian, and American destinations.'
  };
}
