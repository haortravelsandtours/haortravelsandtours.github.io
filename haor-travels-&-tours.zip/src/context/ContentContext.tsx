import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  AGENCY_INFO, 
  SERVICES, 
  TEAM_MEMBERS, 
  PROCESS_STEPS, 
  WHY_CHOOSE_US, 
  FAQS, 
  STATS,
  SiteNumbers,
  DEFAULT_SITE_NUMBERS,
  ServiceItem,
  TeamMember
} from '../data/content';

export interface GalleryItem {
  id: number | string;
  type: string;
  titleBn: string;
  titleEn: string;
  image: string;
  tagBn: string;
  tagEn: string;
}

export interface HeroContent {
  badgeBn: string;
  badgeEn: string;
  titleLine1Bn: string;
  titleLine1En: string;
  titleLine2Bn: string;
  titleLine2En: string;
  subtitleBn: string;
  subtitleEn: string;
  statusBadgeBn: string;
  statusBadgeEn: string;
  taglineBn: string;
  taglineEn: string;
}

export interface MalaysiaContent {
  badgeBn: string;
  badgeEn: string;
  titleBn: string;
  titleEn: string;
  quoteBn: string;
  quoteEn: string;
  descBn: string;
  descEn: string;
  sectors: Array<{
    titleBn: string;
    titleEn: string;
    descBn: string;
    descEn: string;
  }>;
  guaranteesBn: string[];
  guaranteesEn: string[];
}

export interface WhyUsContent {
  badgeBn: string;
  badgeEn: string;
  titleBn: string;
  titleEn: string;
  quoteBn: string;
  quoteEn: string;
  descBn: string;
  descEn: string;
  pillars: Array<{
    titleBn: string;
    titleEn: string;
    descBn: string;
    descEn: string;
  }>;
}

export interface SectionVisibility {
  header: boolean;
  hero: boolean;
  malaysia: boolean;
  services: boolean;
  checker: boolean;
  whyUs: boolean;
  team: boolean;
  process: boolean;
  gallery: boolean;
  faqs: boolean;
  contact: boolean;
  footer: boolean;
}

export interface TypographySettings {
  fontFamilyBn: string;
  fontFamilyEn: string;
  sizeScale: 'compact' | 'standard' | 'large';
  letterSpacing: 'normal' | 'wide';
}

export interface NavLinkItem {
  id: string;
  labelBn: string;
  labelEn: string;
  url: string;
  isExternal?: boolean;
}

export interface FooterLinkItem {
  id: string;
  labelBn: string;
  labelEn: string;
  url: string;
  isExternal?: boolean;
}

export interface UploadedFileItem {
  id: string;
  name: string;
  size: string;
  type: string;
  dataUrl: string;
  createdAt: string;
}

export interface SiteContent {
  agencyInfo: typeof AGENCY_INFO;
  numbers: SiteNumbers;
  deletedItems: Record<string, boolean>;
  hero: HeroContent;
  malaysia: MalaysiaContent;
  services: ServiceItem[];
  team: TeamMember[];
  whyUs: WhyUsContent;
  processSteps: typeof PROCESS_STEPS;
  gallery: GalleryItem[];
  faqs: typeof FAQS;
  stats: typeof STATS;
  visibility: SectionVisibility;
  typography: TypographySettings;
  navLinks: NavLinkItem[];
  footerLinks: FooterLinkItem[];
  uploadedFiles: UploadedFileItem[];
}

const DEFAULT_GALLERY: GalleryItem[] = [
  {
    id: 2,
    type: 'office',
    titleBn: 'সুনামগঞ্জ প্রধান কার্যালয় ডেস্ক',
    titleEn: 'Executive Consultation Desk',
    image: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=800&q=80',
    tagBn: 'পরামর্শ কেন্দ্র',
    tagEn: 'Consultancy'
  },
  {
    id: 3,
    type: 'travel',
    titleBn: 'মালয়েশিয়া গন্তব্য ও কুয়ালালামপুর ফ্লাইট',
    titleEn: 'Malaysia Destination & Kuala Lumpur Flights',
    image: 'https://images.unsplash.com/photo-1596422846543-75c6fc197f07?auto=format&fit=crop&w=800&q=80',
    tagBn: 'মালয়েশিয়া',
    tagEn: 'Malaysia'
  },
  {
    id: 4,
    type: 'travel',
    titleBn: 'আন্তর্জাতিক পাসপোর্ট ও ভিসা প্রক্রিয়া',
    titleEn: 'International Passport & Visa Endorsements',
    image: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80',
    tagBn: 'ভিসা ও টিকিট',
    tagEn: 'Visa & Tickets'
  },
  {
    id: 5,
    type: 'office',
    titleBn: 'ক্লায়েন্ট মিটিং ও ডকুমেন্ট ভেরিফিকেশন',
    titleEn: 'Client Documentation & Transparency',
    image: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=800&q=80',
    tagBn: 'স্বচ্ছতা',
    tagEn: 'Documentation'
  },
  {
    id: 6,
    type: 'travel',
    titleBn: 'বিমানবন্দর যাত্রা ও শুভকামনা',
    titleEn: 'Airport Departure & New Horizons',
    image: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=800&q=80',
    tagBn: 'শুভযাত্রা',
    tagEn: 'Safe Flights'
  },
  {
    id: 7,
    type: 'travel',
    titleBn: 'কুয়ালালামপুর টুইন টাওয়ার্স ও মালয়েশিয়া আগমন',
    titleEn: 'Kuala Lumpur Landmarks & Arrival',
    image: 'https://images.unsplash.com/photo-1508062878650-88b52897f298?auto=format&fit=crop&w=800&q=80',
    tagBn: 'গন্তব্য',
    tagEn: 'Arrival'
  }
];

const DEFAULT_CONTENT: SiteContent = {
  agencyInfo: { ...AGENCY_INFO },
  numbers: { ...DEFAULT_SITE_NUMBERS },
  deletedItems: {},
  hero: {
    badgeBn: '১৭+ বছরের বিশ্বস্ত সেবা • EST. 2008',
    badgeEn: '17+ Years of Trusted Heritage • EST. 2008',
    titleLine1Bn: 'বিদেশ যান —',
    titleLine1En: 'Travel Abroad —',
    titleLine2Bn: 'কাজ, পড়াশোনা ও ভ্রমণের জন্য',
    titleLine2En: 'Work, Study & Global Tourism',
    subtitleBn: 'সুনামগঞ্জের সবচেয়ে নির্ভরযোগ্য ট্রাভেল ও ভিসা এজেন্সি। সঠিক, স্বচ্ছ ও বিশ্বস্ত প্রক্রিয়ায় মালয়েশিয়া সহ বিশ্বের বিভিন্ন দেশে ভিসা প্রসেসিং এবং নিশ্চিত এয়ার টিকিট বুকিং।',
    subtitleEn: 'Sunamganj’s premier visa & travel agency. Transparent, verified work permit processing for Malaysia and destinations worldwide, alongside lowest airfares.',
    statusBadgeBn: 'সার্ভিস সক্রিয় ও আবেদন চলছে',
    statusBadgeEn: 'Applications Open Now',
    taglineBn: 'সুনামগঞ্জ • সিলেট • সমগ্র বাংলাদেশ',
    taglineEn: 'Sunamganj • Sylhet • Bangladesh'
  },
  malaysia: {
    badgeBn: 'আমাদের বিশেষত্ব ও মূল গর্ব',
    badgeEn: 'Core Specialty & Pride',
    titleBn: 'মালয়েশিয়া ওয়ার্ক পারমিট ও কলিং ভিসা স্পেশালিস্ট',
    titleEn: 'Malaysia Work Permit & Calling Visa Specialists',
    quoteBn: '“আমাদের সবচেয়ে প্রিয় এবং সেরা কাজ হলো মালয়েশিয়া। এরপর আমরা অন্যান্য দেশের কাজও করে থাকি।”',
    quoteEn: '“Our foremost specialty and greatest pride is Malaysia. Alongside Malaysia, we also provide trusted services for destinations worldwide.”',
    descBn: '২০০৮ সাল থেকে দীর্ঘ ১৭ বছরের বাস্তব অভিজ্ঞতা ও সততার কারণে সুনামগঞ্জ সহ সারাদেশে মালয়েশিয়া গমনেচ্ছু কর্মীদের প্রথম পছন্দ হাওর ট্রাভেলস অ্যান্ড ট্যুরস। প্রতিটি ধাপে আমরা স্বচ্ছতা ও বৈধতা বজায় রাখি।',
    descEn: 'With 17 years of on-ground experience since 2008, Haor Travels & Tours is the definitive first choice for overseas workers seeking official calling visas and direct factory employment.',
    sectors: [
      {
        titleBn: 'ম্যানুফ্যাকচারিং ও ফ্যাক্টরি',
        titleEn: 'Manufacturing & Industrial',
        descBn: 'ইলেকট্রনিক্স, গার্মেন্টস ও প্যাকেজিং কারখানা',
        descEn: 'Electronics, textile & production facilities'
      },
      {
        titleBn: 'কন্সট্রাকশন ও নির্মাণ',
        titleEn: 'Construction & Civil',
        descBn: 'বিল্ডিং কনস্ট্রাকশন, মেটাল ও সিভিল ওয়ার্ক',
        descEn: 'Commercial building, welding & civil infrastructure'
      },
      {
        titleBn: 'প্ল্যান্টেশন ও এগ্রিকালচার',
        titleEn: 'Plantation & Agriculture',
        descBn: 'পাম অয়েল বাগান ও কৃষি খামার',
        descEn: 'Palm oil harvest & commercial agro projects'
      },
      {
        titleBn: 'সার্ভিস ও হোটেল রেস্তোরাঁ',
        titleEn: 'Service & Hospitality',
        descBn: 'হোটেল, রেস্তোরাঁ ও সুপারশপ কর্মী',
        descEn: 'Hotel service, culinary & modern retail staff'
      }
    ],
    guaranteesBn: [
      'সরকারি অনুমোদিত মেডিকেল গাইড',
      'বায়োমেট্রিক ও পুলিশ ক্লিয়ারেন্স সহায়তা',
      'বিএমইটি (BMET) স্মার্টকার্ড নিশ্চায়ন',
      'কুয়ালালামপুর ফ্লাইটের সুলভ টিকেট'
    ],
    guaranteesEn: [
      'Government authorized medical checkup',
      'Full biometric & police clearance guidance',
      'Guaranteed BMET smart card clearance',
      'Direct Kuala Lumpur discounted air tickets'
    ]
  },
  services: [...SERVICES],
  team: [...TEAM_MEMBERS],
  whyUs: {
    badgeBn: 'কেন আমাদের ওপর ভরসা রাখবেন',
    badgeEn: 'Why Choose Us',
    titleBn: 'সুনামগঞ্জের আস্থা পেরিয়ে সমগ্র বাংলাদেশের বিশ্বস্ত ঠিকানা',
    titleEn: 'Sunamganj’s Pride, Bangladesh’s Trusted Travel Partner',
    quoteBn: '“আমরা মানুষকে কাজ, পড়াশোনা এবং ভ্রমণের জন্য বিদেশে পাঠিয়ে থাকি। প্রথমে আমরা আমাদের এলাকার মানুষের সাথে কাজ করেছি, এখন আমরা পুরো বাংলাদেশের জন্য কাজ শুরু করছি।”',
    quoteEn: '“We send people abroad for work, higher education, and global travel. We started by serving our local community with utmost care, and now we proudly extend our genuine services across all of Bangladesh.”',
    descBn: '২০০৮ সালে সুনামগঞ্জ জেলার ষোলঘর পয়েন্টে প্রতিষ্ঠিত হাওর ট্রাভেলস অ্যান্ড ট্যুরস আজ দীর্ঘ ১৭ বছর ধরে সৎ, বৈধ ও স্বচ্ছ ভিসা প্রসেসিংয়ের অনন্য দৃষ্টান্ত স্থাপন করেছে।',
    descEn: 'Established in 2008 at Shologhar Point, Sunamganj, Haor Travels & Tours stands as an unwavering symbol of integrity, genuine visas, and personal client care for over 17 years.',
    pillars: [...WHY_CHOOSE_US]
  },
  processSteps: [...PROCESS_STEPS],
  gallery: [...DEFAULT_GALLERY],
  faqs: [...FAQS],
  stats: [...STATS],
  visibility: {
    header: true,
    hero: true,
    malaysia: true,
    services: true,
    checker: true,
    whyUs: true,
    team: true,
    process: true,
    gallery: true,
    faqs: true,
    contact: true,
    footer: true,
  },
  typography: {
    fontFamilyBn: 'Hind Siliguri',
    fontFamilyEn: 'Inter',
    sizeScale: 'standard',
    letterSpacing: 'normal',
  },
  navLinks: [
    { id: 'nav-home', labelBn: 'হোম', labelEn: 'Home', url: '#home' },
    { id: 'nav-malaysia', labelBn: 'মালয়েশিয়া ওয়ার্ক', labelEn: 'Malaysia Work', url: '#malaysia' },
    { id: 'nav-services', labelBn: 'সেবাসমূহ', labelEn: 'Services', url: '#services' },
    { id: 'nav-checker', labelBn: 'যোগ্যতা যাচাই', labelEn: 'Eligibility', url: '#checker' },
    { id: 'nav-whyus', labelBn: 'কেন আমরা', labelEn: 'Why Us', url: '#why-us' },
    { id: 'nav-team', labelBn: 'টিম', labelEn: 'Leadership', url: '#team' },
    { id: 'nav-gallery', labelBn: 'গ্যালারি', labelEn: 'Gallery', url: '#gallery' },
    { id: 'nav-contact', labelBn: 'যোগাযোগ', labelEn: 'Contact', url: '#contact' },
  ],
  footerLinks: [
    { id: 'fl-1', labelBn: 'হোম পেজ', labelEn: 'Home', url: '#home' },
    { id: 'fl-2', labelBn: 'মালয়েশিয়া ওয়ার্ক ও কলিং', labelEn: 'Malaysia Work & Calling', url: '#malaysia' },
    { id: 'fl-3', labelBn: 'আমাদের ৫টি সেবা', labelEn: 'All 5 Services', url: '#services' },
    { id: 'fl-4', labelBn: 'যোগ্যতা ও পেপারস যাচাই', labelEn: 'Eligibility Calculator', url: '#checker' },
    { id: 'fl-5', labelBn: 'পরিচালনা পর্ষদ ও টিম', labelEn: 'Leadership Team', url: '#team' },
    { id: 'fl-6', labelBn: 'সরাসরি যোগাযোগ', labelEn: 'Contact Office', url: '#contact' },
  ],
  uploadedFiles: [
    {
      id: 'file-logo-1',
      name: 'haor_travels_official_logo.jpeg',
      size: '148 KB',
      type: 'image/jpeg',
      dataUrl: '/assets/aistudio/WhatsApp_Image_2026-11-06_at_19.51.01_318f3588.jpeg',
      createdAt: '2026-11-06'
    }
  ]
};

const STORAGE_KEY = 'HAOR_TRAVELS_SITE_DATA_V3';

export const ADMIN_PASSWORD = '1916736701';

interface ContentContextType {
  content: SiteContent;
  isEditMode: boolean;
  toggleEditMode: () => void;
  isAdminOpen: boolean;
  setIsAdminOpen: (open: boolean) => void;
  isAdminAuthenticated: boolean;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  loginAdmin: (password: string) => boolean;
  logoutAdmin: () => void;
  updateAgencyInfo: (data: Partial<typeof AGENCY_INFO>) => void;
  updateHeaderHotline: (data: Partial<SiteNumbers['headerHotline']>) => void;
  updateHeaderWhatsApp: (data: Partial<SiteNumbers['headerWhatsApp']>) => void;
  updateFloatingWhatsApp: (data: Partial<SiteNumbers['floatingWhatsApp']>) => void;
  updateContactPageNumbers: (data: Partial<SiteNumbers['contactPage']>) => void;
  updateFooterNumbers: (data: Partial<SiteNumbers['footerNumber']>) => void;
  isDeleted: (id: string) => boolean;
  deleteItem: (id: string) => void;
  restoreItem: (id: string) => void;
  restoreAllItems: () => void;
  deletedCount: number;
  deletedKeys: string[];
  updateHero: (data: Partial<HeroContent>) => void;
  updateMalaysia: (data: Partial<MalaysiaContent>) => void;
  updateService: (id: string, data: Partial<ServiceItem>) => void;
  addService: (service: ServiceItem) => void;
  deleteService: (id: string) => void;
  updateTeamMember: (id: string, data: Partial<TeamMember>) => void;
  addTeamMember: (member: TeamMember) => void;
  deleteTeamMember: (id: string) => void;
  moveTeamMember: (fromIndex: number, toIndex: number) => void;
  updateWhyUs: (data: Partial<WhyUsContent>) => void;
  updateFaq: (index: number, faq: typeof FAQS[0]) => void;
  addFaq: (faq: typeof FAQS[0]) => void;
  deleteFaq: (index: number) => void;
  updateGalleryItem: (index: number, item: GalleryItem) => void;
  addGalleryItem: (item: GalleryItem) => void;
  deleteGalleryItem: (index: number) => void;
  toggleSectionVisibility: (sectionKey: keyof SectionVisibility) => void;
  updateTypography: (settings: Partial<TypographySettings>) => void;
  addNavLink: (link: NavLinkItem) => void;
  updateNavLink: (id: string, data: Partial<NavLinkItem>) => void;
  deleteNavLink: (id: string) => void;
  moveNavLink: (fromIndex: number, toIndex: number) => void;
  addFooterLink: (link: FooterLinkItem) => void;
  updateFooterLink: (id: string, data: Partial<FooterLinkItem>) => void;
  deleteFooterLink: (id: string) => void;
  uploadFile: (file: UploadedFileItem) => void;
  deleteFile: (id: string) => void;
  resetToDefaults: () => void;
  exportContentJson: () => void;
  importContentJson: (jsonStr: string) => boolean;
}

const ContentContext = createContext<ContentContextType | undefined>(undefined);

export const ContentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [content, setContent] = useState<SiteContent>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...DEFAULT_CONTENT,
          ...parsed,
          agencyInfo: { ...DEFAULT_CONTENT.agencyInfo, ...(parsed.agencyInfo || {}) },
          numbers: {
            ...DEFAULT_SITE_NUMBERS,
            ...(parsed.numbers || {}),
            headerHotline: { ...DEFAULT_SITE_NUMBERS.headerHotline, ...(parsed.numbers?.headerHotline || {}) },
            headerWhatsApp: { ...DEFAULT_SITE_NUMBERS.headerWhatsApp, ...(parsed.numbers?.headerWhatsApp || {}) },
            floatingWhatsApp: { ...DEFAULT_SITE_NUMBERS.floatingWhatsApp, ...(parsed.numbers?.floatingWhatsApp || {}) },
            contactPage: { ...DEFAULT_SITE_NUMBERS.contactPage, ...(parsed.numbers?.contactPage || {}) },
            footerNumber: { ...DEFAULT_SITE_NUMBERS.footerNumber, ...(parsed.numbers?.footerNumber || {}) },
          },
          deletedItems: parsed.deletedItems && typeof parsed.deletedItems === 'object' ? parsed.deletedItems : {},
          hero: { ...DEFAULT_CONTENT.hero, ...(parsed.hero || {}) },
          malaysia: { ...DEFAULT_CONTENT.malaysia, ...(parsed.malaysia || {}) },
          whyUs: { ...DEFAULT_CONTENT.whyUs, ...(parsed.whyUs || {}) },
          visibility: { ...DEFAULT_CONTENT.visibility, ...(parsed.visibility || {}) },
          typography: { ...DEFAULT_CONTENT.typography, ...(parsed.typography || {}) },
          navLinks: Array.isArray(parsed.navLinks) && parsed.navLinks.length > 0 ? parsed.navLinks : DEFAULT_CONTENT.navLinks,
          footerLinks: Array.isArray(parsed.footerLinks) && parsed.footerLinks.length > 0 ? parsed.footerLinks : DEFAULT_CONTENT.footerLinks,
          uploadedFiles: Array.isArray(parsed.uploadedFiles) ? parsed.uploadedFiles : DEFAULT_CONTENT.uploadedFiles,
        };
      }
    } catch (e) {
      console.error('Failed to load saved content from localStorage:', e);
    }
    return DEFAULT_CONTENT;
  });

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('HAOR_ADMIN_AUTH_TOKEN_V1') === 'true';
    } catch {
      return false;
    }
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [isAdminOpen, _setIsAdminOpen] = useState<boolean>(false);

  // Sync state to localStorage whenever content changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(content));
    } catch (e) {
      console.error('Failed to save content to localStorage:', e);
    }
  }, [content]);

  // Keep edit mode strictly disabled if not authenticated
  useEffect(() => {
    if (!isAdminAuthenticated && isEditMode) {
      setIsEditMode(false);
    }
  }, [isAdminAuthenticated, isEditMode]);

  const loginAdmin = (password: string): boolean => {
    if (password.trim() === ADMIN_PASSWORD) {
      try {
        sessionStorage.setItem('HAOR_ADMIN_AUTH_TOKEN_V1', 'true');
      } catch {
        // ignore
      }
      setIsAdminAuthenticated(true);
      setIsAuthModalOpen(false);
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    try {
      sessionStorage.removeItem('HAOR_ADMIN_AUTH_TOKEN_V1');
    } catch {
      // ignore
    }
    setIsAdminAuthenticated(false);
    setIsEditMode(false);
    _setIsAdminOpen(false);
  };

  const toggleEditMode = () => {
    if (!isAdminAuthenticated) {
      setIsAuthModalOpen(true);
      return;
    }
    setIsEditMode((prev) => !prev);
  };

  const setIsAdminOpen = (open: boolean) => {
    if (open && !isAdminAuthenticated) {
      setIsAuthModalOpen(true);
      return;
    }
    _setIsAdminOpen(open);
  };

  const updateAgencyInfo = (data: Partial<typeof AGENCY_INFO>) => {
    setContent((prev) => ({
      ...prev,
      agencyInfo: { ...prev.agencyInfo, ...data }
    }));
  };

  const updateHeaderHotline = (data: Partial<SiteNumbers['headerHotline']>) => {
    setContent((prev) => ({
      ...prev,
      numbers: {
        ...prev.numbers,
        headerHotline: { ...prev.numbers.headerHotline, ...data }
      }
    }));
  };

  const updateHeaderWhatsApp = (data: Partial<SiteNumbers['headerWhatsApp']>) => {
    setContent((prev) => ({
      ...prev,
      numbers: {
        ...prev.numbers,
        headerWhatsApp: { ...prev.numbers.headerWhatsApp, ...data }
      }
    }));
  };

  const updateFloatingWhatsApp = (data: Partial<SiteNumbers['floatingWhatsApp']>) => {
    setContent((prev) => {
      const updated = { ...prev.numbers.floatingWhatsApp, ...data };
      if (data.phone && !data.whatsappLink) {
        updated.whatsappLink = `https://wa.me/88${data.phone.replace(/[^0-9]/g, '')}`;
      }
      return {
        ...prev,
        numbers: {
          ...prev.numbers,
          floatingWhatsApp: updated
        }
      };
    });
  };

  const updateContactPageNumbers = (data: Partial<SiteNumbers['contactPage']>) => {
    setContent((prev) => {
      const updated = { ...prev.numbers.contactPage, ...data };
      if (data.whatsappPhone && !data.whatsappLink) {
        updated.whatsappLink = `https://wa.me/88${data.whatsappPhone.replace(/[^0-9]/g, '')}`;
      }
      return {
        ...prev,
        numbers: {
          ...prev.numbers,
          contactPage: updated
        }
      };
    });
  };

  const updateFooterNumbers = (data: Partial<SiteNumbers['footerNumber']>) => {
    setContent((prev) => ({
      ...prev,
      numbers: {
        ...prev.numbers,
        footerNumber: { ...prev.numbers.footerNumber, ...data }
      }
    }));
  };

  const isDeleted = (id: string): boolean => {
    return Boolean(content.deletedItems && content.deletedItems[id]);
  };

  const deleteItem = (id: string) => {
    setContent((prev) => ({
      ...prev,
      deletedItems: {
        ...(prev.deletedItems || {}),
        [id]: true
      }
    }));
  };

  const restoreItem = (id: string) => {
    setContent((prev) => {
      const next = { ...(prev.deletedItems || {}) };
      delete next[id];
      return {
        ...prev,
        deletedItems: next
      };
    });
  };

  const restoreAllItems = () => {
    setContent((prev) => ({
      ...prev,
      deletedItems: {}
    }));
  };

  const deletedKeys = Object.keys(content.deletedItems || {}).filter(
    (k) => content.deletedItems[k] === true
  );
  const deletedCount = deletedKeys.length;

  const updateHero = (data: Partial<HeroContent>) => {
    setContent((prev) => ({
      ...prev,
      hero: { ...prev.hero, ...data }
    }));
  };

  const updateMalaysia = (data: Partial<MalaysiaContent>) => {
    setContent((prev) => ({
      ...prev,
      malaysia: { ...prev.malaysia, ...data }
    }));
  };

  const updateService = (id: string, data: Partial<ServiceItem>) => {
    setContent((prev) => ({
      ...prev,
      services: prev.services.map((s) => (s.id === id ? { ...s, ...data } : s))
    }));
  };

  const addService = (service: ServiceItem) => {
    setContent((prev) => ({
      ...prev,
      services: [...prev.services, service]
    }));
  };

  const deleteService = (id: string) => {
    setContent((prev) => ({
      ...prev,
      services: prev.services.filter((s) => s.id !== id)
    }));
  };

  const updateTeamMember = (id: string, data: Partial<TeamMember>) => {
    setContent((prev) => ({
      ...prev,
      team: prev.team.map((m) => (m.id === id ? { ...m, ...data } : m))
    }));
  };

  const addTeamMember = (member: TeamMember) => {
    setContent((prev) => ({
      ...prev,
      team: [...prev.team, member]
    }));
  };

  const deleteTeamMember = (id: string) => {
    setContent((prev) => ({
      ...prev,
      team: prev.team.filter((m) => m.id !== id)
    }));
  };

  const moveTeamMember = (fromIndex: number, toIndex: number) => {
    setContent((prev) => {
      if (toIndex < 0 || toIndex >= prev.team.length) return prev;
      const newTeam = [...prev.team];
      const [moved] = newTeam.splice(fromIndex, 1);
      newTeam.splice(toIndex, 0, moved);
      return { ...prev, team: newTeam };
    });
  };

  const updateWhyUs = (data: Partial<WhyUsContent>) => {
    setContent((prev) => ({
      ...prev,
      whyUs: { ...prev.whyUs, ...data }
    }));
  };

  const updateFaq = (index: number, faq: typeof FAQS[0]) => {
    setContent((prev) => {
      const newFaqs = [...prev.faqs];
      newFaqs[index] = faq;
      return { ...prev, faqs: newFaqs };
    });
  };

  const addFaq = (faq: typeof FAQS[0]) => {
    setContent((prev) => ({
      ...prev,
      faqs: [...prev.faqs, faq]
    }));
  };

  const deleteFaq = (index: number) => {
    setContent((prev) => ({
      ...prev,
      faqs: prev.faqs.filter((_, idx) => idx !== index)
    }));
  };

  const updateGalleryItem = (index: number, item: GalleryItem) => {
    setContent((prev) => {
      const newGallery = [...prev.gallery];
      newGallery[index] = item;
      return { ...prev, gallery: newGallery };
    });
  };

  const addGalleryItem = (item: GalleryItem) => {
    setContent((prev) => ({
      ...prev,
      gallery: [...prev.gallery, item]
    }));
  };

  const deleteGalleryItem = (index: number) => {
    setContent((prev) => ({
      ...prev,
      gallery: prev.gallery.filter((_, idx) => idx !== index)
    }));
  };

  const updateTypography = (settings: Partial<TypographySettings>) => {
    setContent((prev) => ({
      ...prev,
      typography: { ...prev.typography, ...settings }
    }));
  };

  const addNavLink = (link: NavLinkItem) => {
    setContent((prev) => ({
      ...prev,
      navLinks: [...prev.navLinks, link]
    }));
  };

  const updateNavLink = (id: string, data: Partial<NavLinkItem>) => {
    setContent((prev) => ({
      ...prev,
      navLinks: prev.navLinks.map((l) => (l.id === id ? { ...l, ...data } : l))
    }));
  };

  const deleteNavLink = (id: string) => {
    setContent((prev) => ({
      ...prev,
      navLinks: prev.navLinks.filter((l) => l.id !== id)
    }));
  };

  const moveNavLink = (fromIndex: number, toIndex: number) => {
    setContent((prev) => {
      if (toIndex < 0 || toIndex >= prev.navLinks.length) return prev;
      const list = [...prev.navLinks];
      const [moved] = list.splice(fromIndex, 1);
      list.splice(toIndex, 0, moved);
      return { ...prev, navLinks: list };
    });
  };

  const addFooterLink = (link: FooterLinkItem) => {
    setContent((prev) => ({
      ...prev,
      footerLinks: [...prev.footerLinks, link]
    }));
  };

  const updateFooterLink = (id: string, data: Partial<FooterLinkItem>) => {
    setContent((prev) => ({
      ...prev,
      footerLinks: prev.footerLinks.map((l) => (l.id === id ? { ...l, ...data } : l))
    }));
  };

  const deleteFooterLink = (id: string) => {
    setContent((prev) => ({
      ...prev,
      footerLinks: prev.footerLinks.filter((l) => l.id !== id)
    }));
  };

  const uploadFile = (file: UploadedFileItem) => {
    setContent((prev) => ({
      ...prev,
      uploadedFiles: [file, ...prev.uploadedFiles]
    }));
  };

  const deleteFile = (id: string) => {
    setContent((prev) => ({
      ...prev,
      uploadedFiles: prev.uploadedFiles.filter((f) => f.id !== id)
    }));
  };

  const toggleSectionVisibility = (sectionKey: keyof SectionVisibility) => {
    setContent((prev) => ({
      ...prev,
      visibility: {
        ...prev.visibility,
        [sectionKey]: !prev.visibility[sectionKey]
      }
    }));
  };

  const resetToDefaults = () => {
    if (window.confirm('আপনি কি সব পরিবর্তন মুছে আসল ওয়েবসাইটের মূল তথ্য পুনরুদ্ধার করতে চান? / Reset all content to original defaults?')) {
      localStorage.removeItem(STORAGE_KEY);
      setContent(DEFAULT_CONTENT);
    }
  };

  const exportContentJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(content, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `haor_travels_content_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const importContentJson = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed && typeof parsed === 'object') {
        setContent({
          ...DEFAULT_CONTENT,
          ...parsed
        });
        return true;
      }
    } catch (e) {
      console.error('Failed to import JSON content:', e);
    }
    return false;
  };

  return (
    <ContentContext.Provider
      value={{
        content,
        isEditMode,
        toggleEditMode,
        isAdminOpen,
        setIsAdminOpen,
        isAdminAuthenticated,
        isAuthModalOpen,
        setIsAuthModalOpen,
        loginAdmin,
        logoutAdmin,
        updateAgencyInfo,
        updateHeaderHotline,
        updateHeaderWhatsApp,
        updateFloatingWhatsApp,
        updateContactPageNumbers,
        updateFooterNumbers,
        isDeleted,
        deleteItem,
        restoreItem,
        restoreAllItems,
        deletedCount,
        deletedKeys,
        updateHero,
        updateMalaysia,
        updateService,
        addService,
        deleteService,
        updateTeamMember,
        addTeamMember,
        deleteTeamMember,
        moveTeamMember,
        updateWhyUs,
        updateFaq,
        addFaq,
        deleteFaq,
        updateGalleryItem,
        addGalleryItem,
        deleteGalleryItem,
        toggleSectionVisibility,
        updateTypography,
        addNavLink,
        updateNavLink,
        deleteNavLink,
        moveNavLink,
        addFooterLink,
        updateFooterLink,
        deleteFooterLink,
        uploadFile,
        deleteFile,
        resetToDefaults,
        exportContentJson,
        importContentJson
      }}
    >
      {children}
    </ContentContext.Provider>
  );
};

export const useContent = () => {
  const context = useContext(ContentContext);
  if (!context) {
    throw new Error('useContent must be used within a ContentProvider');
  }
  return context;
};
