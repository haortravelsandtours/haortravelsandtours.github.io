export interface ServiceItem {
  id: string;
  titleBn: string;
  titleEn: string;
  badgeBn: string;
  badgeEn: string;
  descriptionBn: string;
  descriptionEn: string;
  iconName: string;
  popular?: boolean;
  featured?: boolean;
  timelineBn: string;
  timelineEn: string;
  requirementsBn: string[];
  requirementsEn: string[];
  keyHighlightsBn: string[];
  keyHighlightsEn: string[];
}

export interface TeamMember {
  id: string;
  nameBn: string;
  nameEn: string;
  roleBn: string;
  roleEn: string;
  titleBn: string;
  titleEn: string;
  image: string;
  bioBn: string;
  bioEn: string;
  phone: string;
  whatsapp: string;
  experienceBn: string;
  experienceEn: string;
}

export interface SiteNumbers {
  headerHotline: {
    phone: string;
    labelBn: string;
    labelEn: string;
  };
  headerWhatsApp: {
    phone: string;
    whatsappLink: string;
  };
  floatingWhatsApp: {
    phone: string;
    whatsappLink: string;
    labelBn: string;
    labelEn: string;
  };
  contactPage: {
    phone: string;
    whatsappPhone: string;
    whatsappLink: string;
  };
  footerNumber: {
    phone: string;
    labelBn: string;
    labelEn: string;
  };
}

export const DEFAULT_SITE_NUMBERS: SiteNumbers = {
  headerHotline: {
    phone: '01914484627',
    labelBn: 'হটলাইন',
    labelEn: 'Hotline'
  },
  headerWhatsApp: {
    phone: '01914484627',
    whatsappLink: 'https://wa.me/8801914484627'
  },
  floatingWhatsApp: {
    phone: '01914484627',
    whatsappLink: 'https://wa.me/8801914484627',
    labelBn: 'সরাসরি WhatsApp-এ কথা বলুন',
    labelEn: 'Chat with us on WhatsApp'
  },
  contactPage: {
    phone: '01914484627',
    whatsappPhone: '01914484627',
    whatsappLink: 'https://wa.me/8801914484627'
  },
  footerNumber: {
    phone: '01712431613',
    labelBn: 'ফুটার জরুরি সহায়তা নম্বর',
    labelEn: 'Footer Emergency Help'
  }
};

export const AGENCY_INFO = {
  name: 'Haor Travels & Tours',
  nameBn: 'হাওর ট্রাভেলস অ্যান্ড ট্যুরস',
  taglineBn: 'EST. 2008 • আপনার বিশ্বস্ত ট্রাভেল ও ভিসা পার্টনার',
  taglineEn: 'EST. 2008 • Your Trusted Travel & Visa Partner',
  established: 2008,
  yearsOfExperience: 17,
  phone: '01914484627',
  phoneFormatted: '+88 01914-484627',
  whatsappNumber: '01914484627',
  whatsappLink: 'https://wa.me/8801914484627',
  email: 'haortravelsandtours@gmail.com',
  address: 'Shologhar Point, Sunamganj, Sylhet - 3000, Bangladesh',
  addressBn: 'ষোলঘর পয়েন্ট, সুনামগঞ্জ, সিলেট - ৩০০০, বাংলাদেশ',
  openingHoursBn: 'শনিবার - বৃহস্পতিবার: সকাল ৯টা থেকে রাত ৯টা (শুক্রবার সীমিত)',
  openingHoursEn: 'Saturday - Thursday: 9:00 AM - 9:00 PM (Friday Limited)',
  logoUrl: '/assets/aistudio/WhatsApp_Image_2026-11-06_at_19.51.01_318f3588.jpeg',
  founderImage: '/assets/aistudio/WhatsApp_Image_2026-10-26_at_19.11.05_3acd39cb.jpg',
  marketingImage: '/assets/aistudio/WhatsApp_Image_2026-10-31_at_16.44.03_d25f2afd.jpeg',
};

export const SERVICES: ServiceItem[] = [
  {
    id: 'calling-visa',
    titleBn: 'Calling Visa (কলিং ভিসা)',
    titleEn: 'Calling Visa Processing',
    badgeBn: 'মালয়েশিয়া স্পেশাল',
    badgeEn: 'Malaysia Signature',
    descriptionBn: 'নির্ভুল ও নিরাপদ উপায়ে মালয়েশিয়ার কলিং ভিসা প্রসেসিং ও সরকারি বায়োমেট্রিক সেবা প্রদান করা হয়।',
    descriptionEn: 'Official and secure Malaysia calling visa processing with biometric endorsement and verified quota.',
    iconName: 'BadgeCheck',
    featured: true,
    popular: true,
    timelineBn: '৩০ - ৬০ দিন',
    timelineEn: '30 - 60 Days',
    requirementsBn: [
      'মূল মেশিন রিডেবল বা ই-পাসপোর্ট (নূন্যতম ১ বছর মেয়াদ)',
      'পাসপোর্ট সাইজ ছবি (সাদা ও নীল ব্যাকগ্রাউন্ড)',
      'মেডিকেল ফিটনেস সার্টিফিকেট (অনুমোদিত মেডিকেল সেন্টার)',
      'পুলিশ ক্লিয়ারেন্স সার্টিফিকেট (Police Clearance)',
      'জাতীয় পরিচয়পত্র (NID) কপি'
    ],
    requirementsEn: [
      'Original Machine Readable / e-Passport (min 1 year validity)',
      'Passport size photos with white and blue backgrounds',
      'Medical clearance certificate (FOMEMA/approved panel)',
      'Police Clearance Certificate',
      'National ID Card (NID) copy'
    ],
    keyHighlightsBn: [
      'সরাসরি অফিসিয়াল নিয়োগকারী কোম্পানির মাধ্যমে যাচাইকৃত কোটা',
      'বায়োমেট্রিক ও মেডিকেল টেস্টের সম্পূর্ণ গাইডলাইন',
      'বিএমইটি (BMET) ইমিগ্রেশন ছাড়পত্র নিশ্চায়ন'
    ],
    keyHighlightsEn: [
      'Verified quota with genuine approved employers',
      'Step-by-step biometric and medical guidance',
      'Full BMET clearance and smart card support'
    ]
  },
  {
    id: 'work-visa',
    titleBn: 'Work Visa (ওয়ার্ক পারমিট)',
    titleEn: 'Work Visa / Employment Permit',
    badgeBn: 'সর্বাধিক জনপ্রিয়',
    badgeEn: 'Most Demanded',
    descriptionBn: 'মালয়েশিয়া সহ মধ্যপ্রাচ্য ও ইউরোপের বিভিন্ন দেশের কাজের ওয়ার্ক ভিসার সবচেয়ে বিশ্বস্ত মাধ্যম।',
    descriptionEn: 'Trusted legal work permits and employment visa processing for Malaysia, Gulf nations, and select European destinations.',
    iconName: 'Briefcase',
    featured: true,
    popular: true,
    timelineBn: '৪৫ - ৯০ দিন',
    timelineEn: '45 - 90 Days',
    requirementsBn: [
      'বৈধ পাসপোর্ট (নূন্যতম ১২ মাস মেয়াদ)',
      'কাজের অভিজ্ঞতা বা কারিগরি সনদপত্র (প্রযোজ্য ক্ষেত্রে)',
      'মেডিকেল ক্লিয়ারেন্স সার্টিফিকেট',
      'পুলিশ ভেরিফিকেশন রিপোর্ট',
      'ছবি এবং ভোটার আইডি কার্ড'
    ],
    requirementsEn: [
      'Valid Passport (at least 12 months validity)',
      'Skill/work certificates if applicable',
      'Government authorized medical checkup',
      'Police Clearance Certificate',
      'NID and passport photos'
    ],
    keyHighlightsBn: [
      'ফ্যাক্টরি, কন্সট্রাকশন, প্ল্যান্টেশন ও সার্ভিস সেক্টর',
      'চাকরির চুক্তিপত্র (Job Offer & Agreement) স্বচ্ছভাবে বুঝিয়ে দেওয়া',
      'কোনো লুকানো বা অতিরিক্ত অযাচিত চার্জ নেই'
    ],
    keyHighlightsEn: [
      'Factory, Construction, Plantation & Service sectors',
      'Transparent contract agreement explanation',
      'Clear transparent fees with zero hidden clauses'
    ]
  },
  {
    id: 'student-visa',
    titleBn: 'Student Visa / Study Abroad (উচ্চশিক্ষা)',
    titleEn: 'Student Visa / Study Abroad',
    badgeBn: 'ক্যারিয়ার প্ল্যান',
    badgeEn: 'Higher Education',
    descriptionBn: 'মালয়েশিয়া, যুক্তরাজ্য ও ইউরোপের শীর্ষস্থানীয় বিশ্ববিদ্যালয়ে ভর্তির আবেদন, অফার লেটার ও ভিসা প্রসেসিং।',
    descriptionEn: 'Complete admission guidance, university offer letters, EMGS approval, and student visa processing for top universities.',
    iconName: 'GraduationCap',
    timelineBn: '৪৫ - ৬০ দিন',
    timelineEn: '45 - 60 Days',
    requirementsBn: [
      'পাসপোর্ট (নূন্যতম ১৮ মাস মেয়াদ)',
      'সকল শিক্ষাগত যোগ্যতার সনদ ও মার্কশিট (বোর্ড সত্যায়িত)',
      'বিশ্ববিদ্যালয় অফার লেটার / এডমিশন লেটার',
      'আর্থিক সচ্ছলতা ও ব্যাংক স্টেটমেন্ট',
      'আইইএলটিএস (IELTS) বা সমমান স্কোর (প্রযোজ্য ক্ষেত্রে)'
    ],
    requirementsEn: [
      'Passport (minimum 18 months validity)',
      'Academic certificates & transcripts (attested)',
      'University Offer Letter / Acceptance',
      'Bank solvency statement & sponsor documents',
      'Language proficiency (IELTS/MOI) if required'
    ],
    keyHighlightsBn: [
      'মালয়েশিয়া পাবলিক ও প্রাইভেট বিশ্ববিদ্যালয় অপশন',
      'স্পাউস বা ডিপেন্ডেন্ট ভিসা সহায়তা',
      'স্কলারশিপ ও টিউশন ফি ডিসকাউন্ট পরামর্শ'
    ],
    keyHighlightsEn: [
      'Malaysian public and private universities guidance',
      'VAL / EMGS tracking and embassy support',
      'Scholarship & partial fee rebate assistance'
    ]
  },
  {
    id: 'tourist-visa',
    titleBn: 'Tourist Visa & Tour Packages (ভ্রমণ)',
    titleEn: 'Tourist Visa & Tour Packages',
    badgeBn: 'সহজ প্রসেসিং',
    badgeEn: 'Hassle-Free',
    descriptionBn: 'বিশ্বের যেকোনো দেশে পর্যটন, ফ্যামিলি ভিজিট ও বিজনেস ট্রিপের জন্য দ্রুত ট্যুরিস্ট ভিসা ও প্যাকেজ।',
    descriptionEn: 'Fast tourist visa applications, family visit visas, hotel reservations, and custom holiday tour packages worldwide.',
    iconName: 'Compass',
    timelineBn: '৫ - ১৫ দিন',
    timelineEn: '5 - 15 Days',
    requirementsBn: [
      'মূল পাসপোর্ট (নূন্যতম ৬ মাস মেয়াদ)',
      'বিগত ৬ মাসের ব্যাংক স্টেটমেন্ট ও সলভেন্সি',
      'পাসপোর্ট সাইজ ছবি (সাদা ব্যাকগ্রাউন্ড)',
      'ট্রেড লাইসেন্স বা অফিস নো-অবজেকশন সার্টিফিকেট (NOC)',
      'রিটার্ন ফ্লাইট বুকিং ও হোটেল রিজার্ভেশন'
    ],
    requirementsEn: [
      'Passport with min 6 months validity',
      '6 months bank statement & solvency certificate',
      'Recent studio photographs (white background)',
      'NOC letter / Trade License copy',
      'Confirmed flight itinerary and hotel voucher'
    ],
    keyHighlightsBn: [
      'মালয়েশিয়া, থাইল্যান্ড, সিঙ্গাপুর, দুবাই, ভারত ও ইউরোপ',
      'গ্রুপ ট্যুর ও কাস্টমাইজড ফ্যামিলি প্যাকেজ',
      'হোটেল ও এয়ারপোর্ট পিক-ড্রপ সুবিধা'
    ],
    keyHighlightsEn: [
      'Malaysia, Thailand, Singapore, Dubai, India & Schengen',
      'Group tours and customized family itineraries',
      'Airport transfers and hotel bookings'
    ]
  },
  {
    id: 'air-ticket',
    titleBn: 'Air Ticket Booking (এয়ার টিকিট)',
    titleEn: 'Air Ticket Booking (Domestic & Global)',
    badgeBn: 'সুলভ মূল্য',
    badgeEn: 'Best Fares',
    descriptionBn: 'বিমান বাংলাদেশ, ইউএস-বাংলা সহ বিশ্বের যেকোনো এয়ারলাইন্সের নিশ্চিত টিকিট সবচেয়ে সুলভ মূল্যে বুক করুন।',
    descriptionEn: 'Instant seat reservations, lowest fare guarantees, date changes, and luggage support for domestic and international flights.',
    iconName: 'Plane',
    timelineBn: 'তাৎক্ষণিক (Instant)',
    timelineEn: 'Instant Confirmation',
    requirementsBn: [
      'যাত্রীর পাসপোর্টের পরিষ্কার ছবি বা স্ক্যান কপি',
      'যাত্রার তারিখ ও পছন্দের রুট (ঢাকা/সিলেট থেকে গন্তব্য)',
      'প্রয়োজনীয় ট্রানজিট বা এন্ট্রি ভিসা কপি'
    ],
    requirementsEn: [
      'Clear passport bio-page scan of passenger',
      'Travel dates and route preferences',
      'Transit or final destination valid visa copy'
    ],
    keyHighlightsBn: [
      'সিলেট (ZYL) ও ঢাকা (DAC) থেকে সরাসরি ও ট্রানজিট ফ্লাইট',
      'বিশেষ প্রবাসী টিকিট ডিসকাউন্ট ও অতিরিক্ত ব্যাগেজ সুবিধা',
      'তারিখ পরিবর্তন ও রিফান্ডে সার্বক্ষণিক সহায়তা'
    ],
    keyHighlightsEn: [
      'Direct & transit flights from Sylhet and Dhaka airports',
      'Special expatriate baggage allowances & rates',
      '24/7 rescheduling and refund assistance'
    ]
  }
];

export const TEAM_MEMBERS: TeamMember[] = [
  {
    id: 'founder',
    nameBn: 'প্রতিষ্ঠাতা ও পরিচালক',
    nameEn: 'Founder & Managing Director',
    roleBn: 'প্রধান নির্বাহী ও প্রতিষ্ঠাতা',
    roleEn: 'Founder & Managing Director',
    titleBn: 'Haor Travels & Tours',
    titleEn: 'Haor Travels & Tours',
    image: AGENCY_INFO.founderImage,
    experienceBn: '১৭+ বছর',
    experienceEn: '17+ Years',
    bioBn: 'তিনি এই প্রতিষ্ঠানের প্রতিষ্ঠাতা এবং ২০০৮ সাল থেকে নিরবচ্ছিন্ন সততা ও নিষ্ঠার সাথে সুনামগঞ্জ থেকে যাত্রা শুরু করে আজ সারাদেশে হাজারো মানুষের বিদেশ যাত্রার স্বপ্ন বাস্তবে রূপ দিয়েছেন। বিশেষ করে মালয়েশিয়া ও আন্তর্জাতিক ভিসা প্রসেসিংয়ে তিনি সুনাম ও গ্রাহক আস্থার প্রতীক।',
    bioEn: 'Founder and visionary behind Haor Travels & Tours since 2008. Dedicated to transparent, ethical, and authentic visa consultancy. Over the past 17+ years, he has successfully guided thousands of clients into overseas careers, higher education, and international tours.',
    phone: '01914484627',
    whatsapp: 'https://wa.me/8801914484627?text=Assalamu%20Alaikum%20Founder%20Sir%2C%20I%20need%20visa%20consultancy'
  },
  {
    id: 'marketing-manager',
    nameBn: 'মার্কেটিং ম্যানেজার',
    nameEn: 'Marketing Manager',
    roleBn: 'মার্কেটিং ও ক্লায়েন্ট রিলেশনস',
    roleEn: 'Marketing & Client Relations',
    titleBn: 'Haor Travels & Tours',
    titleEn: 'Haor Travels & Tours',
    image: AGENCY_INFO.marketingImage,
    experienceBn: '৮+ বছর',
    experienceEn: '8+ Years',
    bioBn: 'ক্লায়েন্টদের সার্বক্ষণিক সেবা, অনলাইন যোগাযোগ, বিশ্বস্ত তথ্য প্রদান এবং দেশের প্রতিটি জেলা থেকে আসা আগ্রহীদের নিখুঁত পরামর্শ প্রদানে তিনি নিরলসভাবে কাজ করছেন।',
    bioEn: 'Leads communications, customer inquiries, and strategic outreach. Dedicated to responsive client support, timely application updates, and expanding trusted travel services across all 64 districts of Bangladesh.',
    phone: '01914484627',
    whatsapp: 'https://wa.me/8801914484627?text=Hello%20Marketing%20Manager%2C%20I%20have%20an%20inquiry%20regarding%20Haor%20Travels'
  }
];

export const PROCESS_STEPS = [
  {
    step: 1,
    titleBn: 'WhatsApp বা Call করুন',
    titleEn: 'Call or WhatsApp Us',
    descBn: 'আমাদের হটলাইন ০১৯১৪৪৮৪৬২৭ নাম্বারে সরাসরি কথা বলুন অথবা WhatsApp-এ মেসেজ পাঠান।',
    descEn: 'Contact our official hotline 01914484627 or message directly on WhatsApp.',
    icon: 'PhoneCall'
  },
  {
    step: 2,
    titleBn: 'পাসপোর্ট ও কাগজপত্র জমা দিন',
    titleEn: 'Submit Passport & Docs',
    descBn: 'সুনামগঞ্জ অফিসে সরাসরি আসুন অথবা দেশের যেকোনো প্রান্ত থেকে অনলাইনে স্ক্যান কপি জমা দিন।',
    descEn: 'Visit our Sunamganj office or send clear scanned documents from anywhere in Bangladesh.',
    icon: 'FileText'
  },
  {
    step: 3,
    titleBn: 'সঠিক ভিসা প্রসেসিং ও ভেরিফিকেশন',
    titleEn: 'Visa Processing & Verification',
    descBn: 'আমরা সরকারি নিয়ম মেনে নির্ভুলভাবে আপনার ভিসা আবেদন, বায়োমেট্রিক ও অনুমোদন নিশ্চিত করি।',
    descEn: 'Our experienced team processes embassy submissions, BMET clearance, and visa approvals.',
    icon: 'ShieldCheck'
  },
  {
    step: 4,
    titleBn: 'ফ্লাইট টিকেট ও শুভযাত্রা',
    titleEn: 'Ticket Booking & Departure',
    descBn: 'ভিসা পাওয়ার পর সুলভ মূল্যে এয়ার টিকিট নিশ্চিত করে নিরাপদে বিদেশের উদ্দেশ্যে যাত্রা করুন।',
    descEn: 'Receive your approved visa, book discounted airline tickets, and fly with confidence.',
    icon: 'PlaneTakeoff'
  }
];

export const WHY_CHOOSE_US = [
  {
    titleBn: '১৭+ বছরের দীর্ঘ অভিজ্ঞতা (EST. 2008)',
    titleEn: '17+ Years of Experience (EST. 2008)',
    descBn: '২০০৮ সাল থেকে সুনামের সাথে পরিচালিত। কোনো অস্থায়ী বা ভুয়া মাধ্যম নয়—একটি সুপ্রতিষ্ঠিত প্রতিষ্ঠান।',
    descEn: 'Operating with unwavering integrity in Sunamganj and Sylhet since 2008 with a proven track record.'
  },
  {
    titleBn: 'সুনামগঞ্জ থেকে সমগ্র বাংলাদেশ',
    titleEn: 'Sunamganj to All Bangladesh',
    descBn: 'প্রথমে স্থানীয়ভাবে মানুষের মন জয় করেছি, এখন সারাদেশের গ্রাহকদের পূর্ণ আস্থায় সেবা দিচ্ছি।',
    descEn: 'Started with our beloved home community in Sunamganj, now proudly serving nationwide clients.'
  },
  {
    titleBn: 'মালয়েশিয়ায় বিশেষ দক্ষতা ও সাফল্য',
    titleEn: 'Malaysia Work Visa Mastery',
    descBn: '"আমাদের সবচেয়ে প্রিয় এবং সেরা কাজ হলো মালয়েশিয়া।" কলিং ভিসা ও ওয়ার্ক পারমিটে শীর্ষ নির্ভরযোগ্যতা।',
    descEn: 'Our core specialty and pride. Highest approval track record in Malaysia calling and work visas.'
  },
  {
    titleBn: '১০০% স্বচ্ছতা ও সার্বক্ষণিক যোগাযোগ',
    titleEn: '100% Transparency & Real Support',
    descBn: 'কোনো অস্পষ্ট খরচ নেই। আবেদনের প্রতি ধাপে সরাসরি প্রতিষ্ঠাতা ও টিমের সাথে ফোনে কথা বলতে পারবেন।',
    descEn: 'Clear payment schedules, authentic documentation, and direct access to leadership.'
  }
];

export const FAQS = [
  {
    qBn: 'মালয়েশিয়া ওয়ার্ক বা কলিং ভিসার জন্য কী কী কাগজ প্রয়োজন?',
    qEn: 'What documents are required for Malaysia Calling/Work Visa?',
    aBn: 'নূন্যতম ১ বছর মেয়াদী পাসপোর্ট, ছবি, মেডিকেল টেস্ট রিপোর্ট, পুলিশ ক্লিয়ারেন্স এবং এনআইডি কার্ডের কপি। আমাদের সাথে যোগাযোগ করলে সম্পূর্ণ তালিকা জানিয়ে দেওয়া হবে।',
    aEn: 'A valid passport (at least 12 months validity), photos, approved medical test, police clearance, and NID card copy.'
  },
  {
    qBn: 'আমি কি সুনামগঞ্জের বাইরে অন্য জেলা থেকে আবেদন করতে পারব?',
    qEn: 'Can I apply from outside Sunamganj district?',
    aBn: 'হ্যাঁ, অবশ্যই! আমরা এখন সমগ্র বাংলাদেশের যেকোনো জেলার ক্লায়েন্টদের সেবা প্রদান করছি। আপনি অনলাইনে কাগজপত্র পাঠিয়ে বা সরাসরি অফিসে এসে যোগাযোগ করতে পারেন।',
    aEn: 'Yes! We actively serve applicants from all 64 districts across Bangladesh via secure online document verification and office visits.'
  },
  {
    qBn: 'আপনারা কি এয়ার টিকিট বুকিং ও তারিখ পরিবর্তনের সেবা দেন?',
    qEn: 'Do you provide air ticket booking and date change support?',
    aBn: 'হ্যাঁ, বিমান বাংলাদেশ, ইউএস-বাংলা, মালয়েশিয়া এয়ারলাইন্স, এয়ার এশিয়া সহ সকল এয়ারলাইন্সের টিকিট সবচেয়ে সুলভ মূল্যে প্রদান করা হয়।',
    aEn: 'Yes, we issue domestic and international flight tickets with competitive fares and prompt reschedule/refund support.'
  },
  {
    qBn: 'অফিসের অবস্থান ও যোগাযোগের সময় কী?',
    qEn: 'What is your office location and visiting hours?',
    aBn: 'আমাদের অফিস: ষোলঘর পয়েন্ট, সুনামগঞ্জ, সিলেট - ৩০০০। শনিবার থেকে বৃহস্পতিবার সকাল ৯টা থেকে রাত ৯টা পর্যন্ত অফিস খোলা থাকে। হটলাইন: ০১৯১৪৪৮৪৬২৭।',
    aEn: 'Office address: Shologhar Point, Sunamganj, Sylhet - 3000. Open Saturday to Thursday from 9 AM to 9 PM. Hotline: 01914484627.'
  }
];

export const STATS = [
  { valueBn: '১৭+', valueEn: '17+', labelBn: 'বছরের গৌরবময় সেবা', labelEn: 'Years in Business' },
  { valueBn: '১০০০০+', valueEn: '10,000+', labelBn: 'সফল বিদেশ যাত্রা', labelEn: 'Successful Travelers' },
  { valueBn: '১০০%', valueEn: '100%', labelBn: 'বিশ্বস্ত ও বৈধ প্রক্রিয়া', labelEn: 'Verified Processing' },
  { valueBn: '২৪/৭', valueEn: '24/7', labelBn: 'হটলাইন সহায়তা', labelEn: 'Client Support' }
];
